"""Privacy / utility validation on REAL activations of a trained MobileNetV2 (torchvision architecture, 19 blocks).
Data: the 5000 real MNIST digits bundled with the `mlxtend` PyPI package (no external download needed).
The network is trained here (width 0.35, first conv stride 1, 32x32 input): pretrained ImageNet weights and ImageNet images
are not reachable from the evaluation environment, so this is a real-data, real-network, but small-scale validation.

Mechanism under test (Eq. dp of the paper): a_hat = clip_C(a) + Laplace(0, 2C/eps) applied to the l1-clipped activation
a_k = f_{0..k}(x) of the transmitted split k; C_k = 95th percentile of ||a_k||_1 on the training set.

Outputs results/privacy_real.json, figures/fig12_privacy_real.pdf
  (1) accuracy of the cloud half (blocks k+1..18 + classifier) on DP-noised activations vs eps and k
  (2) reconstruction attack: ridge-regression decoder trained by the adversary on auxiliary (activation, image) pairs
  (3) class-identity attack: logistic regression trained on clean activations of auxiliary data, applied to noisy ones
  (4) membership inference: (a) optimal likelihood-ratio test between two candidate inputs (the quantity eps-DP bounds),
      (b) confidence-threshold MI against the trained model (members = training set) through the DP channel
  (5) repeated queries: adversary averages T independent noisy transmissions of the SAME input
    python greensplit/privacy_real.py   (about 10-15 min on CPU)"""
import os, json, time
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from torchvision import models
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import roc_auc_score
from mlxtend.data import mnist_data
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
torch.manual_seed(0); np.random.seed(0); rng = np.random.default_rng(0)
torch.set_num_threads(max(1, os.cpu_count() or 1))

# ---------------- data
X, y = mnist_data(); X = X.reshape(-1, 28, 28).astype(np.float32) / 255.0
X = np.pad(X, ((0, 0), (2, 2), (2, 2)))                       # 32x32
perm = rng.permutation(len(X)); X, y = X[perm], y[perm]
split = dict(member=slice(0, 1500), nonmember=slice(1500, 3000), aux=slice(3000, 4500), test=slice(4500, 5000))
def get(name): s = split[name]; return torch.tensor(X[s])[:, None].repeat(1, 3, 1, 1), torch.tensor(y[s])
Xm, ym = get('member'); Xn, yn = get('nonmember'); Xa, ya = get('aux'); Xt, yt = get('test')

# ---------------- model: torchvision MobileNetV2 (19 feature blocks), small width, trained on the 'member' split only
net = models.mobilenet_v2(weights=None, width_mult=0.35, num_classes=10, dropout=0.0)
net.features[0][0].stride = (1, 1)                              # keep spatial resolution for 32x32 inputs
path = os.path.join(ROOT, 'results', 'mnist_mobilenetv2_w035.pt')
if os.path.exists(path):
    net.load_state_dict(torch.load(path))
else:
    opt = torch.optim.Adam(net.parameters(), 2e-3, weight_decay=0); net.train(); t0 = time.time()
    for ep in range(25):                                        # train on members only -> mild overfit, a meaningful MI target
        p = torch.randperm(len(Xm))
        for i in range(0, len(Xm), 64):
            b = p[i:i + 64]; opt.zero_grad(); F.cross_entropy(net(Xm[b]), ym[b]).backward(); opt.step()
    torch.save(net.state_dict(), path); print('trained in %.0fs' % (time.time() - t0))
net.eval()
L = len(net.features)
def feats(x, upto):
    with torch.no_grad():
        for i in range(upto + 1): x = net.features[i](x)
    return x
def cloud(a, k):
    with torch.no_grad():
        for i in range(k + 1, L): a = net.features[i](a)
        return net.classifier(a.mean((2, 3)))
def acc(lg, yy): return float((lg.argmax(1) == yy).float().mean())
_It = Xt[:, 0].flatten(1).numpy(); _mean = Xa[:, 0].flatten(1).numpy().mean(0)
OUT = dict(recon_baseline_mean_image=dict(mse=float(((_It - _mean) ** 2).mean()), corr=float(np.mean([np.corrcoef(_mean, _It[i])[0, 1] for i in range(len(_It))]))), clean_acc=dict(member=acc(net(Xm), ym), nonmember=acc(net(Xn), yn), test=acc(net(Xt), yt)), L=L)
print(OUT)

# ---------------- mechanism
def clip_l1(a, C):
    n = a.flatten(1).abs().sum(1).clamp_min(1e-12); return a * torch.clamp(C / n, max=1.0).view(-1, *[1] * (a.dim() - 1))
def laplace_like(a, scale, g):
    u = (torch.rand(a.shape, generator=g) - 0.5).clamp(-0.5 + 1e-7, 0.5 - 1e-7)
    return -scale * torch.sign(u) * torch.log1p(-2 * u.abs())
KS = [3, 4, 8, 14, 17]; EPS = [0.5, 1.0, 2.0, 10.0, 100.0, 300.0, 1e3, 3e3, 1e4, 1e5]
g = torch.Generator().manual_seed(123)
res = {}
for k in KS:
    A_m, A_n, A_a, A_t = (feats(Z, k) for Z in (Xm, Xn, Xa, Xt))
    d = A_t[0].numel()
    C = float(np.percentile(A_m.flatten(1).abs().sum(1).numpy(), 95))
    cl = lambda A: clip_l1(A, C)
    Ac_m, Ac_n, Ac_a, Ac_t = cl(A_m), cl(A_n), cl(A_a), cl(A_t)
    r = dict(d=int(d), C=C, clip_fraction_test=float((A_t.flatten(1).abs().sum(1) > C).float().mean()),
             acc_clipped_only=acc(cloud(Ac_t, k), yt))
    # adversary-side models trained on clean auxiliary activations
    Fa = Ac_a.flatten(1).numpy().astype(np.float32); Ia = Xa[:, 0].flatten(1).numpy()
    clf = LogisticRegression(max_iter=300, C=1.0).fit(Fa, ya.numpy())
    # decoder: ridge from (noisy-matched) activation to image. Train on activations noised at the attacked eps (strongest adaptive attacker).
    r['eps'] = {}
    for eps in EPS:
        b = 2 * C / eps
        noisy = lambda A: A + laplace_like(A, b, g)
        e = {}
        # (1) utility
        e['acc'] = acc(cloud(noisy(Ac_t), k), yt)
        # (3) class-identity: logistic regression on noisy aux activations (adaptive), tested on noisy test activations
        Na = noisy(Ac_a).flatten(1).numpy(); Nt = noisy(Ac_t).flatten(1).numpy()
        if d * len(Na) < 6e8:
            c2 = LogisticRegression(max_iter=200, C=0.1).fit(Na, ya.numpy()); e['class_attack_acc'] = float((c2.predict(Nt) == yt.numpy()).mean())
        else:
            # high-dimensional early layers: project on the top-256 principal directions of the clean aux activations first (same for the adversary)
            U = np.linalg.svd(Fa - Fa.mean(0), full_matrices=False)[2][:256]
            c2 = LogisticRegression(max_iter=300, C=0.1).fit(Na @ U.T, ya.numpy()); e['class_attack_acc'] = float((c2.predict(Nt @ U.T) == yt.numpy()).mean())
        # (2) reconstruction: ridge decoder on (projected) noisy activations -> pixels
        U2 = np.linalg.svd(Fa - Fa.mean(0), full_matrices=False)[2][:256]
        dec = Ridge(alpha=1.0).fit(Na @ U2.T, Ia)
        rec = dec.predict(Nt @ U2.T); It = Xt[:, 0].flatten(1).numpy()
        e['recon_mse'] = float(((rec - It) ** 2).mean())
        e['recon_corr'] = float(np.mean([np.corrcoef(rec[i], It[i])[0, 1] for i in range(len(It))]))
        # (4a) optimal two-candidate LR test: advantage = TPR - FPR on random pairs of test inputs
        idx = rng.permutation(len(Ac_t)); A1 = Ac_t[idx[:250]]; A2 = Ac_t[idx[250:500]]
        adv = []
        for trial in range(2):
            y1 = A1 + laplace_like(A1, b, g)                    # truth = A1
            s = ((y1 - A2).abs() - (y1 - A1).abs()).flatten(1).sum(1)   # >0 -> decide A1 (log LR / b)
            y2 = A2 + laplace_like(A2, b, g)                    # truth = A2
            s2 = ((y2 - A2).abs() - (y2 - A1).abs()).flatten(1).sum(1)  # >0 -> decide A1 (wrong)
            adv.append(float((s > 0).float().mean() - (s2 > 0).float().mean()))
        e['lr_test_advantage'] = float(np.mean(adv)); e['dp_bound'] = float((np.exp(eps) - 1) / (np.exp(eps) + 1)) if eps < 700 else 1.0
        # (4b) confidence-threshold MI through the channel: members (train) vs non-members, using max softmax of cloud half
        def conf(A): return F.softmax(cloud(noisy(A), k), 1).max(1).values.numpy()
        cm, cn = conf(Ac_m), conf(Ac_n); e['mi_auc'] = float(roc_auc_score(np.r_[np.ones(len(cm)), np.zeros(len(cn))], np.r_[cm, cn]))
        r['eps'][str(eps)] = e
    # (5) repeated queries of the SAME input at eps = 1.0 and 0.5: adversary averages T copies; class-identity with clean-trained classifier
    r['repeat'] = {}
    for eps in (1.0, 0.5):
        b = 2 * C / eps; rr = {}
        for T in (1, 10, 60, 600, 6000):
            if T <= 600:
                Nt = torch.zeros_like(Ac_t)
                for _ in range(T): Nt += Ac_t + laplace_like(Ac_t, b, g)
                Nt = Nt / T
            else:                                               # mean of T Laplace draws: Gaussian by the CLT, std = b*sqrt(2)/sqrt(T)
                Nt = Ac_t + torch.randn(Ac_t.shape, generator=g) * (b * np.sqrt(2) / np.sqrt(T))
            Ntf = Nt.flatten(1).numpy()
            rr[str(T)] = dict(clf_acc=float((clf.predict(Ntf) == yt.numpy()).mean()), cloud_acc=acc(cloud(Nt, k), yt))
        r['repeat'][str(eps)] = rr
    res[str(k)] = r
    print('k=%d d=%d C=%.1f' % (k, d, C), {e: (round(v['acc'], 3), round(v['class_attack_acc'], 3), round(v['lr_test_advantage'], 3)) for e, v in r['eps'].items()}, flush=True)
OUT['by_k'] = res
json.dump(OUT, open(os.path.join(ROOT, 'results', 'privacy_real.json'), 'w'), indent=1)

# ---------------- figure
fig, ax = plt.subplots(1, 3, figsize=(11, 3.2))
cols = plt.cm.viridis(np.linspace(0, 0.9, len(KS)))
for c, k in zip(cols, KS):
    ep = [float(e) for e in res[str(k)]['eps']]
    ax[0].plot(ep, [v['acc'] for v in res[str(k)]['eps'].values()], 'o-', c=c, label='k=%d' % k)
    ax[1].plot(ep, [v['class_attack_acc'] for v in res[str(k)]['eps'].values()], 'o-', c=c)
for a_ in ax[:2]: a_.set_xscale('log'); a_.set_xlabel('per-inference $\\epsilon_r$'); a_.axhline(0.1, c='gray', ls=':'); a_.grid(alpha=.3)
ax[0].set_ylabel('cloud-half accuracy (test)'); ax[0].legend(fontsize=7); ax[0].axhline(OUT['clean_acc']['test'], c='k', ls='--', lw=.8)
ax[1].set_ylabel('class-identity attack accuracy')
ax[2].plot(EPS, [res['14']['eps'][str(e)]['lr_test_advantage'] for e in EPS], 'o-', label='empirical LR-test advantage (k=14)')
ax[2].plot(EPS, [res['14']['eps'][str(e)]['dp_bound'] for e in EPS], 'k--', label='$(e^\\epsilon-1)/(e^\\epsilon+1)$')
ax[2].set_xscale('log'); ax[2].set_xlabel('$\\epsilon_r$'); ax[2].set_ylabel('membership advantage'); ax[2].legend(fontsize=7); ax[2].grid(alpha=.3)
plt.tight_layout(); os.makedirs(os.path.join(ROOT, 'figures'), exist_ok=True); plt.savefig(os.path.join(ROOT, 'figures', 'fig12_privacy_real.pdf')); print('done')
