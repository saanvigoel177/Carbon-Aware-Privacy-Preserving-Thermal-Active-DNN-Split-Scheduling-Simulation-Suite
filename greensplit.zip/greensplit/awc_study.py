"""Extended AWC evaluation (reduced model of original/awc_model_core.py), answering: (i) targets under per-cycle min-max
normalisation, (ii) several objectives violated at once, (iii) oscillation, (iv) unseen disturbance trajectories.
    python greensplit/awc_study.py  -> results/awc_study.json, figures/fig14_awc_study.pdf   (about 1-2 min)
Everything here uses the SAME reduced model as the earlier AWC study (two regions, scalar carbon proxy, synthetic profiles); it is
not the main simulator of sim.py and its numbers are not comparable with Tables 3/9."""
import os, sys, json
import numpy as np
from scipy import stats
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, os.path.join(ROOT, 'original'))
import awc_model_core as M

K = np.array(M.K_CANDIDATES); RN = M.REGION_NAMES
KK = np.repeat(K, len(RN)); RR = np.array([RN[i % len(RN)] for i in range(len(KK))])      # same candidate order as the original loops
n = len(KK)
EDGE_T = np.array([M.edge_time_ms(k) for k in KK]); PAY = np.array([M.TENSOR_KB_AT[k] * 8.0 / (M.REGIONS[r]['bw'] * 1000.0) * 1000.0 for k, r in zip(KK, RR)])
RTT = np.array([M.REGIONS[r]['rtt'] for r in RR]); CLT = np.array([M.cloud_time_ms(k, r) for k, r in zip(KK, RR)])
ENG = np.array([M.edge_energy_mj(k) + M.transfer_energy_mj(k) + M.cloud_energy_mj(k, r) for k, r in zip(KK, RR)])
HEAT = np.array([M.heat_gen_w(k) for k in KK]); PRIV = np.array([M.privacy_penalty(k) for k in KK])
CI_FIXED = np.array([r == 'EU-West' for r in RR])

def lat_raw(bwf): return EDGE_T + RTT + PAY / bwf + CLT + M.DOWNLINK_MS
def carb_raw(ci_eu, ci_other): return ENG / 3.6e9 * np.where(CI_FIXED, ci_eu, ci_other) * 1000.0

# fixed reference scales (computed once from the design space, independent of the cycle) -> physical targets
L_LO, L_HI = lat_raw(1.0).min(), lat_raw(0.1).max()
C_LO, C_HI = carb_raw(180.0, 180.0).min(), carb_raw(800.0, 800.0).max()
TH_REF = (42.0 - M.T_SAFE) ** 2
def norm_ref(lat, carb, th): return (lat - L_LO) / (L_HI - L_LO), (carb - C_LO) / (C_HI - C_LO), np.minimum(1.0, th / TH_REF)
def norm_mm(x): return (x - x.min()) / (x.max() - x.min() + 1e-9)

def paper_traj():
    return dict(ci_eu=lambda t: 650.0 if 70 <= t <= 110 else 180.0, ci_ot=lambda t: 450.0, amb=lambda t: 34.0 if 120 <= t <= 160 else 24.0, bwf=lambda t: 1.0)

def rand_traj(seed):
    g = np.random.default_rng(10_000 + seed)
    s1, d1, m1 = g.uniform(20, 120), g.uniform(20, 60), g.uniform(400, 700)
    two = g.random() < 0.5; s1b, d1b, m1b = g.uniform(20, 140), g.uniform(20, 60), g.uniform(500, 800)
    s2, d2, a2 = g.uniform(40, 140), g.uniform(20, 60), g.uniform(30, 38)
    s3, d3, f3 = g.uniform(20, 160), g.uniform(20, 60), g.uniform(0.1, 0.6)
    return dict(ci_eu=lambda t: m1 if s1 <= t <= s1 + d1 else 180.0,
                ci_ot=lambda t: m1b if (two and s1b <= t <= s1b + d1b) else 450.0,
                amb=lambda t: a2 if s2 <= t <= s2 + d2 else 24.0, bwf=lambda t: f3 if s3 <= t <= s3 + d3 else 1.0,
                windows=dict(carbon=(s1, s1 + d1), thermal=(s2, s2 + d2), bw=(s3, s3 + d3)))

PRESETS = {k: v / v.sum() for k, v in M.PRESETS.items()}
W_MIN, W_MAX = 0.05, 0.85

def run(policy, traj, eta=3.0, tau=0.30, seed=0, w0='Environmental Priority', n_cycles=200):
    """policy: 'static_mm' (fixed weights, per-cycle min-max, as in the paper's baselines), 'awc_mm' (paper's AWC),
    'static_ref' / 'awc_ref' (fixed-reference normalisation in J and in the excess), 'awc_mix' (per-cycle min-max in J, as in the paper,
    but the EXCESS over the target is measured on the fixed-reference scale, so tau is a physical level)."""
    rng = np.random.default_rng(seed); w = PRESETS[w0].copy(); T = 24.0; tauv = np.full(4, tau)
    adaptive = policy.startswith('awc'); ref = policy.endswith('ref'); ex_ref_upd = policy in ('awc_ref', 'awc_mix')
    E_ref = E_mm = 0.0; tv = 0.0; sw = 0; prev = None; hot = 0; both = []; Es = []; lat_sum = 0.0; clip_hits = 0; ws = []
    for t in range(n_cycles):
        amb = traj['amb'](t)
        s_hat = T + (M.DT / M.C_TH) * (HEAT - (T - amb) / M.R_TH); th = np.maximum(0.0, s_hat - M.T_SAFE) ** 2
        z = rng.normal(0, 0.02, (n, 2))
        lat = lat_raw(traj['bwf'](t)) * (1 + z[:, 0]); carb = carb_raw(traj['ci_eu'](t), traj['ci_ot'](t)) * (1 + z[:, 1])
        if ref: hl, hc, ht = norm_ref(lat, carb, th)
        else: hl, hc, ht = norm_mm(lat), norm_mm(carb), norm_mm(th)
        J = w[0] * hl + w[1] * hc + w[2] * PRIV + w[3] * ht
        i = int(np.argmin(J)); k_, r_ = KK[i], RR[i]
        hat_sel = np.array([hl[i], hc[i], PRIV[i], ht[i]])
        # common evaluation metric: fixed-reference excess over the same numeric targets, summed over objectives
        rl, rc, rt = norm_ref(lat[i:i + 1], carb[i:i + 1], th[i:i + 1]); ex_ref = np.maximum(0.0, np.array([rl[0], rc[0], PRIV[i], rt[0]]) - tauv)
        ex_mm = np.maximum(0.0, np.array([norm_mm(lat)[i], norm_mm(carb)[i], PRIV[i], norm_mm(th)[i]]) - tauv)
        E_ref += ex_ref.sum(); E_mm += ex_mm.sum(); Es.append(ex_ref)
        if prev is not None and (k_, r_) != prev: sw += 1
        prev = (k_, r_); lat_sum += lat[i]
        T = T + (M.DT / M.C_TH) * (HEAT[i] - (T - amb) / M.R_TH); hot += int(T > M.T_SAFE)
        ws.append(w.copy())
        if adaptive:
            ex = ex_ref.copy() if policy == 'awc_mix' else np.maximum(0.0, hat_sel - tauv); wt = w * np.exp(eta * ex); w2 = wt / wt.sum(); wc = np.clip(w2, W_MIN, W_MAX); clip_hits += int(np.any(wc != w2)); w = wc / wc.sum()
            tv += np.abs(w - ws[-1]).sum()
    return dict(E_ref=E_ref, E_mm=E_mm, tv=tv / n_cycles, sw=sw, hot=hot, lat=lat_sum / n_cycles, clip=clip_hits / n_cycles,
                excess_by_obj=np.sum(Es, 0).tolist(), w_final=w.tolist(), ws=np.array(ws))

OUT = {}
# ---- (0) validation: the generalised runner reproduces the original run_scenario on the paper scenario
v = []
for sd in range(3):
    orig, _ = M.run_scenario(PRESETS['Environmental Priority'], adaptive=True, eta=3, tau=0.30, w_min=W_MIN, w_max=W_MAX, seed=sd)
    mine = run('awc_mm', paper_traj(), seed=sd)['E_mm']; v.append((float(orig), float(mine)))
OUT['validation_vs_original'] = dict(pairs=v, max_abs_diff=float(max(abs(a - b) for a, b in v))); assert OUT['validation_vs_original']['max_abs_diff'] < 1e-9, v
print('validation', OUT['validation_vs_original'])

# ---- (1) the min-max/target issue: how much does the "normalised cost of the chosen action" move for the SAME physical action?
rg = np.random.default_rng(5); rows = []
for sd in range(40):
    tr = rand_traj(sd); r_ = run('static_mm', tr, seed=sd)
for t_ in (0, 60, 90, 130, 150):          # same chosen action (k=14, EU-West) under the paper scenario at different cycles
    pass
tr = paper_traj(); sel = np.where((KK == 14) & (RR != 'EU-West'))[0][0]; vals = []
for t in range(200):
    carb = carb_raw(tr['ci_eu'](t), tr['ci_ot'](t)); vals.append((float(carb[sel]), float(norm_mm(carb)[sel]), float(norm_ref(lat_raw(1.0)[sel:sel + 1], carb[sel:sel + 1], np.zeros(1))[1][0])))
vals = np.array(vals)
OUT['minmax_instability'] = dict(split14_other_region_carbon_g_range=[float(vals[:, 0].min()), float(vals[:, 0].max())],
    minmax_norm_range=[float(vals[:, 1].min()), float(vals[:, 1].max())], ref_norm_range=[float(vals[:, 2].min()), float(vals[:, 2].max())])
print('minmax instability', OUT['minmax_instability'])

# ---- (2) held-out trajectories: tune (eta, tau) on TRAIN trajectories, evaluate on unseen TEST trajectories
TRAIN = list(range(0, 30)); TEST = list(range(100, 160))
GE, GT = [0.5, 1.0, 3.0, 8.0], [0.20, 0.30, 0.40]
def mean_E(policy, ids, **kw): return float(np.mean([run(policy, rand_traj(i), seed=i, **kw)['E_ref'] for i in ids]))
tune = {pol: {f'{e}|{t}': mean_E(pol, TRAIN, eta=e, tau=t) for e in GE for t in GT} for pol in ('awc_mm', 'awc_ref', 'awc_mix')}
best = {pol: min(tune[pol], key=tune[pol].get) for pol in tune}
OUT['tuning'] = dict(grid_eta=GE, grid_tau=GT, train_mean_E_ref=tune, best=best)
print('best on train', best)
# evaluation metric uses tau=0.30 for static policies; for tuned policies evaluate E_ref at THEIR tau would change the metric -> keep metric tau fixed at 0.30
def evalp(policy, ids, eta=3.0, tau=0.30):
    rs = [run(policy, rand_traj(i), eta=eta, tau=tau, seed=i) for i in ids]
    return rs
def summarize(rs):
    E = np.array([r['E_ref'] for r in rs]); return dict(E_mm_mean=float(np.mean([r['E_mm'] for r in rs])), E_ref_mean=float(E.mean()), E_ref_sd=float(E.std(ddof=1)), E_ref_ci=[float(E.mean() - 1.96 * E.std(ddof=1) / np.sqrt(len(E))), float(E.mean() + 1.96 * E.std(ddof=1) / np.sqrt(len(E)))],
        tv=float(np.mean([r['tv'] for r in rs])), switches=float(np.mean([r['sw'] for r in rs])), hot_cycles=float(np.mean([r['hot'] for r in rs])), lat=float(np.mean([r['lat'] for r in rs])),
        clip_share=float(np.mean([r['clip'] for r in rs])), per_traj=E.tolist())
test = {}
for nm in PRESETS:
    test['static_mm:' + nm] = summarize([run('static_mm', rand_traj(i), seed=i, w0=nm) for i in TEST])
    test['static_ref:' + nm] = summarize([run('static_ref', rand_traj(i), seed=i, w0=nm) for i in TEST])
test['awc_mm:paper(3,0.30)'] = summarize(evalp('awc_mm', TEST))
test['awc_ref:paper(3,0.30)'] = summarize(evalp('awc_ref', TEST))
test['awc_mix:paper(3,0.30)'] = summarize(evalp('awc_mix', TEST))
for pol in ('awc_mm', 'awc_ref', 'awc_mix'):
    e, t = map(float, best[pol].split('|')); test[f'{pol}:tuned({e},{t})'] = summarize(evalp(pol, TEST, e, t))
OUT['test'] = test
best_static_mm = min((k for k in test if k.startswith('static_mm')), key=lambda k: test[k]['E_ref_mean'])
best_static_ref = min((k for k in test if k.startswith('static_ref')), key=lambda k: test[k]['E_ref_mean'])
OUT['best_static'] = dict(mm=best_static_mm, ref=best_static_ref)
def winrate(a, b): return float(np.mean(np.array(test[a]['per_traj']) < np.array(test[b]['per_traj'])))
OUT['winrate'] = {a: dict(vs_env_static=winrate(a, 'static_mm:Environmental Priority'), vs_best_static_mm=winrate(a, best_static_mm), vs_best_static_ref=winrate(a, best_static_ref))
                  for a in test if a.startswith('awc')}
for k_, v_ in test.items(): print(k_, {a: round(b, 2) for a, b in v_.items() if a not in ('per_traj', 'E_ref_ci')})
print('winrate', OUT['winrate'])

# ---- (3) multiple simultaneous violations vs single: split test cycles by number of concurrently active disturbances
def concurrency_split(policy, **kw):
    s_ = {1: [], 2: [], 3: []}
    for i in TEST:
        tr = rand_traj(i); r = run(policy, tr, seed=i, **kw); w_ = tr['windows']
        act = np.array([sum(a <= t <= b for a, b in w_.values()) for t in range(200)])
        # per-cycle excess is not stored; approximate by re-running with per-cycle capture
    return None
def per_cycle_excess(policy, tr, seed, **kw):
    out = []
    rng_state = None
    r = run(policy, tr, seed=seed, **kw)
    return r
# simple and exact: re-run with n_cycles slices is not possible (state), so record per-cycle excess via a second pass of the same code path
def run_cycle_excess(policy, tr, seed, eta=3.0, tau=0.30, w0='Environmental Priority'):
    rng = np.random.default_rng(seed); w = PRESETS[w0].copy(); T = 24.0; tauv = np.full(4, tau); adaptive = policy.startswith('awc'); ref = policy.endswith('ref'); ex_t = []; mix = policy == 'awc_mix'
    for t in range(200):
        amb = tr['amb'](t); s_hat = T + (M.DT / M.C_TH) * (HEAT - (T - amb) / M.R_TH); th = np.maximum(0.0, s_hat - M.T_SAFE) ** 2
        z = rng.normal(0, 0.02, (n, 2)); lat = lat_raw(tr['bwf'](t)) * (1 + z[:, 0]); carb = carb_raw(tr['ci_eu'](t), tr['ci_ot'](t)) * (1 + z[:, 1])
        hl, hc, ht = norm_ref(lat, carb, th) if ref else (norm_mm(lat), norm_mm(carb), norm_mm(th))
        J = w[0] * hl + w[1] * hc + w[2] * PRIV + w[3] * ht; i = int(np.argmin(J)); hs = np.array([hl[i], hc[i], PRIV[i], ht[i]])
        rl, rc, rt = norm_ref(lat[i:i + 1], carb[i:i + 1], th[i:i + 1]); exr = np.maximum(0.0, np.array([rl[0], rc[0], PRIV[i], rt[0]]) - tauv); ex_t.append(exr.sum())
        T = T + (M.DT / M.C_TH) * (HEAT[i] - (T - amb) / M.R_TH)
        if adaptive:
            ex = exr if mix else np.maximum(0.0, hs - tauv); wt = w * np.exp(eta * ex); w2 = wt / wt.sum(); w = np.clip(w2, W_MIN, W_MAX); w = w / w.sum()
    return np.array(ex_t)
conc = {}
for label, pol, kw in (('static_mm_env', 'static_mm', {}), ('awc_mm_paper', 'awc_mm', {}), ('awc_mix_paper', 'awc_mix', {}), ('awc_ref_paper', 'awc_ref', {}), ('static_ref_env', 'static_ref', {})):
    acc = {0: [], 1: [], 2: [], 3: []}
    for i in TEST:
        tr = rand_traj(i); ex = run_cycle_excess(pol, tr, i, **kw); w_ = tr['windows']
        act = np.array([sum(a <= t <= b for a, b in w_.values()) for t in range(200)])
        for c in acc: 
            if np.any(act == c): acc[c].append(float(ex[act == c].mean()))
    conc[label] = {str(c): dict(mean_excess_per_cycle=float(np.mean(v)) if v else None, n_traj=len(v)) for c, v in acc.items()}
OUT['concurrency'] = conc
print('concurrency', json.dumps(conc, indent=0)[:900])

# ---- (4) oscillation: eta sweep on test set (instability at large eta?)
osc = {}
for e in (0.5, 1.0, 3.0, 8.0, 20.0, 50.0):
    for pol in ('awc_mm', 'awc_ref', 'awc_mix'):
        rs = evalp(pol, TEST, eta=e); s_ = summarize(rs); osc[f'{pol}|{e}'] = {a: s_[a] for a in ('E_ref_mean', 'E_mm_mean', 'tv', 'switches', 'clip_share', 'hot_cycles')}
OUT['eta_sweep'] = osc
print('eta sweep', {k: (round(v['E_ref_mean'], 1), round(v['tv'], 3), round(v['switches'], 1), round(v['clip_share'], 2)) for k, v in osc.items()})
json.dump(OUT, open(os.path.join(ROOT, 'results', 'awc_study.json'), 'w'), indent=1)

fig, ax = plt.subplots(1, 3, figsize=(11, 3.2))
names = ['static_mm:Environmental Priority', best_static_mm, 'awc_mm:paper(3,0.30)', 'awc_mix:paper(3,0.30)', 'awc_mix:tuned(%s,%s)' % tuple(best['awc_mix'].split('|')), 'awc_ref:paper(3,0.30)']
short = ['static env', 'best static', 'AWC\n(paper)', 'AWC\n(mix)', 'AWC mix\ntuned', 'AWC\n(ref)']
cols = ['#999', '#666', '#2e7d32', '#aaa', '#777', '#1b5e20']
ax[0].bar(range(6), [test[n_]['E_ref_mean'] for n_ in names], yerr=[1.96 * test[n_]['E_ref_sd'] / np.sqrt(len(TEST)) for n_ in names], color=cols, capsize=2)
ax[0].set_xticks(range(6)); ax[0].set_xticklabels(short, fontsize=6); ax[0].set_ylabel('excess over target, held-out'); ax[0].grid(alpha=.3)
es = [0.5, 1.0, 3.0, 8.0, 20.0, 50.0]
for pol, c in (('awc_mm', '#2e7d32'), ('awc_mix', '#e65100'), ('awc_ref', '#1565c0')):
    ax[1].plot(es, [osc[f'{pol}|{e}']['tv'] for e in es], 'o-', c=c, label=pol); ax[2].plot(es, [osc[f'{pol}|{e}']['E_ref_mean'] for e in es], 'o-', c=c)
for a_ in ax[1:]: a_.set_xscale('log'); a_.set_xlabel('$\\eta$'); a_.grid(alpha=.3)
ax[1].set_ylabel('mean $\\|\\Delta w\\|_1$ per cycle'); ax[1].legend(fontsize=7); ax[2].set_ylabel('excess over target, held-out')
plt.tight_layout(); plt.savefig(os.path.join(ROOT, 'figures', 'fig14_awc_study.pdf'))
