"""Run every experiment; write results/results.json and figures/*.pdf.
Usage (repo root):  python greensplit/experiments.py [N_TRIALS]"""
import sys, os, json, re, time
import numpy as np
from scipy import stats
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
from greensplit import sim
from greensplit.sim import CFG, REGIONS, Arch

N_TRIALS = int(sys.argv[1]) if len(sys.argv) > 1 else 200
OUT = os.path.join(ROOT, 'results'); FIG = os.path.join(ROOT, 'figures')
os.makedirs(OUT, exist_ok=True); os.makedirs(FIG, exist_ok=True)
R = {}
plt.rcParams.update({'font.size': 9, 'axes.grid': True, 'grid.alpha': .3})
COL = {'local_only': '#888', 'local_dvfs': '#555', 'latency_first': '#d9534f', 'carbon_greedy': '#f0ad4e',
       'privacy_static': '#5b9bd5', 'proposed': '#2e7d32'}


def cp_ci(x, n, a=0.05):
    lo = 0.0 if x == 0 else stats.beta.ppf(a / 2, x, n - x + 1)
    hi = 1.0 if x == n else stats.beta.ppf(1 - a / 2, x + 1, n - x)
    return 100 * lo, 100 * hi


def draw(rng):
    return dict(bw=float(rng.lognormal(np.log(10.0), 0.5)), t_init=float(rng.uniform(28, 36)),
                t_amb=float(rng.uniform(22, 30)), soc=float(rng.uniform(0.2, 1.0)))


mn = Arch('MobileNetV2')
assert sim.check_against_notebook(os.path.join(ROOT, 'original', 'CC.ipynb'))

# ------------------------------------------------ E1: Table 9/10 (sustained 60 s stream, one draw per trial)
t0 = time.time(); rng = np.random.default_rng(42)
raw = {s: [] for s in sim.STRATEGIES}
for _ in range(N_TRIALS):
    d = draw(rng)
    for s in sim.STRATEGIES:
        raw[s].append(sim.run_stream(mn, s, d['t_init'], d['t_amb'], d['soc'], d['bw']))
loc = np.mean([r['carbon'] for r in raw['local_only']])
T9 = {}
for s in sim.STRATEGIES:
    rr = raw[s]; lat = np.array([r['lat'] for r in rr]); car = np.array([r['carbon'] for r in rr]) / loc * 100
    thr = int(sum(r['throttled'] for r in rr)); pv = int(sum(r['viol_frac'] > 0 for r in rr))
    ks = np.concatenate([r['ks'] for r in rr])
    se = car.std(ddof=1) / np.sqrt(N_TRIALS)
    T9[s] = dict(lat_mean=float(lat.mean()), lat_sd=float(lat.std(ddof=1)), carbon_pct=float(car.mean()),
                 carbon_sd=float(car.std(ddof=1)), carbon_ci=[float(car.mean() - 1.96 * se), float(car.mean() + 1.96 * se)],
                 priv_viol_trials_pct=100.0 * pv / N_TRIALS, priv_viol_trials_n=pv,
                 priv_viol_cycles_pct=float(100 * np.mean([r['viol_frac'] for r in rr])),
                 throttle_pct=100.0 * thr / N_TRIALS, throttle_n=thr, throttle_ci=list(cp_ci(thr, N_TRIALS)),
                 mode_k=int(np.bincount(ks).argmax()), mode_k_share=float(np.bincount(ks).max() / len(ks)),
                 tmean=float(np.mean([r['tmean'] for r in rr])), tmax=float(np.max([r['tmax'] for r in rr])))
R['table9'] = T9; R['n_trials'] = N_TRIALS; R['local_carbon_g'] = float(loc)
R['proposed_vs_latency_first_carbon_reduction_pct'] = float(100 * (1 - T9['proposed']['carbon_pct'] / T9['latency_first']['carbon_pct']))
print(f"E1 done {time.time()-t0:.0f}s")


# ------------------------------------------------ E2: routing-only saving (split held fixed, local excluded)
def routing_saving_B(arch, seeds=(0, 1, 42, 123, 999), n=500, weights=None):
    per_seed, allv, pot = [], [], []
    for sd in seeds:
        rg = np.random.default_rng(sd); v = []; vp = []
        for _ in range(n):
            d = draw(rg)
            w = weights or sim.dynamic_weights(d['t_init'])
            k, r, _, _ = sim.select_proposed(arch, d['bw'], d['t_init'], d['t_amb'], d['soc'], weights=w, exclude_local=True)
            v.append(100 * (1 - arch.carbon_g(k, r) / arch.carbon_g(k, 'IN-South')))
            vp.append(100 * (1 - min(arch.carbon_g(k, q) for q in REGIONS) / arch.carbon_g(k, 'IN-South')))
        per_seed.append(float(np.mean(v))); allv += v; pot.append(float(np.mean(vp)))
    i42 = seeds.index(42) if 42 in seeds else 0
    return dict(mean_seed42=per_seed[i42], seed_means=per_seed, range=[min(per_seed), max(per_seed)],
                sd_of_seed_means=float(np.std(per_seed, ddof=1)) if len(per_seed) > 1 else 0.0,
                median_all=float(np.median(allv)), potential_seed42=pot[i42], potential_range=[min(pot), max(pot)])


R['routing_modelB'] = routing_saving_B(mn)

# Model A: the decision-level optimizer in original/CC.ipynb (cell 3), executed verbatim
nb = json.load(open(os.path.join(ROOT, 'original', 'CC.ipynb')))
ns = {'pd': pd, 'np': np, 'SAFE_TEMP': 35.0}
exec(''.join(nb['cells'][3]['source']), ns)
fc = {'IN-South': {'current': 720, 'lat_penalty': 20}, 'EU-West': {'current': 180, 'lat_penalty': 180},
      'US-East': {'current': 410, 'lat_penalty': 240}}
dfA = pd.DataFrame({'split_layer': range(mn.L), 'data_size_mb': mn.tensor_kb / 1024})


def routing_saving_A(seeds=(0, 1, 42, 123, 999), n=500):
    per_seed, allv = [], []
    for sd in seeds:
        rg = np.random.default_rng(sd); v = []
        for _ in range(n):
            bw = float(rg.lognormal(np.log(10.0), 0.5)); T = float(rg.uniform(28, 36)); ci = float(rg.uniform(350, 750))
            env = dict(temperature=T, bandwidth_mbps=bw, thermal_multiplier=1.0 + max(0.0, T - 35.0) * 0.05, carbon_intensity=ci)
            best, res = ns['calculate_patent_grade_split'](dfA, env, fc)
            k = int(best['split_layer'])
            a = res[(res.split_layer == k) & (res.region == 'IN-South')].carbon.iloc[0]
            b = res[(res.split_layer == k) & (res.region == best['region'])].carbon.iloc[0]
            v.append(100 * (1 - b / a))
        per_seed.append(float(np.mean(v))); allv += v
    return dict(mean_seed42=per_seed[seeds.index(42)], seed_means=per_seed, range=[min(per_seed), max(per_seed)],
                sd_of_seed_means=float(np.std(per_seed, ddof=1)), median_all=float(np.median(allv)))


R['routing_modelA'] = routing_saving_A()
print("E2 done: B potential", round(R['routing_modelB']['potential_seed42'], 2), " A", round(R['routing_modelA']['mean_seed42'], 2))

sens = []; base_cfg = dict(CFG)
for net in (0.005, 0.05):
    for cw in (300.0, 3000.0):
        for cie in (442.0, 720.0):
            CFG.update(NET_KWH_PER_GB=net, CLOUD_POWER_W=cw, CI_EDGE=cie)
            a = Arch('MobileNetV2')
            rr_ = routing_saving_B(a, seeds=(42,), n=200)
            best_any = min(a.carbon_g(k, rg) for k in a.feasible_k for rg in REGIONS)   # includes local (k=L-1)
            sens.append(dict(net_kwh_per_gb=net, cloud_w=cw, ci_edge=cie, routing_saving_pct=rr_['mean_seed42'],
                             potential_pct=rr_['potential_seed42'],
                             best_offload_vs_local_pct=float(100 * best_any / a.local_carbon_g())))
CFG.update(base_cfg); R['sensitivity'] = sens
# embodied-carbon (equipment) sensitivity: gCO2 per GB carried; operational network intensity is 0.05 kWh/GB x 442 = 22.1 gCO2/GB
eq = []
for gam in (0.0, 0.5, 2.0, 8.0, 20.0):
    CFG.update(EQUIP_G_PER_GB=gam); a = Arch('MobileNetV2')
    rr_ = routing_saving_B(a, seeds=(42,), n=200)
    lf = [sim.run_stream(a, 'latency_first', 32.0, 26.0, 0.6, 10.0)['carbon']][0]
    eq.append(dict(gamma=gam, offload_vs_local_x=float(lf / a.local_carbon_g()), routing_saving_pct=rr_['mean_seed42'],
                   potential_pct=rr_['potential_seed42'], equip_share_of_offload_pct=float(100 * a.equip_carbon_g(14) / a.carbon_g(14, 'IN-South'))))
CFG.update(base_cfg); R['equip_sweep'] = eq; R['orch_carbon_g'] = Arch.orch_carbon_g(); R['orch_pct_of_local'] = float(100 * Arch.orch_carbon_g() / mn.local_carbon_g())

# ------------------------------------------------ E3: cross-architecture
w_env = {k: v / 0.85 for k, v in dict(lat=.15, carb=.55, priv=.15).items()}; w_env['therm'] = 0.0
T11 = {}
for name in sim.ARCH_NAMES:
    a = Arch(name); ks, ksf, ratio = [], [], []
    rg = np.random.default_rng(42)
    for _ in range(300):
        d = draw(rg)
        k, r, _, _ = sim.select_proposed(a, d['bw'], d['t_init'], d['t_amb'], d['soc'], weights=w_env, use_dvfs=False)
        ks.append(k)
        kf, rf, _, _ = sim.select_proposed(a, d['bw'], d['t_init'], d['t_amb'], d['soc'], weights=w_env, use_dvfs=False, exclude_local=True)
        ksf.append(kf); ratio.append(100 * a.carbon_g(kf, rf) / a.local_carbon_g())
    rs = routing_saving_B(a, seeds=(42, 1), n=300, weights=w_env)
    kmode = int(np.bincount(ks).argmax()); kfm = int(np.bincount(ksf).argmax())
    T11[name] = dict(L=a.L, zone_end=int(max(a.zone)), k_mode_free=kmode, local_share_free=float(np.mean(np.array(ks) == a.L - 1)),
                     k_mode=kfm, boundary=bool(kfm == min(a.feasible_k)),
                     boundary_share=float(np.mean(np.array(ksf) == min(a.feasible_k))),
                     routing_saving_pct=rs['mean_seed42'], routing_range=rs['range'], potential_pct=rs['potential_seed42'],
                     offload_vs_local_pct=float(np.mean(ratio)), tensor_kb_first=float(a.tensor_kb[0]),
                     tensor_kb_last=float(a.tensor_kb[-1]), gmac=float(a.mmacs.sum() / 1e3))
R['table11'] = T11

# ------------------------------------------------ E4: landscape / convergence / weight sensitivity (forced offload)
nom = dict(bw=10.0, t_init=32.0, t_amb=26.0, soc=0.6); w0 = sim.WEIGHTS_BASE
pairs, J = sim.objective_table(mn, nom['bw'], nom['t_init'], nom['t_amb'], nom['soc'], w0, exclude_local=True)
byk = {k: float(min(J[i] for i, (kk, r) in enumerate(pairs) if kk == k)) for k in mn.feasible_k if k != mn.L - 1}
k0 = pairs[int(np.argmin(J))][0]; J0 = float(J.min())
R['landscape'] = dict(k_star=int(k0), J_min=J0, J_by_k={str(k): v for k, v in byk.items()})
rg = np.random.default_rng(42); conv = []
for _ in range(50):
    d = draw(rg); k, r, _, Jv = sim.select_proposed(mn, d['bw'], d['t_init'], d['t_amb'], d['soc'], weights=w0, use_dvfs=False, exclude_local=True)
    conv.append((k, Jv))
ck = np.array([c[0] for c in conv]); cJ = np.array([c[1] for c in conv])
R['convergence'] = dict(k_mode=int(np.bincount(ck).argmax()), k_sd=float(ck.std(ddof=1)), J_mean=float(cJ.mean()),
                        J_sd=float(cJ.std(ddof=1)), k_min=int(ck.min()), k_max=int(ck.max()))
pert = {}
for key in w0:
    for sign in (-0.5, 0.5):
        w = dict(w0); w[key] *= (1 + sign); s_ = sum(w.values()); w = {a: b / s_ for a, b in w.items()}
        shifts = []; rg = np.random.default_rng(7)
        for _ in range(50):
            d = draw(rg)
            kb = sim.select_proposed(mn, d['bw'], d['t_init'], d['t_amb'], d['soc'], weights=w0, use_dvfs=False, exclude_local=True)[0]
            kp = sim.select_proposed(mn, d['bw'], d['t_init'], d['t_amb'], d['soc'], weights=w, use_dvfs=False, exclude_local=True)[0]
            shifts.append(kp - kb)
        pert[f"w_{key}{'+' if sign > 0 else '-'}50%"] = dict(mean=float(np.mean(shifts)), max_abs=int(np.max(np.abs(shifts))))
R['weight_perturbation'] = pert
R['zone_violations_proposed_E4'] = int(sum(1 for k in ck if k in mn.zone))

# ------------------------------------------------ E5: bandwidth stress
bws = np.linspace(1, 30, 30); bs = {s: [] for s in ('latency_first', 'proposed', 'local_only')}
for b in bws:
    bs['local_only'].append(mn.edge_time_ms(mn.L - 1))
    k, r = sim.select_latency_first(mn, b); bs['latency_first'].append(mn.latency_ms(k, r, b))
    k, r, _, _ = sim.select_proposed(mn, b, 32.0, 26.0, 0.6, weights=w0, use_dvfs=False, exclude_local=True)
    bs['proposed'].append(mn.latency_ms(k, r, b))
R['bandwidth'] = dict(bw=list(map(float, bws)), **{k: list(map(float, v)) for k, v in bs.items()})


# ------------------------------------------------ figures
def save(name):
    plt.tight_layout(); plt.savefig(os.path.join(FIG, name)); plt.close()


ks_ = np.arange(mn.L); parts = np.array([mn.energy_parts_J(k) for k in ks_])
plt.figure(figsize=(5.2, 3.4)); plt.stackplot(ks_, parts.T, labels=['Edge', 'Network', 'Cloud'], colors=['#6fa8dc', '#93c47d', '#e06666'])
plt.yscale('log'); plt.xlabel('Split layer $k$'); plt.ylabel('Energy per inference (J)'); plt.legend(loc='lower left', fontsize=7)
plt.axvline(T9['proposed']['mode_k'], ls='--', c='k', lw=1); plt.title('Energy by split layer (stacked, log scale)'); save('fig1_energy_distribution.pdf')

plt.figure(figsize=(5.4, 3.2)); names = [sim.LABELS[s] for s in sim.STRATEGIES]; vals = [T9[s]['carbon_pct'] for s in sim.STRATEGIES]
plt.bar(names, vals, color=[COL[s] for s in sim.STRATEGIES]); plt.yscale('log'); plt.axhline(100, c='k', lw=.8, ls=':')
for i, v in enumerate(vals): plt.text(i, v * 1.08, f"{v:.0f}%", ha='center', fontsize=8)
plt.ylabel('Carbon (% of local-only, log)'); plt.title(f'Sustained-stream carbon per inference (n={N_TRIALS})'); plt.xticks(fontsize=7); save('fig3_carbon_footprint.pdf')

fig, ax = plt.subplots(1, 2, figsize=(7, 3))
ax[0].plot(ks_, mn.P, 'o-', c='#5b3a9e'); ax[0].axvspan(-.5, max(mn.zone) + .5, color='#f4cccc', alpha=.6, label='$\\mathcal{Z}_{priv}$')
ax[0].set_xlabel('Split layer $k$'); ax[0].set_ylabel('$P(k)$'); ax[0].legend(); ax[0].set_title('Modelled privacy penalty')
ax[1].semilogy(ks_, mn.tensor_kb, 's-', c='#2e7d32'); ax[1].axvspan(-.5, max(mn.zone) + .5, color='#f4cccc', alpha=.6)
ax[1].set_xlabel('Split layer $k$'); ax[1].set_ylabel('Transmitted tensor (KB)'); ax[1].set_title('Tensor size (real profile)'); save('fig6_privacy_risk.pdf')

plt.figure(figsize=(5.2, 3.2))
for s, lab in (('latency_first', 'Latency-first'), ('proposed', 'Proposed (offload forced)'), ('local_only', 'Local-only')):
    plt.plot(bws, bs[s], c=COL[s], label=lab)
plt.xlabel('Available bandwidth (Mbps)'); plt.ylabel('End-to-end latency (ms)'); plt.legend(); plt.title('Bandwidth stress test'); save('fig5_bandwidth_stress.pdf')

fig, ax = plt.subplots(1, 2, figsize=(7, 3))
ax[0].plot(range(1, 51), ck, 'o-', ms=3); ax[0].axhline(R['convergence']['k_mode'], c='r', ls='--', lw=1)
ax[0].set_xlabel('Trial'); ax[0].set_ylabel('Selected split $k^*$'); ax[0].set_title('Split-layer stability (50 trials)')
ax[1].plot(range(1, 51), cJ, 'o-', ms=3, c='#2e7d32'); ax[1].axhline(cJ.mean(), c='r', ls='--', lw=1)
ax[1].set_xlabel('Trial'); ax[1].set_ylabel('$J(k^*,r^*)$'); ax[1].set_title('Objective (50 trials)'); save('fig7_convergence.pdf')

plt.figure(figsize=(5.2, 3.4)); labs = list(pert); x = np.arange(len(labs))
plt.bar(x, [pert[l]['mean'] for l in labs], color=['#d9534f' if '-' in l else '#2e7d32' for l in labs])
plt.xticks(x, labs, rotation=45, ha='right', fontsize=7); plt.ylabel('Mean shift in $k^*$ (layers)'); plt.title('$\\pm$50% weight perturbation'); save('fig8_sensitivity.pdf')

plt.figure(figsize=(5.2, 3.2)); kk = sorted(byk); plt.plot(kk, [byk[k] for k in kk], 'o-')
plt.scatter([k0], [J0], s=120, c='gold', ec='k', zorder=5, label=f'minimum, $J$={J0:.3f}')
plt.scatter(sorted(mn.zone), [min(byk.values())] * len(mn.zone), marker='x', c='r', label='excluded ($\\mathcal{Z}_{priv}$)')
plt.xlabel('Split layer $k$'); plt.ylabel('$J(k,r^*)$'); plt.legend(); plt.title('Optimisation landscape (offloaded splits)'); save('fig9_optimization_landscape.pdf')

plt.figure(figsize=(5.4, 3.4))
for s in sim.STRATEGIES:
    plt.scatter(T9[s]['lat_mean'], T9[s]['carbon_pct'], s=170 if T9[s]['priv_viol_trials_pct'] == 0 else 70, c=COL[s], ec='k',
                label=f"{sim.LABELS[s]} (viol {T9[s]['priv_viol_trials_pct']:.0f}%)")
plt.yscale('log'); plt.xlabel('Mean latency (ms)'); plt.ylabel('Carbon (% of local-only, log)'); plt.legend(fontsize=7)
plt.title('Latency vs carbon (large marker = no privacy violations)'); save('fig10_pareto_front.pdf')

sweep = os.path.join(OUT, 'awc_ablation_sweep.txt')
grid = {}
if os.path.exists(sweep):
    for m in re.finditer(r'^eta=\s*([\d.]+):(.*)$', open(sweep).read(), re.M):
        grid[float(m.group(1))] = [float(v) for v in re.findall(r'->([\d.]+)', m.group(2))]
if grid:
    etas = sorted(grid); taus = [0.20, 0.25, 0.30, 0.35, 0.40]; Z = np.array([grid[e] for e in etas]).T
    plt.figure(figsize=(5.4, 3.4)); im = plt.imshow(Z, origin='lower', aspect='auto', cmap='viridis_r')
    plt.xticks(range(len(etas)), [str(e) for e in etas], fontsize=7); plt.yticks(range(5), [f'{t:.2f}' for t in taus])
    plt.colorbar(im, label='Cumulative excess-over-target'); plt.xlabel('$\\eta$'); plt.ylabel('$\\tau$')
    plt.scatter([etas.index(3.0)], [2], marker='*', s=200, c='red'); plt.title('AWC sweep (reduced reconstruction)'); plt.grid(False)
    save('fig11_awc_ablation.pdf'); R['awc_grid'] = {str(k): v for k, v in grid.items()}

json.dump(R, open(os.path.join(OUT, 'results.json'), 'w'), indent=1, default=float)
print('wrote results.json')
