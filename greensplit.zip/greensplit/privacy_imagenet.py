"""Privacy / utility validation of the DP mechanism on REAL ImageNet images and a PRETRAINED ImageNet MobileNetV2.

Model : MobileNetV2 (ericsun99/MobileNet-V2-Pytorch, BSD-2, ImageNet top-1 71.8 % on the full validation set), 19 feature blocks,
        the same split points k as in the paper (block 18 is the last conv, the 19th feature module is the global pool).
Data  : 1000 real ImageNet validation images, one per class (github.com/EliSchwartz/imagenet-sample-images).
        Set IMAGENET_DIR to the clone (default data/imagenet_sample).  Nothing is trained or tuned here except adversary decoders.

Mechanism (Eq. dp):  a_hat = clip_C(a_k(x)) + Laplace(0, 2C/eps),  C = 95th percentile of ||a_k||_1 on the auxiliary half.

Protocol: 1000 images are split 500 AUX (adversary / calibration, 4 views each: centre crop + 3 random crops, flip) and 500 TEST.
  (1) utility    : top-1 / top-5 of the cloud half on noisy test activations (clean pipeline = reference), with and without
                   a public PCA denoising front-end (post-processing, costs no privacy) fitted on AUX activations
  (2) re-identification : adversary knows clean clipped activations of a gallery (all 1000 images) and returns the nearest gallery
                   item in l1 (the optimal Laplace maximum-likelihood decision); chance = 1/1000
  (3) reconstruction : ridge decoder (top-256 PCs of noisy activation -> 32x32x3 pixels) trained on AUX at the attacked eps (adaptive adversary),
                   tested on the 500 unseen TEST images; baselines = AUX mean image, decoder on clean activations
  (4) membership advantage : optimal likelihood-ratio test between two candidate test inputs (what eps-DP bounds)
  (5) repeated queries : adversary averages T noisy copies of the same input (CLT Gaussian for T > 600)
Membership inference against the *training set* cannot be run: the ImageNet validation images are not training members of the
checkpoint, so only the DP-defined distinguishing advantage (4) is reported.
    python greensplit/privacy_imagenet.py        (~10-25 min on CPU)"""
import os, sys, glob, json, time
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from PIL import Image
from torchvision import transforms as T
from sklearn.linear_model import Ridge
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IMG_DIR = os.environ.get('IMAGENET_DIR', os.path.join(ROOT, 'data', 'imagenet_sample'))
MDL_DIR = os.path.join(ROOT, 'data')
torch.manual_seed(0); np.random.seed(0); rng = np.random.default_rng(0)
torch.set_num_threads(max(1, os.cpu_count() or 1))

# ---------------- model
sys.path.insert(0, MDL_DIR)
from MobileNetV2 import MobileNetV2
net = MobileNetV2(n_class=1000)
sd = torch.load(os.path.join(MDL_DIR, 'mobilenetv2_Top1_71.806_Top2_90.410.pth.tar'), map_location='cpu')
net.load_state_dict({k.replace('module.', ''): v for k, v in sd.items()})
net.features[-1] = nn.AdaptiveAvgPool2d(1); net.eval()
L = len(net.features) - 1            # 18 conv blocks (0..18) + pool at index 19-1 -> use blocks 0..18 as 'layers'
NB = 19                              # feature blocks 0..18 (block 18 = last 1x1 conv); pool applied inside head()
def feats(x, upto):
    with torch.no_grad():
        for i in range(upto + 1): x = net.features[i](x)
    return x
def cloud(a, k):
    with torch.no_grad():
        for i in range(k + 1, NB): a = net.features[i](a)
        return net.classifier(a.mean((2, 3)))

# ---------------- data
files = sorted(glob.glob(os.path.join(IMG_DIR, 'n*.JPEG')))
assert len(files) == 1000, 'expected 1000 ImageNet sample images in %s' % IMG_DIR
labels = np.arange(1000)                                     # class index = rank of sorted wnid
norm = T.Compose([T.ToTensor(), T.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])
def load(f, mode, seed=0):
    im = Image.open(f).convert('RGB'); im = T.Resize(256)(im)
    if mode == 'center': im = T.CenterCrop(224)(im)
    else:
        r = np.random.default_rng(seed); w, h = im.size; x0 = int(r.integers(0, w - 224 + 1)); y0 = int(r.integers(0, h - 224 + 1))
        im = im.crop((x0, y0, x0 + 224, y0 + 224))
        if r.random() < 0.5: im = im.transpose(Image.FLIP_LEFT_RIGHT)
    return norm(im)
t0 = time.time()
Xc = torch.stack([load(f, 'center') for f in files])
perm = rng.permutation(1000); aux_idx, test_idx = perm[:500], perm[500:]
NV = 4
Xaux_views = [Xc[aux_idx]] + [torch.stack([load(files[i], 'rand', seed=1000 * v + int(i)) for i in aux_idx]) for v in range(1, NV)]
Xaux = torch.cat(Xaux_views); del Xaux_views; yaux = np.tile(aux_idx, NV)    # (2000,)
Xte = Xc[test_idx]; yte = test_idx
MEAN = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1); STD = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)
def pix(x): return np.concatenate([F.adaptive_avg_pool2d(x[i:i + 100] * STD + MEAN, 32).flatten(1).numpy() for i in range(0, len(x), 100)])    # 32x32x3 target
Paux, Pte = pix(Xaux), pix(Xte)
print('data ready %.0fs' % (time.time() - t0), flush=True)
def topk(lg, y, k=1): return float((lg.topk(k, 1).indices == torch.as_tensor(y).view(-1, 1)).any(1).float().mean())
with torch.no_grad(): lg_clean = torch.cat([net(Xc[i:i + 100]) for i in range(0, 1000, 100)])
OUT = dict(model='MobileNetV2 pretrained ImageNet (ericsun99/MobileNet-V2-Pytorch)', n_images=1000, n_aux=500, n_test=500,
           clean_top1_all=topk(lg_clean, labels), clean_top5_all=topk(lg_clean, labels, 5),
           clean_top1_test=topk(lg_clean[test_idx], yte), clean_top5_test=topk(lg_clean[test_idx], yte, 5),
           recon_baseline_mean_image=dict(mse=float(((Pte - Paux.mean(0)) ** 2).mean()),
                                          corr=float(np.mean([np.corrcoef(Paux.mean(0), Pte[i])[0, 1] for i in range(len(Pte))]))))
print({k: v for k, v in OUT.items() if k != 'recon_baseline_mean_image'}, OUT['recon_baseline_mean_image'], flush=True)

# ---------------- mechanism
def clip_l1(a, C):
    n = a.flatten(1).abs().sum(1).clamp_min(1e-12); return a * torch.clamp(C / n, max=1.0).view(-1, *[1] * (a.dim() - 1))
def lap(shape, scale, g):
    u = (torch.rand(shape, generator=g) - 0.5).clamp(-0.5 + 1e-7, 0.5 - 1e-7)
    return -scale * torch.sign(u) * torch.log1p(-2 * u.abs())
def psnr(mse): return float(10 * np.log10(1.0 / mse))
KS = [4, 8, 14, 17]
EPS = [1.0, 10.0, 100.0, 1e3, 1e4, 3e4, 1e5, 3e5, 1e6]
g = torch.Generator().manual_seed(7)
res = {}
_jp = os.path.join(ROOT, 'results', 'privacy_imagenet.json')
if os.path.exists(_jp) and os.environ.get('RESUME', '0') == '1':
    res = json.load(open(_jp)).get('by_k', {})        # RESUME=1 continues an interrupted run (per-split results already stored are kept)
for k in KS:
    if str(k) in res: continue
    t1 = time.time()
    with torch.no_grad():
        A_aux = torch.cat([feats(Xaux[i:i + 100], k) for i in range(0, len(Xaux), 100)])
        A_all = torch.cat([feats(Xc[i:i + 100], k) for i in range(0, 1000, 100)])
    d = A_all[0].numel(); shape = tuple(A_all.shape[1:])
    C = float(np.percentile(A_all[aux_idx].flatten(1).abs().sum(1).numpy(), 95))
    Gal = clip_l1(A_all, C)                                  # gallery of clean clipped activations (1000)
    Ac_aux = clip_l1(A_aux, C); Ac_te = Gal[test_idx]
    clip_frac = float((A_all[test_idx].flatten(1).abs().sum(1) > C).float().mean())
    # PCA basis from clean clipped AUX activations (used by adversary decoder and by the public denoiser)
    mu = Ac_aux.flatten(1).mean(0, keepdim=True)
    _, _, V = torch.svd_lowrank(Ac_aux.flatten(1) - mu, q=256, niter=3); V = V.T.contiguous()   # (256,d)
    r = dict(d=int(d), shape=list(shape), C=C, clip_fraction_test=clip_frac,
             top1_clipped_only=topk(cloud(Ac_te, k), yte), top1_clean=topk(cloud(A_all[test_idx], k), yte))
    # decoder on clean activations (upper bound)
    dec0 = Ridge(alpha=1.0).fit(((Ac_aux.flatten(1) - mu) @ V.T).numpy(), Paux)
    rec0 = dec0.predict(((Ac_te.flatten(1) - mu) @ V.T).numpy())
    r['recon_clean'] = dict(mse=float(((rec0 - Pte) ** 2).mean()), corr=float(np.mean([np.corrcoef(rec0[i], Pte[i])[0, 1] for i in range(len(Pte))])))
    r['eps'] = {}
    for eps in EPS:
        b = 2 * C / eps; e = {}
        noisy = lambda A: A + lap(A.shape, b, g)
        Nte = noisy(Ac_te)
        lg = cloud(Nte, k); e['top1'] = topk(lg, yte); e['top5'] = topk(lg, yte, 5)
        # public PCA denoiser (post-processing)
        Z = ((Nte.flatten(1) - mu) @ V.T) @ V + mu
        lgd = cloud(Z.view(-1, *shape), k); e['top1_denoised'] = topk(lgd, yte); e['top5_denoised'] = topk(lgd, yte, 5)
        # (2) re-identification among the 1000-image gallery (optimal l1 ML decision), chunked
        pred = []
        Gf = Gal.flatten(1)
        for i in range(0, len(Nte), 25):
            pred.append(torch.cdist(Nte[i:i + 25].flatten(1), Gf, p=1).argmin(1))
        pred = torch.cat(pred).numpy(); e['reid_acc'] = float((pred == yte).mean())
        # (3) reconstruction: adaptive ridge decoder trained on noisy AUX activations (top-256 PCs)
        Naux = noisy(Ac_aux)
        dec = Ridge(alpha=1.0).fit(((Naux.flatten(1) - mu) @ V.T).numpy(), Paux)
        rec = dec.predict(((Nte.flatten(1) - mu) @ V.T).numpy())
        e['recon_mse'] = float(((rec - Pte) ** 2).mean()); e['recon_corr'] = float(np.mean([np.corrcoef(rec[i], Pte[i])[0, 1] for i in range(len(Pte))]))
        # (4) optimal two-candidate LR test (advantage = TPR - FPR), random pairs of test inputs
        idx = rng.permutation(len(Ac_te)); A1 = Ac_te[idx[:250]]; A2 = Ac_te[idx[250:500]]
        adv = []
        for _ in range(2):
            y1 = A1 + lap(A1.shape, b, g); s1 = ((y1 - A2).abs() - (y1 - A1).abs()).flatten(1).sum(1)
            y2 = A2 + lap(A2.shape, b, g); s2 = ((y2 - A2).abs() - (y2 - A1).abs()).flatten(1).sum(1)
            adv.append(float((s1 > 0).float().mean() - (s2 > 0).float().mean()))
        e['lr_test_advantage'] = float(np.mean(adv)); e['dp_bound'] = float((np.exp(eps) - 1) / (np.exp(eps) + 1)) if eps < 700 else 1.0
        r['eps'][str(eps)] = e
    # (5) repeated queries at eps = 1 (average of T noisy copies of the same test input)
    r['repeat'] = {}
    for eps in (1.0,):
        b = 2 * C / eps; rr = {}
        for Tq in (1, 100, 10 ** 4, 10 ** 6, 10 ** 8):
            if Tq <= 100:
                Nt = torch.zeros_like(Ac_te)
                for _ in range(Tq): Nt += Ac_te + lap(Ac_te.shape, b, g)
                Nt = Nt / Tq
            else:
                Nt = Ac_te + torch.randn(Ac_te.shape, generator=g) * (b * np.sqrt(2) / np.sqrt(Tq))
            pred = torch.cat([torch.cdist(Nt[i:i + 25].flatten(1), Gal.flatten(1), p=1).argmin(1) for i in range(0, len(Nt), 25)]).numpy()
            rr[str(Tq)] = dict(reid_acc=float((pred == yte).mean()), top1=topk(cloud(Nt, k), yte))
        r['repeat'][str(eps)] = rr
    # smallest eps in grid keeping >=90 % / 50 % of clean top-1 (with and without denoiser)
    def need(key, frac):
        for eps in EPS:
            if r['eps'][str(eps)][key] >= frac * r['top1_clean']: return eps
        return None
    r['eps_for_90pct_top1'] = need('top1', .9); r['eps_for_90pct_top1_denoised'] = need('top1_denoised', .9)
    r['eps_for_50pct_top1'] = need('top1', .5); r['eps_for_50pct_top1_denoised'] = need('top1_denoised', .5)
    res[str(k)] = r
    print('k=%d d=%d C=%.0f (%.0fs)' % (k, d, C, time.time() - t1),
          {str(e): (round(v['top1'], 3), round(v['top1_denoised'], 3), round(v['reid_acc'], 3), round(v['recon_corr'], 2), round(v['lr_test_advantage'], 2)) for e, v in r['eps'].items()}, flush=True)
    OUT['by_k'] = res
    json.dump(OUT, open(os.path.join(ROOT, 'results', 'privacy_imagenet.json'), 'w'), indent=1)

# ---------------- figure
fig, ax = plt.subplots(1, 4, figsize=(14, 3.2))
cols = plt.cm.viridis(np.linspace(0, 0.9, len(KS)))
for c, k in zip(cols, KS):
    ep = [float(e) for e in res[str(k)]['eps']]; v = res[str(k)]['eps'].values()
    ax[0].plot(ep, [x['top1'] for x in v], 'o-', c=c, label='k=%d' % k)
    ax[0].plot(ep, [x['top1_denoised'] for x in v], 's--', c=c, ms=3, alpha=.7)
    ax[1].plot(ep, [x['reid_acc'] for x in v], 'o-', c=c)
    ax[2].plot(ep, [x['recon_corr'] for x in v], 'o-', c=c)
ax[0].axhline(OUT['clean_top1_test'], c='k', ls='--', lw=.8); ax[0].set_ylabel('top-1 on noisy activations'); ax[0].legend(fontsize=7)
ax[1].set_ylabel('re-identification acc. (1000 gallery)'); ax[1].axhline(1e-3, c='gray', ls=':')
ax[2].set_ylabel('reconstruction correlation'); ax[2].axhline(OUT['recon_baseline_mean_image']['corr'], c='gray', ls=':')
ax[3].plot(EPS, [res['14']['eps'][str(e)]['lr_test_advantage'] for e in EPS], 'o-', label='LR-test advantage (k=14)')
ax[3].plot(EPS, [res['14']['eps'][str(e)]['dp_bound'] for e in EPS], 'k--', label='$(e^\\epsilon-1)/(e^\\epsilon+1)$')
ax[3].set_ylabel('distinguishing advantage'); ax[3].legend(fontsize=7)
for a_ in ax: a_.set_xscale('log'); a_.set_xlabel('per-inference $\\epsilon_r$'); a_.grid(alpha=.3)
plt.tight_layout(); os.makedirs(os.path.join(ROOT, 'figures'), exist_ok=True); plt.savefig(os.path.join(ROOT, 'figures', 'fig12b_privacy_imagenet.pdf')); print('done')
