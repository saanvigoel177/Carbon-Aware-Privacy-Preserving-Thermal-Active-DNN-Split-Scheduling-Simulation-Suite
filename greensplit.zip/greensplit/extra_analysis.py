"""Supporting analyses referenced in the paper text. Run from repo root after experiments.py:
    python greensplit/extra_analysis.py
Writes results/extra.json and figures/fig4_carbon_24h.pdf (a synthetic illustration)."""
import os, sys, json, time
import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from greensplit import sim
from greensplit.sim import Arch, REGIONS

mn = Arch('MobileNetV2')
OUT = {}

# ---- which trials throttle under Local+DVFS / Proposed (same draw protocol and seed as experiments.py)
rng = np.random.default_rng(42)
rows = []
for _ in range(200):
    d = dict(bw=float(rng.lognormal(np.log(10.0), 0.5)), t_init=float(rng.uniform(28, 36)),
             t_amb=float(rng.uniform(22, 30)), soc=float(rng.uniform(0.2, 1.0)))
    a = sim.run_stream(mn, 'local_dvfs', d['t_init'], d['t_amb'], d['soc'], d['bw'])
    b = sim.run_stream(mn, 'proposed', d['t_init'], d['t_amb'], d['soc'], d['bw'])
    rows.append((d['t_init'], d['t_amb'], d['soc'], a['throttled'], b['throttled'], a['lat'], b['lat'], a['carbon'], b['carbon']))
A = np.array(rows, float)
thr = A[:, 3] == 1
OUT['proposed_equals_local_dvfs_per_trial'] = bool(np.all(A[:, 3] == A[:, 4]) and np.allclose(A[:, 5], A[:, 6])
                                                    and np.allclose(A[:, 8] - A[:, 7], Arch.orch_carbon_g(), rtol=0, atol=1e-12))   # identical except the orchestrator's own carbon
OUT['proposed_minus_local_dvfs_carbon_pct_of_local'] = float(100 * np.mean(A[:, 8] - A[:, 7]) / mn.local_carbon_g())
OUT['throttled_means'] = dict(t_init=float(A[thr, 0].mean()), t_amb=float(A[thr, 1].mean()), soc=float(A[thr, 2].mean()))
OUT['not_throttled_means'] = dict(t_init=float(A[~thr, 0].mean()), t_amb=float(A[~thr, 1].mean()), soc=float(A[~thr, 2].mean()))
OUT['corr_with_throttle'] = dict(t_init=float(np.corrcoef(A[:, 0], thr)[0, 1]), t_amb=float(np.corrcoef(A[:, 1], thr)[0, 1]),
                                 soc=float(np.corrcoef(A[:, 2], thr)[0, 1]))
OUT['throttled_n'] = int(thr.sum())

# ---- network vs on-device energy: the number behind "offloading costs more carbon"
smallest = min(mn.feasible_k[:-1], key=lambda k: mn.tensor_kb[k])
OUT['smallest_tensor_kb'] = float(mn.tensor_kb[smallest]); OUT['smallest_tensor_block'] = int(smallest)
OUT['net_J_smallest'] = float(mn.net_energy_J(smallest)); OUT['edge_J_full_local'] = float(mn.edge_energy_J(mn.L - 1))
OUT['net_J_by_k'] = {int(k): float(mn.net_energy_J(k)) for k in mn.feasible_k}
OUT['carbon_pct_of_local_by_k_IN'] = {int(k): float(100 * mn.carbon_g(k, 'IN-South') / mn.local_carbon_g()) for k in mn.feasible_k}

# ---- decision time in this (Python) simulator
w = sim.dynamic_weights(32.0)
for _ in range(20):
    sim.select_proposed(mn, 10.0, 32.0, 26.0, 0.6, weights=w)
ts = []
for _ in range(300):
    t0 = time.perf_counter(); sim.select_proposed(mn, 10.0, 32.0, 26.0, 0.6, weights=w); ts.append((time.perf_counter() - t0) * 1e3)
OUT['decision_ms_median'] = float(np.median(ts)); OUT['decision_ms_p95'] = float(np.percentile(ts, 95))
OUT['n_candidates'] = len(mn.feasible_k) * len(REGIONS)

# ---- synthetic illustration for Section 4.3 (no data, no selection result implied)
h = np.arange(0, 24.01, 1.0); rg = np.random.default_rng(7)
base = {'IN-South': 715, 'US-East': 405, 'EU-West': 180}
amp = {'IN-South': 15, 'US-East': 25, 'EU-West': 45}
col = {'IN-South': '#c0392b', 'US-East': '#e67e22', 'EU-West': '#2c6fbb'}
plt.figure(figsize=(5.4, 3.0))
for r in ('IN-South', 'US-East', 'EU-West'):
    y = base[r] + amp[r] * np.sin((h - 6) / 24 * 2 * np.pi + {'IN-South': 0, 'US-East': 1, 'EU-West': 2}[r]) + rg.normal(0, 6, h.size)
    plt.plot(h, y, c=col[r], lw=2, label=r)
plt.axvspan(6, 7, color='#27ae60', alpha=.25, label='look-ahead window')
plt.xlabel('Hour of day'); plt.ylabel('CI (gCO$_2$/kWh)'); plt.ylim(0, 820); plt.legend(fontsize=7, ncol=2, loc='upper right')
plt.title('Synthetic illustration of regional carbon-intensity profiles', fontsize=9); plt.grid(alpha=.3)
os.makedirs(os.path.join(ROOT, 'figures'), exist_ok=True)
plt.tight_layout(); plt.savefig(os.path.join(ROOT, 'figures', 'fig4_carbon_24h.pdf')); plt.close()

json.dump(OUT, open(os.path.join(ROOT, 'results', 'extra.json'), 'w'), indent=1)
print(json.dumps({k: v for k, v in OUT.items() if k not in ('net_J_by_k', 'carbon_pct_of_local_by_k_IN')}, indent=1))
