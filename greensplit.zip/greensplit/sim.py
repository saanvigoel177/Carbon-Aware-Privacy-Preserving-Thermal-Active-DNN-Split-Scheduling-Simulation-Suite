"""
greensplit.sim -- single, self-contained simulator for every experiment in the paper
(except the AWC study, which uses the reduced reconstruction in original/awc_*.py).

Design rules
  * No torch: tensor sizes and MAC counts are computed from the architecture definitions;
    `check_against_notebook()` asserts they equal the torch output saved in original/CC.ipynb
    (MobileNetV2, ResNet-50, ViT-Base; to 4 decimals of MB).
  * ONE energy model. Every constant that is an assumption (not a measurement) is named in
    CFG and swept in experiments.py.
  * The hard privacy zone is applied in exactly one place (Arch.zone) and every feasible-set
    selector reads it, so a split inside the zone can never be returned by them.
"""
import numpy as np

# --------------------------------------------------------------------------------------
# Assumptions (all flagged in the paper, all swept in experiments.py)
# --------------------------------------------------------------------------------------
CFG = dict(
    EDGE_P_ACTIVE_W=4.0,        # mean per-block active compute power (sigma 0.15 W)
    EDGE_P_SIGMA_W=0.15,
    P_IDLE_W=1.5,
    CLOUD_POWER_W=300.0,        # stated assumption (server power), not a measurement
    CLOUD_MMAC_PER_MS=500.0,    # modelled cloud throughput
    PUE=1.2,
    NET_KWH_PER_GB=0.05,        # network-path energy intensity (assumption; cite or measure)
    CI_EDGE=720.0,              # g/kWh, edge device assumed installed on the IN-South grid
    CI_NET=442.0,               # g/kWh, blended network-path intensity
    MNV2_EDGE_TOTAL_MS=450.0,   # calibration: full MobileNetV2 on the edge takes 450 ms
    PRIV_DECAY=6.3,             # P(k) = (e^{-s d} - e^{-s})/(1 - e^{-s}), d = k/(L-1)
    PRIV_ZONE_THRESHOLD=0.30,   # Z_priv = {k : P(k) >= threshold}
    EQUIP_G_PER_GB=2.0,         # amortised EMBODIED carbon of network equipment, gCO2 per GB carried (assumption, swept)
    ORCH_POWER_W=4.0,           # edge power while the orchestrator evaluates the candidate set (= active compute power)
    ORCH_MS=0.5,                # orchestrator time per decision cycle (measured 0.4-0.8 ms in this simulator, extra_analysis.py)
)

REGIONS = {
    'IN-South': dict(CI_now=720.0, CI_fcast=680.0, rtt_ms=20.0),
    'EU-West':  dict(CI_now=180.0, CI_fcast=140.0, rtt_ms=180.0),
    'US-East':  dict(CI_now=410.0, CI_fcast=390.0, rtt_ms=240.0),
}

# thermal / battery model constants
C_TH, R_TH, T_SAFE, T_CRITICAL, DT_FORECAST_S = 3.0, 7.0, 35.0, 42.0, 1.0
R0, R1, R2, K_SOC = 0.05, 0.15, 0.02, 4.0
T_REF, I_DISCHARGE_A = 25.0, 1.2
DVFS_FREQ_SCALE = 0.8
DVFS_POWER_MULTIPLIER = DVFS_FREQ_SCALE ** 3      # P ~ V^2 f with V ~ f
WEIGHTS_BASE = dict(lat=0.15, carb=0.55, priv=0.15, therm=0.15)
THERM_ESCALATION_MARGIN_C, THERM_ESCALATION_CAP = 4.0, 0.80
SIM_DURATION_S, STEP_S = 60.0, 0.05


# --------------------------------------------------------------------------------------
# Architecture profiles from first principles (4 bytes / activation element, MACs in 1e6)
# --------------------------------------------------------------------------------------
def _mobilenet_v2():
    cfg = [(1, 16, 1, 1), (6, 24, 2, 2), (6, 32, 3, 2), (6, 64, 4, 2),
           (6, 96, 3, 1), (6, 160, 3, 2), (6, 320, 1, 1)]
    H, c = 112, 32
    sizes, macs = [c * H * H], [3 * 3 * 3 * c * H * H / 1e6]          # features[0]
    for t, cout, n, s in cfg:
        for i in range(n):
            stride = s if i == 0 else 1
            Hout = H // 2 if stride == 2 else H
            cexp = c * t
            m = (c * cexp * H * H if t != 1 else 0) + 9 * cexp * Hout * Hout + cexp * cout * Hout * Hout
            c, H = cout, Hout
            sizes.append(c * H * H); macs.append(m / 1e6)
    sizes.append(1280 * H * H); macs.append(320 * 1280 * H * H / 1e6)   # features[18]
    return np.array(sizes), np.array(macs)


def _resnet50():
    sizes, macs = [], []
    cin, H = 64, 56
    for li, (m, n, s) in enumerate([(64, 3, 1), (128, 4, 2), (256, 6, 2), (512, 3, 2)]):
        for b in range(n):
            stride = s if b == 0 else 1
            Hout = H // 2 if stride == 2 else H
            mac = cin * m * H * H + 9 * m * m * Hout * Hout + m * 4 * m * Hout * Hout
            if b == 0:
                mac += cin * 4 * m * Hout * Hout                       # downsample 1x1
            cin, H = 4 * m, Hout
            sizes.append(cin * H * H); macs.append(mac / 1e6)
    macs[0] += 7 * 7 * 3 * 64 * 112 * 112 / 1e6                         # stem always runs on edge
    return np.array(sizes), np.array(macs)


def _vit(n_tokens, d, n_blocks, patch_in):
    blk = (12 * n_tokens * d * d + 2 * n_tokens * n_tokens * d) / 1e6
    macs = np.full(n_blocks, blk)
    macs[0] += (n_tokens - 1) * patch_in * d / 1e6                      # patch embedding
    return np.full(n_blocks, n_tokens * d), macs


def profile_arrays(name):
    if name == 'MobileNetV2':
        return _mobilenet_v2()
    if name == 'ResNet-50':
        return _resnet50()
    if name == 'ViT-Base':                         # ViT-B/16, 224x224: 197 tokens
        return _vit(197, 768, 12, 16 * 16 * 3)
    if name == 'CLIP ViT-B/32':                    # image encoder only: 50 tokens
        return _vit(50, 768, 12, 32 * 32 * 3)
    raise KeyError(name)


ARCH_NAMES = ['MobileNetV2', 'ResNet-50', 'ViT-Base', 'CLIP ViT-B/32']
_MNV2_TOTAL_MMAC = float(profile_arrays('MobileNetV2')[1].sum())


class Arch:
    def __init__(self, name, seed=0):
        self.name = name
        elems, mmacs = profile_arrays(name)
        self.L = len(elems)
        self.tensor_kb = elems * 4 / 1024.0
        self.mmacs = mmacs
        ms_per_mmac = CFG['MNV2_EDGE_TOTAL_MS'] / _MNV2_TOTAL_MMAC
        self.t_edge_ms = mmacs * ms_per_mmac
        rng = np.random.default_rng(1000 + seed)
        self.p_edge_w = CFG['EDGE_P_ACTIVE_W'] + rng.normal(0, CFG['EDGE_P_SIGMA_W'], self.L)
        s = CFG['PRIV_DECAY']
        d = np.arange(self.L) / (self.L - 1)
        self.P = (np.exp(-s * d) - np.exp(-s)) / (1 - np.exp(-s))      # soft privacy penalty
        self.zone = {int(k) for k in np.where(self.P >= CFG['PRIV_ZONE_THRESHOLD'])[0]}
        self.feasible_k = [k for k in range(self.L) if k not in self.zone]

    # ---- latency -----------------------------------------------------------------
    def edge_time_ms(self, k):
        return float(self.t_edge_ms[:k + 1].sum())

    def cloud_time_ms(self, k):
        rem = float(self.mmacs[k + 1:].sum())
        return rem / CFG['CLOUD_MMAC_PER_MS']

    def latency_ms(self, k, region, bw_mbps):
        if k == self.L - 1:                      # nothing left to offload
            return self.edge_time_ms(k)
        bits = self.tensor_kb[k] * 1024 * 8
        up = bits / (bw_mbps * 1e6) * 1000.0 + REGIONS[region]['rtt_ms'] / 2.0
        return self.edge_time_ms(k) + up + self.cloud_time_ms(k) + 2.0

    # ---- energy / carbon ---------------------------------------------------------
    def edge_energy_J(self, k):
        return float((self.p_edge_w[:k + 1] * self.t_edge_ms[:k + 1] / 1000.0).sum())

    def net_energy_J(self, k):
        if k == self.L - 1:
            return 0.0
        gb = self.tensor_kb[k] * 1024 / 2 ** 30
        return gb * CFG['NET_KWH_PER_GB'] * 3.6e6

    def cloud_energy_J(self, k):
        if k == self.L - 1:
            return 0.0
        return CFG['CLOUD_POWER_W'] * self.cloud_time_ms(k) / 1000.0 * CFG['PUE']

    def energy_parts_J(self, k):
        return self.edge_energy_J(k), self.net_energy_J(k), self.cloud_energy_J(k)

    def equip_carbon_g(self, k):
        """Amortised embodied carbon of the networking equipment carrying the tensor: already a MASS of CO2 (g),
        = (gCO2 per GB carried) x (GB transmitted). It is NOT multiplied by any carbon intensity."""
        if k == self.L - 1:
            return 0.0
        return self.tensor_kb[k] * 1024 / 2 ** 30 * CFG['EQUIP_G_PER_GB']

    @staticmethod
    def orch_carbon_g():
        """Operational carbon of the orchestrator on the edge device: E_orch [J] x CI_edge [g/kWh] / 3.6e6 [J/kWh]."""
        return CFG['ORCH_POWER_W'] * CFG['ORCH_MS'] / 1000.0 * CFG['CI_EDGE'] / 3.6e6

    def carbon_g(self, k, region, edge_e_scale=1.0, orch=False):
        """C_carb(k,r) [g] = E_edge CI_edge + E_net CI_net + E_cloud CI(r,t) + C_equip(k) + [E_orch CI_edge]
        (energies in J, intensities in g/kWh, 3.6e6 J per kWh)."""
        e, n, c = self.energy_parts_J(k)
        e = e * edge_e_scale
        ci_cloud = REGIONS[region]['CI_now'] if region else 0.0
        return ((e * CFG['CI_EDGE'] + n * CFG['CI_NET'] + c * ci_cloud) / 3.6e6 + self.equip_carbon_g(k)
                + (self.orch_carbon_g() if orch else 0.0))

    def local_carbon_g(self):
        return self.carbon_g(self.L - 1, None)

    # ---- thermal -----------------------------------------------------------------
    def p_compute(self, k):
        return float(self.p_edge_w[:k + 1].mean())


def r_int(soc, t_dev):
    return R0 + R1 * np.exp(-K_SOC * soc) + R2 * max(0.0, T_REF - t_dev)


def p_batt(soc, t_dev):
    return I_DISCHARGE_A ** 2 * r_int(soc, t_dev)


def forecast_temp(arch, k, t_dev, t_amb, soc):
    p_gen = arch.p_compute(k) + p_batt(soc, t_dev)
    return t_dev + DT_FORECAST_S * (p_gen - (t_dev - t_amb) / R_TH) / C_TH


def thermal_penalty(arch, k, t_dev, t_amb, soc):
    return max(0.0, forecast_temp(arch, k, t_dev, t_amb, soc) - T_SAFE) ** 2


def dynamic_weights(t_dev, base=WEIGHTS_BASE):
    ex = float(np.clip((t_dev - (T_SAFE - THERM_ESCALATION_MARGIN_C)) / THERM_ESCALATION_MARGIN_C, 0, 1))
    w_th = base['therm'] + ex * (THERM_ESCALATION_CAP - base['therm'])
    sc = (1.0 - w_th) / (1.0 - base['therm'])
    return dict(lat=base['lat'] * sc, carb=base['carb'] * sc, priv=base['priv'] * sc, therm=w_th)


def _norm(v):
    v = np.asarray(v, float)
    span = v.max() - v.min()
    return np.zeros_like(v) if span < 1e-12 else (v - v.min()) / span


# --------------------------------------------------------------------------------------
# Selectors
# --------------------------------------------------------------------------------------
def objective_table(arch, bw, t_dev, t_amb, soc, weights, exclude_local=False):
    """All feasible (k, r) pairs with J(k,r). Zone layers never enter the table."""
    ks = [k for k in arch.feasible_k if not (exclude_local and k == arch.L - 1)]
    pairs = [(k, r) for k in ks for r in REGIONS]
    n_lat = _norm([arch.latency_ms(k, r, bw) for k, r in pairs])
    n_car = _norm([arch.carbon_g(k, r) for k, r in pairs])
    n_th = _norm([thermal_penalty(arch, k, t_dev, t_amb, soc) for k, r in pairs])
    J = np.array([weights['lat'] * n_lat[i] + weights['carb'] * n_car[i]
                  + weights['priv'] * arch.P[k] + weights['therm'] * n_th[i]
                  for i, (k, r) in enumerate(pairs)])
    return pairs, J


def select_proposed(arch, bw, t_dev, t_amb, soc, weights=None, use_dvfs=True, exclude_local=False):
    w = dynamic_weights(t_dev) if weights is None else weights
    pairs, J = objective_table(arch, bw, t_dev, t_amb, soc, w, exclude_local)
    k, r = pairs[int(np.argmin(J))]
    mult = 1.0
    if use_dvfs and forecast_temp(arch, k, t_dev, t_amb, soc) >= T_SAFE:
        mult = DVFS_POWER_MULTIPLIER
    return k, r, mult, float(J.min())


def select_latency_first(arch, bw):
    # unconstrained: may pick any k including the privacy zone (baseline has no zone)
    return min(((k, r) for k in range(arch.L - 1) for r in REGIONS),
               key=lambda kr: arch.latency_ms(kr[0], kr[1], bw))


def select_carbon_greedy(arch, bw):
    r = min(REGIONS, key=lambda x: REGIONS[x]['CI_now'])
    k = min(range(arch.L - 1), key=lambda kk: arch.latency_ms(kk, r, bw))
    return k, r


def select_privacy_static(arch, mi_threshold=0.15):
    k = next((k for k in range(arch.L) if arch.P[k] <= mi_threshold), arch.L - 1)
    r = min(REGIONS, key=lambda x: REGIONS[x]['rtt_ms'])
    return k, r


STRATEGIES = ['local_only', 'local_dvfs', 'latency_first', 'carbon_greedy', 'privacy_static', 'proposed']
LABELS = {'local_only': 'Local-Only', 'local_dvfs': 'Local+DVFS', 'latency_first': 'Latency-First',
          'carbon_greedy': 'CAG', 'privacy_static': 'PASS', 'proposed': 'Proposed'}


def _step(t_dev, soc, p_active, t_amb, dt):
    p_gen = p_active + p_batt(soc, t_dev)
    return t_dev + dt * (p_gen - (t_dev - t_amb) / R_TH) / C_TH


def run_stream(arch, strategy, t_init, t_amb, soc, bw, duration=SIM_DURATION_S, step=STEP_S):
    """60-second continuous inference stream. The *same* trial draw is used for latency,
    carbon, privacy and throttling (no separate random stream)."""
    t_dev, elapsed, throttled, tmax = t_init, 0.0, False, t_init
    fixed = None
    if strategy == 'latency_first':
        fixed = select_latency_first(arch, bw)
    elif strategy == 'carbon_greedy':
        fixed = select_carbon_greedy(arch, bw)
    elif strategy == 'privacy_static':
        fixed = select_privacy_static(arch)
    lat, car, ks, viol, tsum, ncyc = [], [], [], 0, 0.0, 0
    while elapsed < duration and not throttled:
        mult = 1.0
        if strategy == 'local_only':
            k, r = arch.L - 1, None
        elif strategy == 'local_dvfs':          # fair baseline: same reactive DVFS, never offloads
            k, r = arch.L - 1, None
            mult = DVFS_POWER_MULTIPLIER if forecast_temp(arch, k, t_dev, t_amb, soc) >= T_SAFE else 1.0
        elif strategy == 'proposed':
            k, r, mult, _ = select_proposed(arch, bw, t_dev, t_amb, soc)
        else:
            k, r = fixed
        tf = 1.0 / DVFS_FREQ_SCALE if mult < 1.0 else 1.0       # slower clock -> longer edge compute
        e_scale = mult * tf                                       # energy = power x time
        edge_ms = arch.edge_time_ms(k) * tf
        cyc_ms = edge_ms if r is None else arch.latency_ms(k, r, bw) + arch.edge_time_ms(k) * (tf - 1.0)
        lat.append(cyc_ms); car.append(arch.carbon_g(k, r, e_scale, orch=(strategy == 'proposed'))); ks.append(k); viol += int(k in arch.zone)
        active_s = edge_ms / 1000.0
        idle_s = max(0.0, cyc_ms / 1000.0 - active_s)
        for dur, p in ((active_s, arch.p_compute(k) * mult), (idle_s, CFG['P_IDLE_W'])):
            rem = dur
            while rem > 0 and not throttled and elapsed < duration:
                dt = min(step, rem)
                t_dev = _step(t_dev, soc, p, t_amb, dt)
                tmax = max(tmax, t_dev); tsum += t_dev * dt
                if t_dev >= T_CRITICAL:
                    throttled = True
                rem -= dt; elapsed += dt
        ncyc += 1
    return dict(throttled=throttled, tmax=tmax, lat=float(np.mean(lat)), carbon=float(np.mean(car)),
                ks=ks, viol_frac=viol / max(1, len(ks)), tmean=tsum / max(elapsed, 1e-9))


def check_against_notebook(nb_path):
    """Assert the analytic tensor sizes equal the torch output saved in CC.ipynb."""
    import json, re
    nb = json.load(open(nb_path))
    text = ''
    for c in nb['cells']:
        for o in c.get('outputs', []):
            text += ''.join(o.get('text', [])) if 'text' in o else ''
    mnv2 = [float(m.group(1)) for m in re.finditer(r'^\d+\s*\|\s*\S+\s*\|\s*([\d.]+)\s*\|', text, re.M)][:19]

    def mb(n):
        return [round(x * 4 / 2 ** 20, 4) for x in profile_arrays(n)[0]]
    assert mb('MobileNetV2') == mnv2, (mb('MobileNetV2'), mnv2)
    m = re.search(r'ResNet-50 layer sizes \(MB\): (\[.*?\])', text)
    assert mb('ResNet-50') == json.loads(m.group(1))
    m = re.search(r'ViT-Base layer sizes \(MB\): (\[.*?\])', text)
    assert mb('ViT-Base') == json.loads(m.group(1))
    return True
