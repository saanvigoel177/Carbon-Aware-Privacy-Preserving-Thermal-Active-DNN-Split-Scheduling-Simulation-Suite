"""Sensitivity of the sustained-load throttling results to the (unmeasured) thermal / battery / DVFS parameters.
    python greensplit/thermal_sensitivity.py  -> results/thermal_sensitivity.json, figures/fig13_thermal_sensitivity.pdf
Same 200-trial draw protocol as experiments.py (seed 42). Only the two policies that never offload are needed:
Local-Only (no DVFS) and Local+DVFS (== the proposed controller for MobileNetV2 under carbon priority).
One-at-a-time sweeps around the nominal point, then a joint Monte-Carlo over all parameters at once."""
import os, sys, json, itertools
import numpy as np
from scipy import stats
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT)
from greensplit import sim
from greensplit.sim import Arch
mn = Arch('MobileNetV2')
NOM = dict(C_TH=sim.C_TH, R_TH=sim.R_TH, R0=sim.R0, R1=sim.R1, R2=sim.R2, DVFS=sim.DVFS_FREQ_SCALE, AMB_SHIFT=0.0, T_CRIT=sim.T_CRITICAL)

def cp(x, n):
    lo = 0.0 if x == 0 else stats.beta.ppf(0.025, x, n - x + 1); hi = 1.0 if x == n else stats.beta.ppf(0.975, x + 1, n - x)
    return [100 * lo, 100 * hi]

def run(par, n=200, policies=('local_only', 'local_dvfs')):
    sim.C_TH, sim.R_TH = par['C_TH'], par['R_TH']
    sim.R0, sim.R1, sim.R2 = par['R0'], par['R1'], par['R2']
    sim.DVFS_FREQ_SCALE = par['DVFS']; sim.DVFS_POWER_MULTIPLIER = par['DVFS'] ** 3
    sim.T_CRITICAL = par['T_CRIT']
    rng = np.random.default_rng(42); out = {p: [] for p in policies}; tmax = []
    for _ in range(n):
        bw = float(rng.lognormal(np.log(10.0), 0.5)); ti = float(rng.uniform(28, 36)); ta = float(rng.uniform(22, 30)) + par['AMB_SHIFT']; soc = float(rng.uniform(0.2, 1.0))
        for p in policies:
            r = sim.run_stream(mn, p, ti, ta, soc, bw); out[p].append(r['throttled'])
    res = {}
    for p in policies:
        x = int(sum(out[p])); res[p] = dict(pct=100.0 * x / n, ci=cp(x, n))
    return res

def reset():
    sim.C_TH, sim.R_TH, sim.R0, sim.R1, sim.R2 = NOM['C_TH'], NOM['R_TH'], NOM['R0'], NOM['R1'], NOM['R2']
    sim.DVFS_FREQ_SCALE = NOM['DVFS']; sim.DVFS_POWER_MULTIPLIER = NOM['DVFS'] ** 3; sim.T_CRITICAL = NOM['T_CRIT']

GRID = dict(
    C_TH=[1.5, 3.0, 6.0, 12.0],                  # J/K  (3.0 nominal)
    R_TH=[4.0, 5.5, 7.0, 9.0, 12.0],             # K/W  (7.0 nominal)
    AMB_SHIFT=[-6.0, -3.0, 0.0, 3.0, 6.0],       # K added to the 22-30 C ambient range
    BATT_SCALE=[0.5, 1.0, 1.5, 2.0],             # multiplies R0,R1,R2 (internal resistance)
    DVFS=[0.6, 0.7, 0.8, 0.9],                   # frequency step (power x f^3)
)
OUT = dict(nominal={k: float(v) for k, v in NOM.items()}, one_at_a_time={})
for name, vals in GRID.items():
    OUT['one_at_a_time'][name] = {}
    for v in vals:
        par = dict(NOM)
        if name == 'BATT_SCALE': par.update(R0=NOM['R0'] * v, R1=NOM['R1'] * v, R2=NOM['R2'] * v)
        else: par[name] = v
        OUT['one_at_a_time'][name][str(v)] = run(par); reset()
    print(name, {k: (round(x['local_only']['pct'], 1), round(x['local_dvfs']['pct'], 1)) for k, x in OUT['one_at_a_time'][name].items()}, flush=True)

# joint Monte-Carlo: log-uniform over the ranges above (all parameters vary together)
rg = np.random.default_rng(2024); mc = []
for i in range(40):
    par = dict(NOM); par['C_TH'] = float(np.exp(rg.uniform(np.log(1.5), np.log(12.0)))); par['R_TH'] = float(np.exp(rg.uniform(np.log(4.0), np.log(12.0))))
    par['AMB_SHIFT'] = float(rg.uniform(-6, 6)); bs = float(np.exp(rg.uniform(np.log(0.5), np.log(2.0))))
    par.update(R0=NOM['R0'] * bs, R1=NOM['R1'] * bs, R2=NOM['R2'] * bs, DVFS=float(rg.uniform(0.6, 0.9)))
    r = run(par, n=100); reset()
    mc.append(dict(par={k: float(v) for k, v in par.items()}, local_only=r['local_only']['pct'], local_dvfs=r['local_dvfs']['pct']))
lo = np.array([m['local_only'] for m in mc]); dv = np.array([m['local_dvfs'] for m in mc])
OUT['joint_mc'] = dict(n_draws=len(mc), trials_per_draw=100, local_only_pct=dict(min=float(lo.min()), p10=float(np.percentile(lo, 10)), median=float(np.median(lo)), p90=float(np.percentile(lo, 90)), max=float(lo.max())),
                       local_dvfs_pct=dict(min=float(dv.min()), p10=float(np.percentile(dv, 10)), median=float(np.median(dv)), p90=float(np.percentile(dv, 90)), max=float(dv.max())),
                       share_draws_dvfs_lower=float(np.mean(dv <= lo)), frac_draws_dvfs_below_50=float(np.mean(dv < 50)))
# which parameter explains the spread (Spearman rank correlation with the Local+DVFS throttle rate)
keys = ['C_TH', 'R_TH', 'AMB_SHIFT', 'R0', 'DVFS']
OUT['joint_mc']['spearman_local_dvfs'] = {k: float(stats.spearmanr([m['par'][k] for m in mc], dv).statistic) for k in keys}
json.dump(OUT, open(os.path.join(ROOT, 'results', 'thermal_sensitivity.json'), 'w'), indent=1)
print(json.dumps(OUT['joint_mc'], indent=1))

fig, ax = plt.subplots(1, 5, figsize=(12, 2.6), sharey=True)
labs = dict(C_TH='$C_{th}$ (J/K)', R_TH='$R_{th}$ (K/W)', AMB_SHIFT='ambient shift (K)', BATT_SCALE='battery resistance x', DVFS='DVFS step $f$')
for a_, (name, d_) in zip(ax, OUT['one_at_a_time'].items()):
    xs = list(d_); a_.plot(xs, [d_[x]['local_only']['pct'] for x in xs], 'o-', c='#888', label='Local-Only'); a_.plot(xs, [d_[x]['local_dvfs']['pct'] for x in xs], 'o-', c='#2e7d32', label='Local+DVFS / Proposed')
    a_.set_xlabel(labs[name]); a_.grid(alpha=.3)
ax[0].set_ylabel('throttled trials (%)'); ax[0].legend(fontsize=6)
plt.tight_layout(); plt.savefig(os.path.join(ROOT, 'figures', 'fig13_thermal_sensitivity.pdf'))
