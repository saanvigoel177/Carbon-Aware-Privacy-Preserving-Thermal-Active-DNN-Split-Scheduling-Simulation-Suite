"""One-sample t-test of the cosine similarity between a DP-noised transmission and the true clipped activation
against 0 (is there ANY linear signal left?). Uses the same activation draw as original/privacy_attack_evaluation.py
(seed 0, 20000 x 1280, l1-normalised to C=1); noise from an independent generator (seed 2026), Laplace scale 2C/eps.
    python greensplit/privacy_ttest.py   ->  results/privacy_ttest.json"""
import os, json
import numpy as np
from scipy import stats
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
rng = np.random.default_rng(0); d = 1280; n = 20000; C = 1.0
a = rng.uniform(-1, 1, size=(n, d)); a = a / np.linalg.norm(a, ord=1, axis=1, keepdims=True) * C
rn = np.random.default_rng(2026); out = {}
for eps in (1.0, 0.5):
    a_hat = a + rn.laplace(0, 2 * C / eps, size=(n, d))
    cs = np.sum(a_hat * a, 1) / (np.linalg.norm(a_hat, axis=1) * np.linalg.norm(a, axis=1))
    t = stats.ttest_1samp(cs, 0.0); m, s = cs.mean(), cs.std(ddof=1); h = 1.96 * s / np.sqrt(n)
    out[str(eps)] = dict(n=n, mean=float(m), sd=float(s), ci=[float(m - h), float(m + h)], t=float(t.statistic), p=float(t.pvalue))
    print(eps, out[str(eps)])
os.makedirs(os.path.join(ROOT, 'results'), exist_ok=True)
json.dump(out, open(os.path.join(ROOT, 'results', 'privacy_ttest.json'), 'w'), indent=1)
