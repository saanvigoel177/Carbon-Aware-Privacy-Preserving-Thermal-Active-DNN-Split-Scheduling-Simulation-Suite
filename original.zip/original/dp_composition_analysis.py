import numpy as np

# Setup: DT=1.0s control interval, 60-second trial => T=60 DP queries per trial
T = 60
delta_prime = 1e-5  # target slack for advanced composition / RDP->(eps,delta) conversion

eps_regions = {"EU-West (eps=1.0)": 1.0, "US-East/IN-South (eps=0.5)": 0.5}

def basic_composition(eps, T):
    return T * eps

def advanced_composition(eps, T, delta_prime):
    term1 = eps * np.sqrt(2 * T * np.log(1/delta_prime))
    term2 = T * eps * (np.exp(eps) - 1)
    return term1 + term2

def rdp_laplace(alpha, eps, delta_f=1.0, b=1.0):
    # Renyi divergence of order alpha for Laplace mechanism with sensitivity delta_f, scale b
    # Using the standard closed form (Mironov 2017 style approximation used in the paper eq 8)
    ratio = delta_f / b
    a = alpha / (2*alpha - 1) * np.exp((alpha-1)*ratio)
    c = (alpha-1) / (2*alpha - 1) * np.exp(-alpha*ratio)
    return 1.0/(alpha-1) * np.log(a + c)

def rdp_composition(eps, T, delta_prime, delta_f=1.0):
    b = delta_f / eps  # Laplace scale, since eps = delta_f/b -> b = delta_f/eps
    alphas = np.arange(1.01, 64, 0.01)
    best = None
    for alpha in alphas:
        try:
            rdp_per_query = rdp_laplace(alpha, eps, delta_f=delta_f, b=b)
        except (ValueError, ZeroDivisionError, FloatingPointError):
            continue
        if not np.isfinite(rdp_per_query) or rdp_per_query <= 0:
            continue
        composed_rdp = T * rdp_per_query
        # standard RDP -> (eps,delta)-DP conversion (Mironov 2017)
        eps_dp = composed_rdp + np.log(1/delta_prime)/(alpha - 1)
        if best is None or eps_dp < best[0]:
            best = (eps_dp, alpha)
    return best

print(f"T = {T} sequential per-inference DP queries (60-second trial, "
      f"1.0 s control interval, one transmitted/DP-noised activation per decision cycle)")
print(f"delta' = {delta_prime}\n")

results = {}
for label, eps in eps_regions.items():
    basic = basic_composition(eps, T)
    adv = advanced_composition(eps, T, delta_prime)
    rdp_eps, rdp_alpha = rdp_composition(eps, T, delta_prime, delta_f=1.0)
    results[label] = dict(eps=eps, basic=basic, adv=adv, rdp_eps=rdp_eps, rdp_alpha=rdp_alpha)
    print(f"--- {label} ---")
    print(f"  Basic composition:    eps_total = {basic:.2f}  (pure {basic:.2f}-DP)")
    print(f"  Advanced composition: eps_total = {adv:.2f}, delta' = {delta_prime}  "
          f"({adv:.2f}, {delta_prime})-DP")
    print(f"  RDP composition:      eps_total = {rdp_eps:.2f} at optimal alpha={rdp_alpha:.2f}, "
          f"delta'={delta_prime}  ({rdp_eps:.2f}, {delta_prime})-DP")
    print()

# sanity: confirm RDP tightest
for label, r in results.items():
    tightest = min(("basic", r["basic"]), ("advanced", r["adv"]), ("rdp", r["rdp_eps"]), key=lambda x: x[1])
    print(f"{label}: tightest bound = {tightest[0]} (eps={tightest[1]:.2f})")
