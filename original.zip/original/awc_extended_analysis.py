"""
Additional baselines, extended carbon accounting, and tail-latency /
decision-overhead / switching-cost / SLO-violation measurements, built
on top of the recalibrated (v3) AWC model in awc_model_core.py.

Same honesty framing as awc_ablation_sweep.py: this is a reconstruction,
not the original supplementary code, and all the same caveats about
synthetic edge-time profiles, retuned CLOUD_W_PER_MS/HEAT_SCALE, and
CC.ipynb-derived tensor sizes/privacy step-function apply here too,
since this script imports that model directly (awc_model_core.py).

New assumptions specific to this script, flagged as they're introduced:
  - Pareto baseline: equal-weight (0.25 each) L2 distance to the
    per-cycle ideal point in normalised objective space -- a standard,
    simple Pareto-style baseline, not the paper's own algorithm (which
    isn't specified beyond being "Pareto-based").
  - RL baseline: tabular epsilon-greedy Q-learning over a small
    discretised state (carbon-spike flag x thermal-excursion flag) and
    the 15 feasible k actions (region fixed to whichever minimises
    latency for that k, to keep the action space tractable). This is a
    minimal, generic RL baseline -- not any specific published
    algorithm -- since the paper doesn't specify one either.
  - Thermal-only baseline: myopic argmin on forecast thermal penalty
    alone, ties broken by carbon.
  - Network-equipment carbon: a small constant per-cycle operational
    carbon addition for routing equipment, proportional to bytes
    transferred, using a widely-cited network energy intensity range
    (a commonly used estimate is on the order of 0.01-0.1 kWh per GB
    for wired core+access network energy; this script uses 0.05 kWh/GB
    as a representative mid-range synthetic value, not a project-specific
    measurement).
  - Forecast error: the controller/baselines choose actions using a
    noisy forecast of carbon intensity (Gaussian, sigma=10% of true
    value); actual accounted carbon uses the true (unperturbed) CI.
  - SLO: latency SLO = 150 ms, thermal SLO = forecast temperature must
    stay under T_safe. Both are illustrative thresholds, not values
    taken from the paper.
"""
import numpy as np
from awc_model_core import (
    K_CANDIDATES, REGIONS, REGION_NAMES, DT, C_TH, R_TH, T_SAFE,
    ambient_temp, heat_gen_w, privacy_penalty, latency_raw_ms,
    carbon_raw_g, carbon_intensity, PRESETS, TENSOR_KB_AT, N_CYCLES,
)

SLO_LAT_MS = 150.0
NET_KWH_PER_GB = 0.05
DECISION_OVERHEAD_US_PER_CANDIDATE = 8.0  # synthetic constant, microseconds per (k,region) candidate scored


def score_candidates(t, T_device, ci_noise_sigma=0.0, rng=None):
    """Return list of (k, region, lat, carb_true, carb_forecast, therm_pen, priv, net_carb_true)."""
    amb = ambient_temp(t)
    out = []
    for k in K_CANDIDATES:
        s_hat = T_device + (DT / C_TH) * (heat_gen_w(k) - (T_device - amb) / R_TH)
        therm_pen = max(0.0, s_hat - T_SAFE) ** 2
        priv = privacy_penalty(k)
        for region in REGION_NAMES:
            lat = latency_raw_ms(k, region)
            ci_true = carbon_intensity(region, t)
            ci_fore = ci_true * (1 + (rng.normal(0, ci_noise_sigma) if rng is not None and ci_noise_sigma > 0 else 0.0))
            carb_fore = carbon_raw_g(k, region, ci_fore)
            carb_true = carbon_raw_g(k, region, ci_true)
            net_bytes_gb = TENSOR_KB_AT[k] * 1024 / 1e9
            net_carb_g = net_bytes_gb * NET_KWH_PER_GB * ci_true  # gCO2 from network equipment energy
            out.append((k, region, lat, carb_true, carb_fore, therm_pen, priv, net_carb_g, s_hat))
    return out


def run_policy(policy, seed, weights_init=None, eta=3, tau=0.30, w_min=0.05, w_max=0.85,
               ci_noise_sigma=0.10, n_cycles=N_CYCLES):
    rng = np.random.default_rng(seed)
    T_device = 24.0
    w = None
    if policy == "awc":
        w = weights_init.astype(float).copy()
        w = w / w.sum()
    elif policy == "static":
        w = weights_init.astype(float).copy()
        w = w / w.sum()

    Q = {}  # for RL: (state) -> array over k actions
    ALPHA, GAMMA, EPS = 0.3, 0.0, 0.15  # single-step, no bootstrapping needed (episodic-per-cycle reward)

    prev_action = None
    log = dict(
        raw_latency=[], raw_carbon_true=[], net_carbon=[], thermal_excess_count=0,
        latency_slo_violations=0, switches=0, decision_overhead_us=0.0,
        total_carbon_g=0.0, region_carbon={r: 0.0 for r in REGION_NAMES},
        cum_excess=0.0,
    )

    tau_vec = np.full(4, tau)

    for t in range(n_cycles):
        cand = score_candidates(t, T_device, ci_noise_sigma=ci_noise_sigma, rng=rng)
        log["decision_overhead_us"] += len(cand) * DECISION_OVERHEAD_US_PER_CANDIDATE

        raw_lat = np.array([c[2] for c in cand])
        raw_carb = np.array([c[4] for c in cand])  # forecast carbon used for decisions
        raw_therm = np.array([c[5] for c in cand])
        lo_l, hi_l = raw_lat.min(), raw_lat.max()
        lo_c, hi_c = raw_carb.min(), raw_carb.max()
        lo_t, hi_t = raw_therm.min(), raw_therm.max()
        d = 1e-9

        scored = []
        for (k, region, lat, carb_true, carb_fore, therm_pen, priv, net_carb, s_hat) in cand:
            hl = (lat - lo_l) / (hi_l - lo_l + d)
            hc = (carb_fore - lo_c) / (hi_c - lo_c + d)
            ht = (therm_pen - lo_t) / (hi_t - lo_t + d)
            scored.append((k, region, hl, hc, priv, ht, lat, carb_true, therm_pen, net_carb, s_hat))

        if policy in ("awc", "static"):
            best = min(scored, key=lambda s: w[0] * s[2] + w[1] * s[3] + w[2] * s[4] + w[3] * s[5])
        elif policy == "pareto":
            # equal-weight L2 distance to ideal point (0,0,0,0) in normalised space
            best = min(scored, key=lambda s: (s[2] ** 2 + s[3] ** 2 + s[4] ** 2 + s[5] ** 2))
        elif policy == "thermal_only":
            best = min(scored, key=lambda s: (s[5], s[3]))  # ties broken by carbon
        elif policy == "rl":
            spike = 1 if 70 <= t <= 110 else 0
            excursion = 1 if 120 <= t <= 160 else 0
            state = (spike, excursion)
            if state not in Q:
                Q[state] = np.zeros(len(K_CANDIDATES))
            by_k = {}
            for s in scored:
                k_idx = K_CANDIDATES.index(s[0])
                # keep the latency-minimising region for each k, to shrink the action space to |K|
                if k_idx not in by_k or s[6] < by_k[k_idx][6]:
                    by_k[k_idx] = s
            if rng.random() < EPS:
                a = rng.integers(0, len(K_CANDIDATES))
            else:
                a = int(np.argmax(Q[state]))
            best = by_k[a]
        else:
            raise ValueError(policy)

        k_star, region_star = best[0], best[1]
        hl, hc, priv, ht = best[2], best[3], best[4], best[5]
        lat_true, carb_true_g, therm_true, net_carb = best[6], best[7], best[8], best[9]

        excess = np.maximum(0.0, np.array([hl, hc, priv, ht]) - tau_vec)
        log["cum_excess"] += excess.sum()

        if policy == "rl":
            reward = -(excess.sum())
            spike = 1 if 70 <= t <= 110 else 0
            excursion = 1 if 120 <= t <= 160 else 0
            state = (spike, excursion)
            k_idx = K_CANDIDATES.index(k_star)
            Q[state][k_idx] += ALPHA * (reward - Q[state][k_idx])

        # bookkeeping
        log["raw_latency"].append(lat_true)
        log["raw_carbon_true"].append(carb_true_g)
        log["net_carbon"].append(net_carb)
        log["total_carbon_g"] += carb_true_g + net_carb
        log["region_carbon"][region_star] += carb_true_g + net_carb
        if therm_true > 0:
            log["thermal_excess_count"] += 1
        if lat_true > SLO_LAT_MS:
            log["latency_slo_violations"] += 1
        action = (k_star, region_star)
        if prev_action is not None and action != prev_action:
            log["switches"] += 1
        prev_action = action

        amb = ambient_temp(t)
        T_device = T_device + (DT / C_TH) * (heat_gen_w(k_star) - (T_device - amb) / R_TH)

        if policy == "awc":
            w_tilde = w * np.exp(eta * excess)
            w = w_tilde / w_tilde.sum()
            w = np.clip(w, w_min, w_max)
            w = w / w.sum()

    return log


# ----------------------------------------------------------------------
# 1) Additional baselines comparison (Pareto, RL, thermal-only) vs AWC/static
# ----------------------------------------------------------------------
print("=" * 78)
print("1) Additional baselines: cumulative excess-over-target, 3 seeds, 200 cycles")
print("=" * 78)
w0 = PRESETS["Environmental Priority"]
SEEDS = [0, 1, 2]
POLICIES = ["static", "awc", "pareto", "thermal_only", "rl"]
summary = {}
for pol in POLICIES:
    logs = [run_policy(pol, seed=s, weights_init=w0) for s in SEEDS]
    mean_excess = np.mean([l["cum_excess"] for l in logs])
    mean_switches = np.mean([l["switches"] for l in logs])
    mean_slo = np.mean([l["latency_slo_violations"] for l in logs])
    mean_therm = np.mean([l["thermal_excess_count"] for l in logs])
    summary[pol] = dict(excess=mean_excess, switches=mean_switches, slo=mean_slo, therm=mean_therm, logs=logs)
    print(f"{pol:<14} cum_excess={mean_excess:7.2f}  switches={mean_switches:6.1f}  "
          f"lat_SLO_violations={mean_slo:5.1f}/200  thermal_excess_cycles={mean_therm:5.1f}/200")

# ----------------------------------------------------------------------
# 2) Extended carbon accounting: network equipment + geographic disaggregation
# ----------------------------------------------------------------------
print("\n" + "=" * 78)
print("2) Extended carbon accounting (AWC policy, 3-seed mean)")
print("=" * 78)
awc_logs = summary["awc"]["logs"]
total_compute_g = np.mean([sum(l["raw_carbon_true"]) for l in awc_logs])
total_net_g = np.mean([sum(l["net_carbon"]) for l in awc_logs])
total_g = np.mean([l["total_carbon_g"] for l in awc_logs])
print(f"Compute carbon (edge+cloud):      {total_compute_g:8.2f} g-CO2eq-proxy")
print(f"Network-equipment carbon (added): {total_net_g:8.2f} g-CO2eq-proxy  "
      f"({100*total_net_g/total_g:.1f}% of total)")
print(f"Total (compute+network):          {total_g:8.2f} g-CO2eq-proxy")
print("\nGeographic disaggregation (share of total compute+network carbon by region):")
region_means = {r: np.mean([l["region_carbon"][r] for l in awc_logs]) for r in REGION_NAMES}
for r, v in region_means.items():
    print(f"  {r:<20} {v:8.2f}  ({100*v/total_g:.1f}%)")

print("\nForecast-error sensitivity: total carbon under different CI-forecast noise levels")
for sigma in [0.0, 0.05, 0.10, 0.20, 0.35]:
    logs = [run_policy("awc", seed=s, weights_init=w0, ci_noise_sigma=sigma) for s in SEEDS]
    tot = np.mean([l["total_carbon_g"] for l in logs])
    print(f"  CI forecast noise sigma={sigma:.2f}: total carbon = {tot:8.2f} "
          f"({'+' if sigma>0 else ' '}{100*(tot/total_g-1):.1f}% vs sigma=0.10 baseline)" if sigma != 0.10 else
          f"  CI forecast noise sigma={sigma:.2f}: total carbon = {tot:8.2f}  <- baseline used above")

# ----------------------------------------------------------------------
# 3) Tail latency / decision overhead / switching cost / SLO violations
# ----------------------------------------------------------------------
print("\n" + "=" * 78)
print("3) Tail latency, decision overhead, switching cost, SLO violations")
print("=" * 78)
for pol in POLICIES:
    logs = summary[pol]["logs"]
    all_lat = np.concatenate([np.array(l["raw_latency"]) for l in logs])
    p50, p95, p99 = np.percentile(all_lat, [50, 95, 99])
    mean_overhead_us = np.mean([l["decision_overhead_us"] for l in logs]) / N_CYCLES
    print(f"{pol:<14} lat p50={p50:6.1f}ms  p95={p95:6.1f}ms  p99={p99:6.1f}ms  "
          f"mean_decision_overhead={mean_overhead_us:6.1f}us/cycle  "
          f"switches/200cyc={summary[pol]['switches']:5.1f}  "
          f"lat_SLO_violations={summary[pol]['slo']:5.1f}/200 ({100*summary[pol]['slo']/N_CYCLES:.1f}%)")

print("\nDone.")
