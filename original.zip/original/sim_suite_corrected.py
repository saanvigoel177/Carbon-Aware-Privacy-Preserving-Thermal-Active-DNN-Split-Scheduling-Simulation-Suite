"""
Corrected version of simulation_suite.ipynb's baseline comparison (cell 8),
using the paper's fixed 3-intensity carbon model (Eq. carbonfull, sec:carbonmodel)
instead of the single-CI model the original notebook used.

ASSUMPTIONS (flagged, not measured -- adjust if you have better numbers):
  - CI_EDGE  = 720 gCO2/kWh  -- treats the edge device as deployed in the
    IN-South grid. The paper says this is "a deployment-time configuration
    constant" but gives no explicit number. Change EDGE_CI_GCO2_PER_KWH below
    if the device's real deployment grid differs.
  - CI_NET   = 442 gCO2/kWh  -- taken directly from main.tex (the network
    carbon intensity constant used elsewhere in the paper).
  - E_equip and E_orch (Eq. carbonfull's two additional terms: amortised
    embodied networking-equipment carbon, and orchestrator compute carbon)
    are left at 0. The paper states both are expected to be "several orders
    of magnitude smaller" than the other three terms and gives no numeric
    constants to compute them from -- so they're omitted rather than invented.
    If you have real figures for these, add them in `carbon_gco2()` below.
"""
import numpy as np

rng = np.random.default_rng(42)

L = 18
PRIV_ZONE = {0, 1, 2, 3}

_raw = np.array([1.6, 1.5, 1.4, 1.3, 1.2, 1.15, 1.1, 1.05, 1.0, 0.95,
                  0.9, 0.85, 0.8, 0.75, 0.7, 0.65, 0.6, 0.55])
t_edge_ms = _raw / _raw.sum() * 450.0

P_edge_layer_W = 4.0 + rng.normal(0, 0.15, L)

tensor_kb = np.array([588, 588, 294, 294, 147, 147, 73.5, 73.5,
                       36.8, 36.8, 18.4, 18.4, 9.2, 9.2, 4.6, 4.6, 2.3, 2.3])

layer_mflops = np.array([54, 54, 44, 44, 35, 35, 28, 28, 22, 22,
                          18, 18, 15, 15, 12, 12, 10, 10])

E_per_bit_nJ = 1.0
CLOUD_MFLOPS_PER_MS = 500.0
J_PER_MFLOP_CLOUD = 0.00003

regions = {
    'IN-South': dict(CI_now=720, CI_fcast=680, rtt_ms=20,  compute_scale=1.0),
    'EU-West':  dict(CI_now=180, CI_fcast=140, rtt_ms=180, compute_scale=1.0),
    'US-East':  dict(CI_now=410, CI_fcast=390, rtt_ms=240, compute_scale=1.0),
}
PUE = 1.2

# --- ASSUMPTION: fixed constants for the 3-CI carbon model (see docstring) ---
EDGE_CI_GCO2_PER_KWH = 720.0   # ASSUMPTION: device deployed in IN-South grid
NET_CI_GCO2_PER_KWH = 442.0    # from main.tex

def p_compute(k):
    return float(np.mean(P_edge_layer_W[:k + 1]))

def mutual_info(k):
    return np.exp(-0.35 * k)

_I_MAX = mutual_info(0)
_I_MIN = mutual_info(L - 1)

def P_priv(k):
    return (mutual_info(k) - _I_MIN) / (_I_MAX - _I_MIN)

def edge_time_ms(k):
    return float(np.sum(t_edge_ms[:k + 1]))

def edge_energy_J(k):
    idx = slice(0, k + 1)
    return float(np.sum(P_edge_layer_W[idx] * (t_edge_ms[idx] / 1000.0)))

def uplink_time_ms(k, region, bandwidth_mbps):
    bits = tensor_kb[k] * 1024 * 8
    transmit_ms = bits / (bandwidth_mbps * 1e6) * 1000.0
    return transmit_ms + region['rtt_ms'] / 2.0

def net_energy_J(k):
    bits = tensor_kb[k] * 1024 * 8
    return bits * E_per_bit_nJ * 1e-9

def cloud_time_ms(k, region):
    remaining = float(np.sum(layer_mflops[k + 1:])) if k + 1 < L else 0.0
    return remaining / (CLOUD_MFLOPS_PER_MS * region['compute_scale'])

def cloud_energy_J(k, region):
    remaining = float(np.sum(layer_mflops[k + 1:])) if k + 1 < L else 0.0
    return remaining * J_PER_MFLOP_CLOUD * PUE

def latency_ms(k, region_name, bandwidth_mbps):
    region = regions[region_name]
    return (edge_time_ms(k) + uplink_time_ms(k, region, bandwidth_mbps)
            + cloud_time_ms(k, region) + 2.0)

def carbon_gco2(k, region_name, bandwidth_mbps):
    """FIXED: separate CI_edge / CI_net / CI_cloud(r) instead of one blended CI
    applied to edge+net+cloud (Eq. carbonfull in main.tex, sec:carbonmodel)."""
    region = regions[region_name]
    e_edge_kwh = edge_energy_J(k) / 3.6e6
    e_net_kwh = net_energy_J(k) / 3.6e6
    e_cloud_kwh = cloud_energy_J(k, region) / 3.6e6
    return (e_edge_kwh * EDGE_CI_GCO2_PER_KWH
            + e_net_kwh * NET_CI_GCO2_PER_KWH
            + e_cloud_kwh * region['CI_now'])
    # E_equip and E_orch terms omitted -- see ASSUMPTIONS in docstring.

def select_split_latency_first(bandwidth_mbps):
    feasible = [(k, rname) for k in range(L) for rname in regions]
    best = min(feasible, key=lambda kr: latency_ms(kr[0], kr[1], bandwidth_mbps))
    return best

WEIGHTS_BASE = dict(lat=0.15, carb=0.55, priv=0.15, therm=0.15)
THERM_ESCALATION_MARGIN_C = 4.0
THERM_ESCALATION_CAP = 0.80
DVFS_POWER_MULTIPLIER = 0.8 ** 3
C_TH, R_TH, T_SAFE, T_CRITICAL, DT_FORECAST_S = 3.0, 7.0, 35.0, 42.0, 1.0
R0, R1, R2, K_SOC = 0.05, 0.15, 0.02, 4.0
T_REF, I_DISCHARGE_A, V_crit = 25.0, 1.2, 3.0
P_IDLE_W, SIM_DURATION_S, STEP_S = 1.5, 60.0, 0.05

def r_int(soc, t_device):
    return R0 + R1 * np.exp(-K_SOC * soc) + R2 * max(0.0, T_REF - t_device)

def p_batt(soc, t_device):
    return I_DISCHARGE_A ** 2 * r_int(soc, t_device)

def dynamic_weights(t_device):
    excess = np.clip((t_device - (T_SAFE - THERM_ESCALATION_MARGIN_C))
                      / THERM_ESCALATION_MARGIN_C, 0.0, 1.0)
    w_therm = WEIGHTS_BASE['therm'] + excess * (THERM_ESCALATION_CAP - WEIGHTS_BASE['therm'])
    remaining = 1.0 - w_therm
    scale = remaining / (1.0 - WEIGHTS_BASE['therm'])
    return dict(lat=WEIGHTS_BASE['lat'] * scale,
                carb=WEIGHTS_BASE['carb'] * scale,
                priv=WEIGHTS_BASE['priv'] * scale,
                therm=w_therm)

def normalise(values):
    vmin, vmax = min(values), max(values)
    span = vmax - vmin
    if span < 1e-9:
        return [0.0 for _ in values]
    return [(v - vmin) / span for v in values]

def forecast_temp(k, t_device, t_amb, soc):
    p_gen = p_compute(k) + p_batt(soc, t_device)
    dTdt = (p_gen - (t_device - t_amb) / R_TH) / C_TH
    return t_device + DT_FORECAST_S * dTdt

def thermal_penalty(k, t_device, t_amb, soc):
    s_hat = forecast_temp(k, t_device, t_amb, soc)
    return max(0.0, s_hat - T_SAFE) ** 2

def select_split_active(bandwidth_mbps, t_device, t_amb, soc):
    weights = dynamic_weights(t_device)
    feasible = [(k, rname) for k in range(L) if k not in PRIV_ZONE
                for rname in regions]
    raw_lat = [latency_ms(k, r, bandwidth_mbps) for k, r in feasible]
    raw_carb = [carbon_gco2(k, r, bandwidth_mbps) for k, r in feasible]
    raw_therm = [thermal_penalty(k, t_device, t_amb, soc) for k, r in feasible]
    n_lat = normalise(raw_lat)
    n_carb = normalise(raw_carb)
    n_therm = normalise(raw_therm)

    best = None
    best_J = float('inf')
    for i, (k, r) in enumerate(feasible):
        J = (weights['lat'] * n_lat[i] + weights['carb'] * n_carb[i]
             + weights['priv'] * P_priv(k) + weights['therm'] * n_therm[i])
        if J < best_J:
            best_J = J
            best = (k, r)

    k_sel, r_sel = best
    s_hat = forecast_temp(k_sel, t_device, t_amb, soc)
    dvfs_multiplier = DVFS_POWER_MULTIPLIER if s_hat >= T_SAFE else 1.0
    return k_sel, r_sel, dvfs_multiplier

def _integrate_step(t_device, soc, p_active, t_amb, dt):
    p_gen = p_active + p_batt(soc, t_device)
    dTdt = (p_gen - (t_device - t_amb) / R_TH) / C_TH
    return t_device + dt * dTdt

PASS_MI_THRESHOLD = 0.15

def select_split_carbon_aware_greedy(bandwidth_mbps):
    r_star = min(regions, key=lambda r: regions[r]['CI_now'])
    k_star = min(range(L), key=lambda k: latency_ms(k, r_star, bandwidth_mbps))
    return k_star, r_star

def select_split_privacy_aware_static():
    for k in range(L):
        if P_priv(k) <= PASS_MI_THRESHOLD:
            k_star = k
            break
    else:
        k_star = L - 1
    r_star = min(regions, key=lambda r: regions[r]['rtt_ms'])
    return k_star, r_star

def select_split_proposed(bandwidth_mbps, t_device, t_amb, soc):
    k, r, _ = select_split_active(bandwidth_mbps, t_device, t_amb, soc)
    return k, r

STRATEGIES = ['local_only', 'latency_first', 'carbon_aware_greedy',
              'privacy_aware_static', 'proposed_active']

def decide(strategy, bandwidth, t_device, t_amb, soc):
    if strategy == 'local_only':
        return L - 1, None
    if strategy == 'latency_first':
        return select_split_latency_first(bandwidth)
    if strategy == 'carbon_aware_greedy':
        return select_split_carbon_aware_greedy(bandwidth)
    if strategy == 'privacy_aware_static':
        return select_split_privacy_aware_static()
    if strategy == 'proposed_active':
        return select_split_proposed(bandwidth, t_device, t_amb, soc)
    raise ValueError(strategy)

N_TRIALS = 50

def run_experiment():
    results = {s: dict(carbon=[], latency=[], priv_violation=0, k_hist=[])
               for s in STRATEGIES}

    for trial in range(N_TRIALS):
        bandwidth = float(rng.lognormal(mean=np.log(10.0), sigma=0.5))
        t_init = float(rng.uniform(28, 36))
        t_amb = float(rng.uniform(22, 30))
        soc = float(rng.uniform(0.2, 1.0))

        for s in STRATEGIES:
            k, r = decide(s, bandwidth, t_init, t_amb, soc)
            r_for_cost = r if r is not None else 'IN-South'
            results[s]['carbon'].append(carbon_gco2(k, r_for_cost, bandwidth))
            results[s]['latency'].append(
                latency_ms(k, r_for_cost, bandwidth) if r is not None else edge_time_ms(k))
            results[s]['k_hist'].append(k)
            if k in PRIV_ZONE:
                results[s]['priv_violation'] += 1

    return results

def sustained_throttle_generic(strategy, t_init, t_amb, soc, bandwidth, step_s=0.05):
    t_device = t_init
    elapsed = 0.0
    throttled = False
    max_temp = t_device
    duration_s = 60.0

    fixed_kr = None
    if strategy == 'latency_first':
        fixed_kr = select_split_latency_first(bandwidth)
    elif strategy == 'carbon_aware_greedy':
        fixed_kr = select_split_carbon_aware_greedy(bandwidth)
    elif strategy == 'privacy_aware_static':
        fixed_kr = select_split_privacy_aware_static()

    while elapsed < duration_s and not throttled:
        dvfs_mult = 1.0
        if strategy == 'local_only':
            k, r = L - 1, None
        elif strategy == 'proposed_active':
            k, r, dvfs_mult = select_split_active(bandwidth, t_device, t_amb, soc)
        else:
            k, r = fixed_kr

        r_for_cost = r if r is not None else 'IN-South'
        cycle_ms = latency_ms(k, r_for_cost, bandwidth) if r is not None else edge_time_ms(k)
        active_s = edge_time_ms(k) / 1000.0
        idle_s = max(0.0, cycle_ms / 1000.0 - active_s)
        active_power = p_compute(k) * dvfs_mult

        t_remaining = active_s
        while t_remaining > 0 and not throttled and elapsed < duration_s:
            dt = min(step_s, t_remaining)
            t_device = _integrate_step(t_device, soc, active_power, t_amb, dt)
            max_temp = max(max_temp, t_device)
            if t_device >= T_CRITICAL:
                throttled = True
            t_remaining -= dt
            elapsed += dt

        t_remaining = idle_s
        while t_remaining > 0 and not throttled and elapsed < duration_s:
            dt = min(step_s, t_remaining)
            t_device = _integrate_step(t_device, soc, P_IDLE_W, t_amb, dt)
            max_temp = max(max_temp, t_device)
            if t_device >= T_CRITICAL:
                throttled = True
            t_remaining -= dt
            elapsed += dt

    return throttled, max_temp

if __name__ == '__main__':
    res = run_experiment()
    local_carbon_ref = float(np.mean(res['local_only']['carbon']))

    throttle_rng = np.random.default_rng(99)
    throttle_counts = {s: 0 for s in STRATEGIES}
    for trial in range(N_TRIALS):
        bandwidth = float(throttle_rng.lognormal(mean=np.log(10.0), sigma=0.5))
        t_init = float(throttle_rng.uniform(28, 36))
        t_amb = float(throttle_rng.uniform(22, 30))
        soc = float(throttle_rng.uniform(0.2, 1.0))
        for s in STRATEGIES:
            throttled, _ = sustained_throttle_generic(s, t_init, t_amb, soc, bandwidth)
            throttle_counts[s] += int(throttled)

    print(f"{'Strategy':<22}{'MeanLat(ms)':>13}{'Carbon(gCO2)':>14}{'Carbon(norm%)':>15}{'PrivViol%':>11}{'ModeSplit':>11}{'Throttle%':>11}")
    for s in STRATEGIES:
        r = res[s]
        mean_lat = np.mean(r['latency'])
        mean_carbon_abs = np.mean(r['carbon'])
        norm_carbon = 100.0 * mean_carbon_abs / local_carbon_ref
        priv_viol_pct = 100.0 * r['priv_violation'] / N_TRIALS
        mode_k = int(np.bincount(r['k_hist']).argmax())
        throttle_pct = 100.0 * throttle_counts[s] / N_TRIALS
        print(f"{s:<22}{mean_lat:>13.1f}{mean_carbon_abs:>14.6f}{norm_carbon:>15.1f}{priv_viol_pct:>11.1f}{mode_k:>11d}{throttle_pct:>11.1f}")
