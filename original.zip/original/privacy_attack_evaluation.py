"""
Privacy attack evaluation for the DP-protected transmitted activation
(Eq. 10, main.tex): a_hat = clip_C(a) + Laplace(0, Delta_f/eps_r),
Delta_f = 2C (Eq. 13).

Three attacks, matched to the mechanism actually used in the paper:
  (A) Reconstruction attack -- exact, mechanism-level analysis of what
      a single-shot attacker can recover from one noisy transmission.
  (B) Membership-inference bound -- analytic MI-advantage bound implied
      by eps-DP (Yeom et al. 2018), evaluated at both the per-inference
      budgets and the T=60-composed RDP budgets from Table 1 (Sec 4.6).
  (C) Feature-inversion / class-identity attack -- an attacker trains a
      nearest-centroid classifier to recover which of K synthetic
      activation clusters produced a noisy transmission, as a function
      of eps_r. Real ImageNet-pretrained MobileNetV2 weights are not
      reachable in this sandbox (no external image-dataset or
      model-weight host on the network allowlist), so clusters are
      synthetic: signal is confined to a d_eff-dim informative subspace
      of the d=1280 activation, consistent with the strong post-ReLU
      channel sparsity reported for MobileNetV2 activations, with the
      remaining channels at baseline. This is a controlled proxy for
      "how much class-identifying signal survives the noise", not a
      claim about literal pixel/image reconstruction.
"""
import numpy as np

rng = np.random.default_rng(0)

d = 1280
d_eff = 24          # informative subspace size (sparse-activation proxy)
C = 1.0             # clipping norm (Eq. 12), normalised
delta_f = 2 * C     # Eq. 13
eps_regions = {"EU-West": 1.0, "US-East/IN-South": 0.5}
T = 60
composed_rdp = {"EU-West": 48.6, "US-East/IN-South": 21.9}  # from Table 1

print("="*72)
print("(A) Reconstruction attack: single-shot noisy transmission")
print("="*72)
print("Noise scale b = Delta_f/eps_r = 2C/eps_r is compared directly to the")
print("clip norm C -- both are ell_1-scale quantities, so b/C is exact and")
print("architecture/dimension-independent:\n")
n_trials = 20000
a = rng.uniform(-1, 1, size=(n_trials, d))
a = a / np.linalg.norm(a, ord=1, axis=1, keepdims=True) * C
for label, eps in eps_regions.items():
    b = delta_f / eps
    noise = rng.laplace(0, b, size=(n_trials, d))
    a_hat = a + noise
    cos_sim = np.sum(a_hat * a, axis=1) / (np.linalg.norm(a_hat, axis=1) * np.linalg.norm(a, axis=1))
    print(f"{label} (eps_r={eps}): b/C = {b/C:.1f}x   "
          f"mean cosine sim(noisy transmission, true clipped activation) = {cos_sim.mean():.4f} "
          f"(sd {cos_sim.std():.4f})")

print()
print("="*72)
print("(B) Membership-inference advantage bound (Yeom et al. 2018):")
print("    Adv_MI <= (e^eps - 1)/(e^eps + 1)")
print("="*72)
def mi_bound(eps):
    return (np.exp(eps) - 1) / (np.exp(eps) + 1)

for label, eps in eps_regions.items():
    per_query = mi_bound(eps)
    composed = mi_bound(composed_rdp[label])
    print(f"{label}: per-inference eps_r={eps:>3} -> Adv_MI <= {per_query:.3f} ({per_query*100:.1f}%)")
    print(f"{' '*len(label)}  composed (T={T}, RDP) eps={composed_rdp[label]:>5} -> "
          f"Adv_MI <= {composed:.3f} ({composed*100:.1f}%, i.e. vacuous)")

print()
print("="*72)
print("(C) Feature-inversion / class-identity attack (synthetic proxy)")
print("="*72)
K = 10
n_per_cluster = 400
sig = rng.uniform(-1, 1, size=(K, d_eff))
sig = sig / np.linalg.norm(sig, axis=1, keepdims=True)  # unit-norm, well-separated directions

def sample_cluster_data(sig, n_per_cluster, spread=0.08):
    X, y = [], []
    for k in range(K):
        sub = sig[k] + rng.normal(0, spread, size=(n_per_cluster, d_eff))
        full = np.zeros((n_per_cluster, d))
        full[:, :d_eff] = sub
        # renormalise the whole (mostly-zero) vector onto the L1 clip ball, as the real
        # transmitted activation would be after Eq. 12
        full = full / np.linalg.norm(full, ord=1, axis=1, keepdims=True) * C
        X.append(full); y.append(np.full(n_per_cluster, k))
    return np.vstack(X), np.concatenate(y)

X, y = sample_cluster_data(sig, n_per_cluster)
centroids = np.stack([X[y == k].mean(axis=0) for k in range(K)])

def nearest_centroid_acc(X, y, centroids, eps):
    b = delta_f / eps
    noisy = X + rng.laplace(0, b, size=X.shape)
    d2 = ((noisy[:, None, :] - centroids[None, :, :]) ** 2).sum(-1)
    pred = d2.argmin(axis=1)
    return (pred == y).mean()

eps_sweep = [0.1, 0.25, 0.5, 1.0, 2.0, 5.0, 1e6]
print(f"{'eps':>10} | attack accuracy (K={K} classes, chance={1/K:.3f})")
for eps in eps_sweep:
    acc = nearest_centroid_acc(X, y, centroids, eps)
    tag = ("  <- US-East/IN-South op. point" if abs(eps-0.5) < 1e-9 else
           "  <- EU-West op. point" if abs(eps-1.0) < 1e-9 else
           "  <- no-DP ceiling" if eps == 1e6 else "")
    print(f"{eps:>10.3g} | {acc:.3f}{tag}")
