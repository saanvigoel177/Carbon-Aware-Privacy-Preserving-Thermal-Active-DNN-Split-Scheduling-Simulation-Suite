"""
Reconstructed AWC (Adaptive Weight Controller) simulation and
hyperparameter-sensitivity ablation sweep, for Section 4.6.1
("Hyperparameter Sensitivity of the AWC", sec:awc-ablation) of main.tex.

RECALIBRATION NOTE (v3)
-------------------------
Plugging in the real tensor sizes/privacy step-function with CC.ipynb's
literal constant-5W edge power produced a degenerate result: 0.00
cumulative excess-over-target everywhere in the sweep, because constant
edge power makes edge energy (-> carbon) monotonic in the same
direction as edge time (-> latency), so both objectives are minimised
by the same split and the AWC never has anything to correct. Per user
direction, CLOUD_W_PER_MS was retuned upward (0.02 -> 15.0) to reflect
that cloud/datacenter inference draws far more absolute power per ms
than a mobile edge chip, and HEAT_SCALE retuned alongside it. This is
value selection to restore a *plausible* trade-off structure -- it is
not derived from any profiled number in CC.ipynb or main.tex, and is
flagged here rather than presented as measured.

RECALIBRATION NOTE (v2)
------------------------
The user-provided notebook CC.ipynb does NOT contain the AWC
multiplicative-weights controller (no eta, no adaptive weight update,
no ablation/sensitivity code) -- it implements a different, much
simpler single-scalar latency-bias adaptation over 5 trials. It cannot
validate or replace this ablation. It DOES, however, contain:
  (a) real per-layer profiling of an actual torchvision MobileNetV2
      (19 feature layers, indices 0-18, matching this script's L=18),
      giving real (not synthetic) transmitted-tensor sizes per split
      layer, and
  (b) concrete, literal definitions for several quantities this script
      previously had to invent from scratch: a step-function privacy
      penalty (100 if k<4, 10 if 4<=k<11, else 0), a constant 5W
      edge-device power assumption, and heat generation as a linear
      function of cumulative compute load (0.5x factor).
This version recalibrates the previously-synthetic tensor-size and
privacy-penalty profiles using those real/concrete values (see
"RECALIBRATED FROM CC.ipynb" comments below). Per-layer *edge compute
time* in CC.ipynb is itself just a placeholder linear function of
layer index (not derived from real profiling), so this script keeps
its own monotonic-increasing synthetic edge-time profile for that
piece rather than adopting CC.ipynb's placeholder.

IMPORTANT / HONESTY NOTE
-------------------------
The original supplementary simulation notebook referenced in the paper
(footnote at sec:awc-eval, "Section 2: Adaptive Weight Controller (AWC)
Evaluation") was not included in the files provided to produce this
script, and CC.ipynb is confirmed not to be it (see above). This
remains a *reconstruction* built directly from the equations and
parameter values stated in main.tex:

  - Unified cost J(k,r;w)                         Eq. (eq:J)
  - Min-max per-cycle normalisation                Eq. (eq:norm)
  - Latency decomposition                          Eq. (eq:latency)
  - Carbon decomposition                           Eq. (eq:carbon)
  - Privacy soft penalty P(k)                       Eq. (eq:priv)
  - Thermal forecast s_hat(k) / penalty T(k)        Eq. (eq:sforecast),(eq:thermal)
  - AWC multiplicative-weights update               Eq. (eq:mwu)
  - Scenario: EU-West carbon spike (180->650 gCO2/kWh, cycles 70-110)
    + thermal excursion (ambient -> 34C, cycles 120-160), 200 cycles,
    Z_priv = {0,1,2,3}, T_safe = 35.0C.               (sec:awc-eval)

Two things the paper text does NOT give numerically and that this
script had to assume, clearly flagged here rather than hidden:

  1. Concrete weight vectors for the three static presets other than
     Environmental Priority (only w_env = (0.15, 0.55, 0.15, 0.15) is
     given explicitly). This script uses the same "0.55 on the
     favoured objective, 0.15 on the other three" pattern for Latency
     Priority, Privacy Priority and Thermal Safety, by direct analogy.
  2. The exact per-layer edge-time/energy/tensor-size/heat-generation
     profiles (these come from offline device profiling in the real
     system and are not reproducible without that hardware data). This
     script uses monotonic synthetic profiles with the qualitative
     shape the paper describes (edge time/energy increasing in k,
     transfer time/energy and P(k) decreasing in k, forecast temperature
     increasing in k), consistent in spirit with how
     privacy_attack_evaluation.py already handles the ImageNet-weights
     gap for the privacy attacks.

Consequence: the absolute numbers below (e.g. cumulative excess
totals) are NOT expected to reproduce the 137.7 / 25.07 / 7.03 figures
already sitting in main.tex, which came from a different, unavailable
reconstruction. Section main.tex will need to be corrected to whatever
this script actually finds -- see README block printed at the end of
this file's output for the specific numbers to swap in.
"""
import numpy as np

# ----------------------------------------------------------------------
# Static system model
# ----------------------------------------------------------------------
L = 18                      # deepest layer index
Z_PRIV = {0, 1, 2, 3}       # hard exclusion zone
K_CANDIDATES = [k for k in range(L + 1) if k not in Z_PRIV]  # 4..18, 15 options
T_SAFE = 35.0
DT = 1.0                    # control interval, seconds
C_TH = 18.0                 # thermal capacitance (synthetic, tuned so a
R_TH = 3.2                  #  200-cycle scenario crosses T_safe plausibly)

REGIONS = {
    # name: (RTT ms, bandwidth Mbps, cloud compute factor, cloud PUE)
    "EU-West": dict(rtt=180.0, bw=50.0, compute=1.00, pue=1.10),
    "US-East/IN-South": dict(rtt=60.0, bw=80.0, compute=1.15, pue=1.35),
}
REGION_NAMES = list(REGIONS.keys())

# Per-layer synthetic profiles (index 0..18), monotonically shaped as
# described qualitatively in the paper (edge cost/heat increasing with
# depth processed on-device; transferred-tensor size decreasing with
# depth due to spatial downsampling dominating channel growth).
rng_profile = np.random.default_rng(42)
_layer_growth = np.linspace(0.8, 2.7, L + 1)
EDGE_MS_PER_LAYER = _layer_growth + rng_profile.normal(0, 0.03, L + 1)  # kept synthetic; CC.ipynb's own
                                                                          # edge-time formula is a placeholder
                                                                          # linear-in-index term, not real profiling
EDGE_W_PER_LAYER = np.full(L + 1, 5.0)  # RECALIBRATED FROM CC.ipynb: constant 5W mobile-inference assumption
                                        # (cell 3/5: "Assuming 5W for mobile inference")

# RECALIBRATED FROM CC.ipynb cell 0: real torchvision MobileNetV2 (19 feature
# layers, weights=None since pretrained weights aren't reachable on this
# sandbox's network allowlist -- shapes/sizes are weight-independent) output
# tensor sizes in MB per split layer k=0..18, converted to KB.
_REAL_DATA_SIZE_MB = np.array([
    1.5312, 0.7656, 0.2871, 0.2871, 0.0957, 0.0957, 0.0957, 0.0479, 0.0479,
    0.0479, 0.0479, 0.0718, 0.0718, 0.0718, 0.0299, 0.0299, 0.0299, 0.0598,
    0.2393,
])
TENSOR_KB_AT = _REAL_DATA_SIZE_MB * 1024.0
REMAINING_FLOPS_MS_AT = np.flip(np.cumsum(np.flip(_layer_growth))) * 0.9  # cloud work left after split
CLOUD_W_PER_MS = 15.0  # RETUNED: cloud/datacenter inference draws far more absolute power per ms than
                        # the edge chip even though CC.ipynb's 5W-constant edge assumption made edge
                        # energy dominate at low CLOUD_W, collapsing the latency/carbon trade-off (see
                        # RECALIBRATION NOTE v3 below); this value restores a genuine tension where
                        # carbon favours deep splits (cloud-heavy, less own edge energy) while latency
                        # stays roughly flat/mildly mid-favouring, instead of both favouring shallow k.

DOWNLINK_MS = 2.0
ENERGY_PER_BIT_UJ = 0.06  # microjoules per kB, synthetic radio energy factor


def edge_time_ms(k):
    return float(np.sum(EDGE_MS_PER_LAYER[: k + 1]))


def edge_energy_mj(k):
    # power (W, constant 5W per CC.ipynb) integrated over per-layer time (ms) -> mJ, summed across layers 0..k
    return float(np.sum(EDGE_W_PER_LAYER[: k + 1] * EDGE_MS_PER_LAYER[: k + 1]))


def transfer_time_ms(k, region):
    r = REGIONS[region]
    return r["rtt"] + (TENSOR_KB_AT[k] * 8.0) / (r["bw"] * 1000.0) * 1000.0


def transfer_energy_mj(k):
    return TENSOR_KB_AT[k] * ENERGY_PER_BIT_UJ / 1000.0


def cloud_time_ms(k, region):
    r = REGIONS[region]
    return REMAINING_FLOPS_MS_AT[k] / r["compute"]


def cloud_energy_mj(k, region):
    r = REGIONS[region]
    return CLOUD_W_PER_MS * cloud_time_ms(k, region) * r["pue"]


# RECALIBRATED FROM CC.ipynb cell 0/2: real per-layer "comp_load" =
# output.nelement()*1e-6 (note: in CC.ipynb this is proportional to
# output tensor size, not real FLOPs -- a known conflation in that
# notebook, kept here only because the user asked to recalibrate
# against its real numbers, not to silently fix its modelling choice),
# cumulative across layers 0..k, and cell 2's heat_generated =
# compute_load * 0.5.
_REAL_COMP_LOAD = _REAL_DATA_SIZE_MB * (0.000001 / (4 / 1024 / 1024))  # comp_load = nelement*1e-6; data_size_mb = nelement*4/1024/1024
_REAL_CUM_COMP_LOAD = np.cumsum(_REAL_COMP_LOAD)
HEAT_SCALE = 6.0  # RETUNED alongside CLOUD_W_PER_MS (see note above) so the thermal excursion
                   # (ambient -> 34C, cycles 120-160) can still plausibly push forecast device
                   # temperature past T_safe=35C for deep, edge-heavy splits


def heat_gen_w(k):
    # on-device heat generation this cycle if split at k, per CC.ipynb
    # cell 2's heat_generated = compute_load * 0.5, using the real
    # cumulative compute load at split k and rescaled to this sim's units
    return float(HEAT_SCALE * 0.5 * _REAL_CUM_COMP_LOAD[k])


def privacy_penalty(k):
    # RECALIBRATED FROM CC.ipynb cells 3/5: literal step-function privacy
    # cost (100 if k<4 [excluded by Z_priv anyway], 10 if 4<=k<11, else 0),
    # normalised to [0,1]
    if k < 4:
        return 1.0
    elif k < 11:
        return 0.10
    else:
        return 0.0


def latency_raw_ms(k, region):
    return edge_time_ms(k) + transfer_time_ms(k, region) + cloud_time_ms(k, region) + DOWNLINK_MS


def carbon_raw_g(k, region, ci_gco2_per_kwh):
    energy_mj = edge_energy_mj(k) + transfer_energy_mj(k) + cloud_energy_mj(k, region)
    energy_kwh = energy_mj / 3.6e9  # mJ -> kWh
    return energy_kwh * ci_gco2_per_kwh * 1000.0  # back to a workable gCO2-ish scale for this sim


# ----------------------------------------------------------------------
# Scenario: 200-cycle carbon-spike (EU-West) + thermal-excursion run
# ----------------------------------------------------------------------
N_CYCLES = 200


def carbon_intensity(region, t):
    if region == "EU-West":
        base = 180.0
        if 70 <= t <= 110:
            return 650.0
        return base
    else:
        return 450.0  # baseline for the higher-carbon region, per paper's framing of EU-West as "normally lowest-carbon"


def ambient_temp(t):
    return 34.0 if 120 <= t <= 160 else 24.0


# ----------------------------------------------------------------------
# Presets (assumption #1 above: only Environmental Priority is given
# explicit numbers in the paper; the other three follow the same
# 0.55/0.15/0.15/0.15 pattern by direct analogy)
# ----------------------------------------------------------------------
PRESETS = {
    "Environmental Priority": np.array([0.15, 0.55, 0.15, 0.15]),
    "Latency Priority": np.array([0.55, 0.15, 0.15, 0.15]),
    "Privacy Priority": np.array([0.15, 0.15, 0.55, 0.15]),
    "Thermal Safety": np.array([0.15, 0.15, 0.15, 0.55]),
}
OBJ_NAMES = ["lat", "carb", "priv", "therm"]


def run_scenario(weights_init, adaptive, eta, tau, w_min, w_max, seed, n_cycles=N_CYCLES):
    """Run one 200-cycle scenario. Returns cumulative excess-over-target
    (summed over 4 objectives x n_cycles) and the final weight vector."""
    rng = np.random.default_rng(seed)
    w = weights_init.astype(float).copy()
    w = w / w.sum()
    T_device = 24.0  # start at baseline ambient
    cum_excess = 0.0
    tau_vec = np.full(4, tau)

    for t in range(n_cycles):
        amb = ambient_temp(t)

        # score every feasible (k, region) candidate
        raw_lat, raw_carb, raw_therm, raw_priv = [], [], [], []
        cand = []
        for k in K_CANDIDATES:
            s_hat = T_device + (DT / C_TH) * (heat_gen_w(k) - (T_device - amb) / R_TH)
            therm_pen = max(0.0, s_hat - T_SAFE) ** 2
            for region in REGION_NAMES:
                lat = latency_raw_ms(k, region) * (1 + rng.normal(0, 0.02))
                ci = carbon_intensity(region, t)
                carb = carbon_raw_g(k, region, ci) * (1 + rng.normal(0, 0.02))
                cand.append((k, region, lat, carb, therm_pen, privacy_penalty(k)))
                raw_lat.append(lat)
                raw_carb.append(carb)
                raw_therm.append(therm_pen)
                raw_priv.append(privacy_penalty(k))

        raw_lat, raw_carb, raw_therm = map(np.array, (raw_lat, raw_carb, raw_therm))
        lo_lat, hi_lat = raw_lat.min(), raw_lat.max()
        lo_carb, hi_carb = raw_carb.min(), raw_carb.max()
        lo_therm, hi_therm = raw_therm.min(), raw_therm.max()
        delta = 1e-9

        best_J, best = None, None
        best_hat = None
        for (k, region, lat, carb, therm_pen, priv) in cand:
            hat_lat = (lat - lo_lat) / (hi_lat - lo_lat + delta)
            hat_carb = (carb - lo_carb) / (hi_carb - lo_carb + delta)
            hat_therm = (therm_pen - lo_therm) / (hi_therm - lo_therm + delta)
            J = w[0] * hat_lat + w[1] * hat_carb + w[2] * priv + w[3] * hat_therm
            if best_J is None or J < best_J:
                best_J = J
                best = (k, region)
                best_hat = np.array([hat_lat, hat_carb, priv, hat_therm])

        # excess-over-target losses at the chosen action
        excess = np.maximum(0.0, best_hat - tau_vec)
        cum_excess += excess.sum()

        # actual thermal update (feedback), using the chosen split's heat gen
        k_star, region_star = best
        T_device = T_device + (DT / C_TH) * (heat_gen_w(k_star) - (T_device - amb) / R_TH)

        if adaptive:
            w_tilde = w * np.exp(eta * excess)
            w = w_tilde / w_tilde.sum()
            w = np.clip(w, w_min, w_max)
            w = w / w.sum()

    return cum_excess, w


# ----------------------------------------------------------------------
# Sanity check: reproduce the base scenario (single point, eta=3,
# tau=0.30, Environmental-Priority start) for both static and AWC
# ----------------------------------------------------------------------
print("=" * 78)
print("Sanity check: base scenario, static preset vs AWC (eta=3, tau=0.30)")
print("=" * 78)
w0 = PRESETS["Environmental Priority"]
static_excess, _ = run_scenario(w0, adaptive=False, eta=3, tau=0.30, w_min=0.05, w_max=0.85, seed=0)
awc_excess, w_final = run_scenario(w0, adaptive=True, eta=3, tau=0.30, w_min=0.05, w_max=0.85, seed=0)
print(f"Static preset cumulative excess-over-target: {static_excess:.2f}")
print(f"AWC cumulative excess-over-target:            {awc_excess:.2f}")
if static_excess > 0:
    print(f"Reduction: {100*(1 - awc_excess/static_excess):.1f}%")
print(f"AWC final weights: lat={w_final[0]:.3f} carb={w_final[1]:.3f} priv={w_final[2]:.3f} therm={w_final[3]:.3f}")
print("(Not expected to match 25.07/7.03/72.0% in main.tex -- different, unavailable")
print(" original reconstruction; this is a fresh one built from the stated equations.)\n")

# ----------------------------------------------------------------------
# Sweep 1: eta x tau grid, 3 seeds each, AWC only, Environmental-Priority start
# ----------------------------------------------------------------------
ETAS = [0.25, 0.5, 1, 1.5, 2, 3, 5, 8]
TAUS = [0.20, 0.25, 0.30, 0.35, 0.40]
SEEDS = [0, 1, 2]

print("=" * 78)
print("Sweep 1: eta x tau grid (AWC), 3 seeds each")
print("=" * 78)
grid = np.zeros((len(ETAS), len(TAUS)))
for i, eta in enumerate(ETAS):
    for j, tau in enumerate(TAUS):
        vals = [
            run_scenario(w0, adaptive=True, eta=eta, tau=tau, w_min=0.05, w_max=0.85, seed=s)[0]
            for s in SEEDS
        ]
        grid[i, j] = np.mean(vals)
    print(f"eta={eta:>4}: " + "  ".join(f"tau={t:.2f}->{grid[i,j]:.2f}" for j, t in enumerate(TAUS)))

# static baseline, averaged over same 3 seeds (weights fixed, independent of eta/tau)
static_vals = [run_scenario(w0, adaptive=False, eta=0, tau=0.30, w_min=0.05, w_max=0.85, seed=s)[0] for s in SEEDS]
static_baseline = float(np.mean(static_vals))
print(f"\nStatic preset baseline (avg over 3 seeds): {static_baseline:.2f}")

best_idx = np.unravel_index(np.argmin(grid), grid.shape)
best_eta, best_tau = ETAS[best_idx[0]], TAUS[best_idx[1]]
print(f"Best (eta, tau) in this grid: eta={best_eta}, tau={best_tau} -> {grid[best_idx]:.2f}")
paper_point = grid[ETAS.index(3), TAUS.index(0.30)]
print(f"Paper operating point (eta=3, tau=0.30): {paper_point:.2f}")

# ----------------------------------------------------------------------
# Sweep 2: clip-bound sensitivity at (eta, tau) = (3, 0.30)
# ----------------------------------------------------------------------
print("\n" + "=" * 78)
print("Sweep 2: clip-bound (w_min, w_max) sensitivity at eta=3, tau=0.30")
print("=" * 78)
CLIP_BOUNDS = [(0.05, 0.85), (0.15, 0.60), (0.02, 0.95)]
for wmin, wmax in CLIP_BOUNDS:
    vals = [run_scenario(w0, adaptive=True, eta=3, tau=0.30, w_min=wmin, w_max=wmax, seed=s)[0] for s in SEEDS]
    print(f"(w_min, w_max)=({wmin}, {wmax}): mean cumulative excess = {np.mean(vals):.2f}")

# ----------------------------------------------------------------------
# Sweep 3: starting-preset sensitivity, at eta=3 and at best-performing eta
# ----------------------------------------------------------------------
print("\n" + "=" * 78)
print(f"Sweep 3: starting-preset sensitivity at eta=3 and eta={best_eta} (tau=0.30)")
print("=" * 78)
for label, eta_test in [("paper's eta=3", 3), (f"best-performing eta={best_eta}", best_eta)]:
    print(f"\n-- {label} --")
    results = {}
    for preset_name, w_init in PRESETS.items():
        vals = [run_scenario(w_init, adaptive=True, eta=eta_test, tau=0.30, w_min=0.05, w_max=0.85, seed=s)[0] for s in SEEDS]
        results[preset_name] = np.mean(vals)
        print(f"  start={preset_name:<24} mean cumulative excess = {results[preset_name]:.2f}")
    spread = max(results.values()) - min(results.values())
    print(f"  spread across starting presets: {spread:.2f}")

print("\n" + "=" * 78)
print("README FOR MANUSCRIPT UPDATE")
print("=" * 78)
print(f"""
This reconstruction's actual numbers (use these to replace the ones
currently in sec:awc-ablation, or clearly re-label the existing prose
as illustrative/unverified until reconciled):

  Static-preset baseline:              {static_baseline:.2f}
  Paper operating point (eta=3,t=.30): {paper_point:.2f}
  Best (eta, tau) in this grid:        eta={best_eta}, tau={best_tau} -> {grid[best_idx]:.2f}

A figure (fig11_awc_ablation_RECONSTRUCTED.png) has been generated
from `grid` -- swap it in for fig11_awc_ablation.pdf only after you
decide whether to keep this reconstruction's numbers or source the
original notebook.
""")

# ----------------------------------------------------------------------
# Figure: cumulative excess-over-target vs eta, one line per tau,
# star marking the paper's operating point (eta=3, tau=0.30)
# ----------------------------------------------------------------------
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

fig, ax = plt.subplots(figsize=(6, 4.2))
for j, tau in enumerate(TAUS):
    ax.plot(ETAS, grid[:, j], marker="o", label=f"tau={tau:.2f}")
ax.axhline(static_baseline, color="k", linestyle="--", linewidth=1, label=f"static baseline ({static_baseline:.1f})")
ax.scatter([3], [grid[ETAS.index(3), TAUS.index(0.30)]], marker="*", s=250, color="red", zorder=5,
           label="paper operating point (eta=3, tau=0.30)")
ax.set_xscale("log")
ax.set_xlabel("learning rate eta (log scale)")
ax.set_ylabel("cumulative excess-over-target (200 cycles)")
ax.set_title("AWC hyperparameter sensitivity (reconstructed simulation)")
ax.legend(fontsize=7, loc="upper left")
fig.tight_layout()
fig.savefig("/home/claude/files_extracted/fig11_awc_ablation_RECONSTRUCTED.pdf")
fig.savefig("/home/claude/files_extracted/fig11_awc_ablation_RECONSTRUCTED.png", dpi=150)
print("Saved fig11_awc_ablation_RECONSTRUCTED.pdf/.png")
