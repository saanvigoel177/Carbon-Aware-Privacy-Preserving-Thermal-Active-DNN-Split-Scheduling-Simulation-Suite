# -*- coding: utf-8 -*-
"""Assemble the revised main.tex from the submitted main.tex plus code-generated numbers.
Usage (repo root):  python paper/build_main.py <old_main.tex> <out_main.tex>
Every number in the new tables and text comes from results/*.json / results/*.txt; claims about the data
are asserted below so that the build fails if the results change."""
import os, re, sys, json
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
old = open(sys.argv[1], encoding='utf-8').read()
R = json.load(open(os.path.join(ROOT, 'results', 'results.json')))
X = json.load(open(os.path.join(ROOT, 'results', 'extra.json')))
PT = json.load(open(os.path.join(ROOT, 'results', 'privacy_ttest.json')))
TS = json.load(open(os.path.join(ROOT, 'results', 'thermal_sensitivity.json')))
AS = json.load(open(os.path.join(ROOT, 'results', 'awc_study.json')))
PR = json.load(open(os.path.join(ROOT, 'results', 'privacy_real.json')))
PI = json.load(open(os.path.join(ROOT, 'results', 'privacy_imagenet.json')))
sweep = open(os.path.join(ROOT, 'results', 'awc_ablation_sweep.txt')).read()
ext = open(os.path.join(ROOT, 'results', 'awc_extended.txt')).read()
dp = open(os.path.join(ROOT, 'results', 'dp_composition.txt')).read()
atk = open(os.path.join(ROOT, 'results', 'privacy_attacks.txt')).read()

T9, T11, SENS = R['table9'], R['table11'], R['sensitivity']
N = R['n_trials']
ORDER = ['local_only', 'local_dvfs', 'latency_first', 'carbon_greedy', 'privacy_static', 'proposed']
NAMES = {'local_only': 'Local-Only', 'local_dvfs': 'Local + DVFS', 'latency_first': 'Latency-First',
         'carbon_greedy': 'Carbon-Aware Greedy (CAG)', 'privacy_static': 'Privacy-Aware Static (PASS)', 'proposed': r'\textbf{Proposed}'}

# ------------------------------------------------------------------ parse the original scripts' printed outputs
num = r'([-\d.]+)'
pol = {}
for m in re.finditer(r'^(static|awc|pareto|thermal_only|rl)\s+cum_excess=\s*' + num + r'\s+switches=\s*' + num + r'\s+lat_SLO_violations=\s*' + num + r'/200', ext, re.M):
    pol[m.group(1)] = dict(excess=float(m.group(2)), switches=float(m.group(3)), slo_n=float(m.group(4)))
for m in re.finditer(r'^(static|awc|pareto|thermal_only|rl)\s+lat p50=\s*' + num + r'ms\s+p95=\s*' + num + r'ms\s+p99=\s*' + num + r'ms.*?\(' + num + r'%\)', ext, re.M):
    pol[m.group(1)].update(p50=float(m.group(2)), p95=float(m.group(3)), p99=float(m.group(4)), slo_pct=float(m.group(5)))
assert set(pol) == {'static', 'awc', 'pareto', 'thermal_only', 'rl'} and all('p99' in v for v in pol.values())
acct = dict(compute=float(re.search(r'Compute carbon \(edge\+cloud\):\s+' + num, ext).group(1)),
            net=float(re.search(r'Network-equipment carbon \(added\):\s+' + num, ext).group(1)),
            net_pct=float(re.search(r'\(' + num + r'% of total\)', ext).group(1)),
            total=float(re.search(r'Total \(compute\+network\):\s+' + num, ext).group(1)),
            eu_share=float(re.search(r'EU-West\s+' + num + r'\s+\(' + num + r'%\)', ext).group(2)))
noise = {float(m.group(1)): float(m.group(2)) for m in re.finditer(r'sigma=' + num + r': total carbon =\s+' + num, ext)}
static_sw = float(re.search(r'Static preset baseline \(avg over 3 seeds\):\s+' + num, sweep).group(1))
awc_sw = float(re.search(r'Paper operating point \(eta=3, tau=0\.30\):\s+' + num, sweep).group(1))
clip = [float(m.group(1)) for m in re.finditer(r'mean cumulative excess = ' + num + r'\n', sweep)][:3]
spreads = [float(m.group(1)) for m in re.finditer(r'spread across starting presets: ' + num, sweep)]
grid = {float(k): v for k, v in R['awc_grid'].items()}
taus = [0.20, 0.25, 0.30, 0.35, 0.40]
assert all(min(grid[e][i] for e in grid if e <= 1) < grid[3.0][i] for i in range(5)), 'eta<=1 must beat eta=3 at every tau'
assert all(grid[3.0][i] > grid[3.0][i + 1] for i in range(4)), 'violation must fall as tau relaxes'
assert pol['pareto']['excess'] < pol['awc']['excess'] < pol['rl']['excess'] < pol['static']['excess']
assert pol['rl']['slo_n'] == 0.0 and pol['pareto']['slo_pct'] < 1.0
assert X['proposed_equals_local_dvfs_per_trial'] and T9['proposed']['mode_k'] == 18 and T9['proposed']['mode_k_share'] == 1.0
assert all(T9[s]['priv_viol_trials_n'] == 0 for s in ('proposed', 'local_only', 'local_dvfs', 'privacy_static'))
assert T9['latency_first']['priv_viol_trials_n'] == T9['carbon_greedy']['priv_viol_trials_n'] == 8
assert R['landscape']['k_star'] == 14 and R['zone_violations_proposed_E4'] == 0
assert abs(abs(PT['1.0']['t']) - 1.66) < 0.01
assert X['proposed_equals_local_dvfs_per_trial'], 'proposed must equal Local+DVFS except for the orchestrator carbon'
_tm = AS['test']; _env = _tm['static_mm:Environmental Priority']; _aw = _tm['awc_mm:paper(3,0.30)']; _mx = _tm['awc_mix:paper(3,0.30)']; _mt = _tm['awc_mix:tuned(3.0,0.4)']
assert AS['validation_vs_original']['max_abs_diff'] < 1e-9
assert _aw['E_ref_mean'] > 3 * _env['E_ref_mean'] and _aw['E_mm_mean'] < _env['E_mm_mean'] and _aw['clip_share'] > 0.8, 'paper AWC: saturates, worse on fixed scale, better on own metric'
assert _mt['E_ref_mean'] < 0.5 * _env['E_ref_mean'] and AS['winrate']['awc_mix:tuned(3.0,0.4)']['vs_env_static'] > 0.75
assert _mx['hot_cycles'] > 0.95 * _env['hot_cycles'], 'AWC-mix gives no thermal benefit'
_cc = AS['concurrency']; assert _cc['awc_mix_paper']['3']['mean_excess_per_cycle'] > _cc['static_mm_env']['3']['mean_excess_per_cycle']
assert TS['joint_mc']['share_draws_dvfs_lower'] == 1.0
_pk = PR['by_k']; _cl = PR['clean_acc']['test']
for _k, _r in _pk.items():
    for _e in ('0.5', '1.0'):
        assert _r['eps'][_e]['acc'] < 0.15 and _r['eps'][_e]['class_attack_acc'] < 0.15, (_k, _e)
    assert all(v['lr_test_advantage'] > 0.95 for e, v in _r['eps'].items() if v['acc'] >= 0.9 * _cl)
_pi = PI['by_k']; _pic = PI['clean_top1_test']
for _k, _r in _pi.items():
    for _e in ('1.0', '10.0'):
        assert _r['eps'][_e]['top1'] < 0.02 and _r['eps'][_e]['reid_acc'] < 0.02 and _r['eps'][_e]['recon_corr'] < PI['recon_baseline_mean_image']['corr'], (_k, _e)
    _ok = [e for e, v in _r['eps'].items() if v['top1'] >= 0.9 * _pic]
    assert _ok and all(_r['eps'][e]['reid_acc'] == 1.0 and _r['eps'][e]['lr_test_advantage'] > 0.99 for e in _ok), _k
    assert float(min(_ok, key=float)) >= 3e4, _k
dpv = [float(x) for x in re.findall(r'eps_total = ([\d.]+)', dp)]
assert dpv == [60.0, 140.27, 48.64, 30.0, 38.05, 21.92], dpv

f1 = lambda x: f"{x:.1f}"
cmp_ = {s: T9[s] for s in ORDER}
lat_pc = lambda s: T9[s]['lat_mean']
carb = lambda s: T9[s]['carbon_pct']
thr = lambda s: T9[s]['throttle_pct']
rB, rA = R['routing_modelB'], R['routing_modelA']
sp_lo, sp_hi = min(x['potential_pct'] for x in SENS), max(x['potential_pct'] for x in SENS)
offl = [carb(s) / 100 for s in ('latency_first', 'carbon_greedy', 'privacy_static')]
red_lo = 100 * (1 - carb('proposed') / min(carb(s) for s in ('latency_first', 'carbon_greedy', 'privacy_static')))
red_hi = 100 * (1 - carb('proposed') / max(carb(s) for s in ('latency_first', 'carbon_greedy', 'privacy_static')))
thr_others = [thr(s) for s in ('local_only', 'latency_first', 'carbon_greedy', 'privacy_static')]
cv = R['convergence']; ld = R['landscape']['J_by_k']
dm = X['decision_ms_median']; dm95 = X['decision_ms_p95']
cl = {k: PT[k] for k in PT}


def sci(x):
    m, e = f"{x:.1e}".split('e'); return f"{m}\\times10^{{{int(e)}}}"


# ------------------------------------------------------------------ tables
def tab_carbon():
    return "\n".join(f"{NAMES[s]} & {T9[s]['carbon_pct']:.1f} $\\pm$ {T9[s]['carbon_sd']:.1f} & [{T9[s]['carbon_ci'][0]:.1f}, {T9[s]['carbon_ci'][1]:.1f}] \\\\" for s in ORDER)


def tab_summary():
    return "\n".join(f"{NAMES[s]} & {T9[s]['lat_mean']:.1f} $\\pm$ {T9[s]['lat_sd']:.1f} & {T9[s]['carbon_pct']:.1f} & {T9[s]['priv_viol_trials_pct']:.1f} & "
                     f"{T9[s]['throttle_pct']:.1f} [{T9[s]['throttle_ci'][0]:.1f}, {T9[s]['throttle_ci'][1]:.1f}] \\\\" for s in ORDER)


def tab_thermal():
    return "\n".join(f"{NAMES[s]} & {T9[s]['throttle_n']}/{N} & {T9[s]['throttle_pct']:.1f} & [{T9[s]['throttle_ci'][0]:.1f}, {T9[s]['throttle_ci'][1]:.1f}] \\\\" for s in ORDER)


def tab_sens():
    return "\n".join(f"{x['net_kwh_per_gb']:g} & {x['cloud_w']:g} & {x['ci_edge']:g} & {x['potential_pct']:.1f} & {x['best_offload_vs_local_pct']:.0f} \\\\" for x in SENS)


def tab_gen():
    rows = []
    for n, v in T11.items():
        free = f"{v['k_mode_free']} (local)" if v['local_share_free'] > 0.99 else f"{v['k_mode_free']} (earliest feasible)"
        rows.append(f"{n} & {v['L']} & {v['zone_end']} & {free} & {v['k_mode']} & {v['offload_vs_local_pct']:.0f} & {v['potential_pct']:.1f} \\\\")
    return "\n".join(rows)


def tab_pol():
    lab = dict(static='Static', awc='AWC', pareto='Pareto', thermal_only='Thermal-only', rl='RL (tabular)')
    return "\n".join(f"{lab[k]} & {v['excess']:.2f} & {v['switches']:.1f} & {v['slo_pct']:.1f} & {v['p50']:.1f} & {v['p95']:.1f} & {v['p99']:.1f} \\\\"
                     for k, v in pol.items())


def tab_equip():
    return "\n".join(f"{e['gamma']:g} & {e['equip_share_of_offload_pct']:.1f} & {e['offload_vs_local_x']:.1f} & {e['potential_pct']:.2f} \\\\" for e in R['equip_sweep'])


def tab_thermsens():
    lab = dict(C_TH=r'$C_{\mathrm{th}}$ (J/K)', R_TH=r'$R_{\mathrm{th}}$ (K/W)', AMB_SHIFT='ambient shift (K)', BATT_SCALE=r'battery resistance $\times$', DVFS='DVFS frequency step $f$')
    rows = []
    for k, d in TS['one_at_a_time'].items():
        vals = list(d)
        rows.append(f"{lab[k]} & {', '.join(f'{float(v):g}' for v in vals)} & {', '.join(f'{d[v]['local_dvfs']['pct']:.0f}' for v in vals)} & {', '.join(f'{d[v]['local_only']['pct']:.0f}' for v in vals)} \\\\")
    return "\n".join(rows)


def tab_privreal():
    r = _pk['14']['eps']; rows = []
    for e in ('0.5', '1.0', '2.0', '10.0', '100.0', '300.0', '1000.0', '10000.0', '100000.0'):
        v = r[e]; ef = float(e); bound = 'vacuous' if ef > 20 else f"{100 * v['dp_bound']:.0f}"
        rows.append(f"{ef:g} & {100 * v['acc']:.1f} & {100 * v['class_attack_acc']:.1f} & {v['recon_corr']:.2f} & {100 * v['lr_test_advantage']:.0f} & {bound} \\\\")
    return "\n".join(rows)


def tab_privimg():
    r = _pi['14']['eps']; rows = []
    for e in ('1.0', '10.0', '100.0', '1000.0', '10000.0', '30000.0', '100000.0', '1000000.0'):
        v = r[e]; ef = float(e); bound = 'vacuous' if ef > 20 else f"{100 * v['dp_bound']:.0f}"
        rows.append(f"{ef:g} & {100 * v['top1']:.1f} & {100 * v['top1_denoised']:.1f} & {100 * v['reid_acc']:.1f} & {v['recon_corr']:.2f} & {100 * v['lr_test_advantage']:.0f} & {bound} \\\\")
    return "\n".join(rows)


def tab_privimg_k():
    rows = []
    for k in ('4', '8', '14', '17'):
        r = _pi[k]; e1 = r['eps']['1000.0']
        n90 = min(float(e) for e, v in r['eps'].items() if v['top1'] >= 0.9 * _pic)
        nd = [float(e) for e, v in r['eps'].items() if v['top1_denoised'] >= 0.9 * _pic]
        rp = r['repeat']['1.0']
        rows.append(f"{k} & {r['d']:,} & {n90:g} & {(f'{min(nd):g}' if nd else 'none')} & {100 * e1['reid_acc']:.0f} & {100 * rp['1000000']['reid_acc']:.0f} & {100 * rp['10000']['reid_acc']:.1f} \\\\".replace(',', '{,}'))
    return "\n".join(rows)


def tab_awcheld():
    rows = [('Static, Environmental preset', 'static_mm:Environmental Priority'), ('AWC as in the original formulation $(3,0.30)$', 'awc_mm:paper(3,0.30)'),
            ('AWC, fixed-scale excess $(3,0.30)$', 'awc_mix:paper(3,0.30)'), ('AWC, fixed-scale excess, tuned $(3,0.40)$', 'awc_mix:tuned(3.0,0.4)'),
            ('AWC, fixed scale in $J$ and excess $(3,0.30)$', 'awc_ref:paper(3,0.30)')]
    return "\n".join(f"{n} & {AS['test'][k]['E_ref_mean']:.2f} & {AS['test'][k]['E_mm_mean']:.1f} & {AS['test'][k]['hot_cycles']:.1f} & {AS['test'][k]['lat']:.0f} & {AS['test'][k]['tv']:.3f} & {100 * AS['test'][k]['clip_share']:.0f} \\\\" for n, k in rows)


# ------------------------------------------------------------------ text pieces
ABSTRACT = r'''Edge deployment of deep neural networks (DNNs) offers low-latency inference, but choosing where to split a network between a device and the cloud becomes difficult when latency, carbon emissions, privacy and device thermal state must be balanced together. This study proposes an adaptive spatio-temporal framework that selects the split layer and cloud region by minimising a normalised four-term cost under a hard privacy exclusion zone, with an Adaptive Weight Controller (AWC), current and forecast carbon intensity, Laplace noise on transmitted activations, a forward thermal--battery model and a DVFS safeguard. We evaluate it in simulation on MobileNetV2 in a three-region setting and extend the decision model to ResNet-50, ViT-Base and the CLIP ViT-B/32 image encoder. Under our energy model, in which the network-path energy intensity (0.05~kWh/GB) and the embodied-carbon factor are assumed rather than measured, offloading a lightweight CNN is carbon-costly: latency-first, carbon-greedy and privacy-static splitting emit @@OFFLO@@--@@OFFHI@@$\times$ the carbon of on-device execution, so the proposed objective keeps MobileNetV2 on the device under carbon priority. Over @@N@@ sustained-load trials it then behaves as local execution with DVFS: it emits @@PCARB@@\,\% of the carbon of unmanaged local execution and has no privacy-zone violations, against 4\,\% for baselines without the zone. Its throttle rate (@@PTHR@@\,\% at the nominal assumed thermal parameters) is not robust: it ranges from 0 to 100\,\% over plausible thermal parameters, although DVFS lowers throttling in every parameter draw. The benefit of carbon-aware region routing when offloading is forced ranges from @@SPLO@@ to @@SPHI@@\,\% across the unmeasured constants. On a pretrained ImageNet MobileNetV2 and 1{,}000 real ImageNet images, Laplace noise at the operating budgets ($\epsilon_r\le10$) makes the cloud half classify at chance as well as the attacker; the accuracy-preserving budgets ($\epsilon_r\approx@@PI_EMIN@@$--@@PI_EMAX@@) give an adversary with a 1{,}000-image gallery perfect re-identification and a vacuous differential-privacy bound, so the hard exclusion zone, not the noise, provides the utility-preserving protection. The AWC reduces excess over its targets on its original scenario, but on unseen randomised disturbances its original min--max formulation saturates, and a variant with fixed-scale targets is stable but gives only a modest, tuning-dependent gain and no thermal benefit. All results are simulated; validation on physical edge devices is required.'''

INTRO_GREEN = r'''Practitioner guidance on building green software recognises this as a concern, recommending that distributed systems be carbon-intensity-aware at the scheduling layer~\citep{mckinsey2021green}.'''

RW_21 = r'''
More recent partitioning systems continue to optimise for latency alone.
\citet{ghosh2024partnner} propose PArtNNer, a platform-agnostic partitioning algorithm that adapts the split point to temporally varying bandwidth and cloud load without device-specific profiling; its adaptivity is driven by an end-to-end latency objective, with no carbon, thermal or privacy term in its formulation. \citet{ding2024resource} broaden the objective with a resource-aware partitioning scheme for privacy-sensitive edge--cloud systems that folds a privacy cost into the split decision; their privacy treatment is one term in a resource-aware cost function rather than the structurally separate hard-zone-plus-differential-privacy mechanism used here (Section~\ref{sec:framework}), and, like PArtNNer, it does not address carbon or thermal cost. \citet{cheng2025privacy} jointly optimise model deployment, user--server association and partition point under an explicit privacy constraint; their objective is delay under that constraint rather than a jointly weighted multi-objective cost, and it likewise has no carbon or thermal term.

'''

RW_22 = r'''For split inference specifically, the literature on carbon awareness
is sparse.  Prior work~\citep{kang2017neurosurgeon,hu2019dynamic} treats
cloud energy as a black box, ignoring the carbon intensity of the grid
powering each region.  Closer to this paper's goal, \citet{ke2024carboncp} propose CarbonCP, a conformal-prediction-based partitioning framework that targets carbon emissions alongside latency and edge battery consumption, evaluated on a physical Jetson-Nano-plus-GPU-server testbed.  CarbonCP's carbon formulation applies a single scalar carbon intensity to the summed edge, transmission and server energy; in a single-node deployment this simplification is less consequential than it would be for a system, like the one proposed here, that chooses between regions with materially different grid intensity, which is why Section~\ref{sec:carbonmodel} prices each segment with its own intensity.  CarbonCP does not address privacy or the sustained-thermal-load case.  The proposed framework addresses the multi-region gap by embedding live
$\mathrm{CI}(r,t)$ signals from grid carbon APIs into the split-point
selection decision at inference time.  The one-hour look-ahead forecast
further enables temporal shifting analogous to the workload-level
deferral studied by \citet{wiesner2021lets}.
'''

RW_24 = r'''\subsection{Privacy-Preserving Edge--Cloud Systems in Adjacent Domains}

A related line of work applies privacy-preserving federated learning to intrusion detection in the internet of vehicles (IoV), a setting that shares this paper's tension between transmitting informative representations and limiting what an adversary can reconstruct from them. \citet{heidari2026flite} train a lightweight detector on the vehicle under federated learning so that raw telemetry never leaves the device, with an energy-aware scheduler deciding which vehicles participate; this is an edge-side selection problem under joint privacy, energy and communication constraints, although it optimises detection performance and communication cost rather than carbon or thermal safety, and its privacy mechanism acts on federated model updates rather than per-inference activations. \citet{heidari2026survey} survey the wider design space of privacy preservation in the IoV. In both cases the underlying question, deciding what to compute locally versus what to transmit under a privacy budget, is the one this paper addresses for DNN partitioning.

'''

SEC_42 = r'''\subsection{Carbon Emission Model}
\label{sec:carbonmodel}

The carbon cost of a split configuration is a \emph{mass of CO$_2$}. It is obtained by pricing the energy of each segment with that segment's own carbon intensity and adding the amortised embodied carbon of the networking equipment that carries the tensor. The edge device draws power from whatever grid it is installed on, which has no necessary relationship to the region the optimiser routes to; applying $\mathrm{CI}(r,t)$ to the edge segment would rescale edge carbon whenever the cloud region changes and could bias the split choice. We therefore write
\begin{align}
C_{\mathrm{carb}}(k,r) ={} & \frac{1}{\kappa}\Bigl[E_{\mathrm{edge}}(0{:}k)\,\mathrm{CI}_{\mathrm{edge}}
   + E_{\mathrm{net}}(k)\,\mathrm{CI}_{\mathrm{net}}
   + E_{\mathrm{cloud}}(k{+}1{:}L,\,r)\,\mathrm{CI}(r,t)
   + E_{\mathrm{orch}}\,\mathrm{CI}_{\mathrm{edge}}\Bigr] \notag\\
   & {}+ C_{\mathrm{equip}}(k),
\qquad C_{\mathrm{equip}}(k)=\gamma_{\mathrm{equip}}\,\frac{B(k)}{2^{30}},
\label{eq:carbon}
\end{align}
where $\kappa=3.6\times10^{6}$~J/kWh converts energy to kWh and $B(k)$ is the number of transmitted bytes. Table~\ref{tab:units} gives the unit of every term. All $E$ terms are energies and are multiplied by an intensity; $C_{\mathrm{equip}}$ is already a mass of CO$_2$ (the embodied carbon of the equipment divided by the traffic it carries over its life, $\gamma_{\mathrm{equip}}$ in gCO$_2$ per GB, times the data volume~\citep{gupta2021chasing}) and is therefore \emph{not} multiplied by a carbon intensity. $\mathrm{CI}(r,t)$ is fetched from a grid carbon API (e.g., Electricity Maps, WattTime) before each decision~\citep{wiesner2021lets} and applies only to the cloud term, the only segment whose location the optimiser chooses. $\mathrm{CI}_{\mathrm{edge}}$ is a deployment-time constant (the grid the device is installed on) and $\mathrm{CI}_{\mathrm{net}}$ is a fixed blended intensity of the network path. $E_{\mathrm{orch}}=P_{\mathrm{orch}}\,t_{\mathrm{dec}}$ is the energy of the orchestrator on the edge device for one decision cycle.

\begin{table}[t]
\centering
\caption{Units of the terms of Eq.~(\ref{eq:carbon}) and the values used in the experiments (all values other than the energies are assumptions).}
\label{tab:units}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{llll}
\toprule
Symbol & Meaning & Unit & Value used \\
\midrule
$E_{\mathrm{edge}},E_{\mathrm{net}},E_{\mathrm{cloud}},E_{\mathrm{orch}}$ & segment energies & J & computed \\
$\mathrm{CI}_{\mathrm{edge}},\mathrm{CI}_{\mathrm{net}},\mathrm{CI}(r,t)$ & grid carbon intensities & gCO$_2$/kWh & 720, 442, Table~\ref{tab:regions} \\
$\gamma_{\mathrm{equip}}$ & amortised embodied carbon per GB carried & gCO$_2$/GB & 2 (swept 0--20) \\
$P_{\mathrm{orch}}$, $t_{\mathrm{dec}}$ & orchestrator power, time per decision & W, ms & 4, 0.5 \\
$B(k)$ & transmitted data & bytes & tensor size \\
$C_{\mathrm{equip}}(k)$, $C_{\mathrm{carb}}(k,r)$ & carbon per inference & gCO$_2$ & computed \\
\bottomrule
\end{tabular}}
\end{table}

\paragraph{Energy terms used in the experiments.} Edge energy is the sum over blocks $0..k$ of modelled active power times block time. Network energy is the transmitted bytes times a network-path energy intensity of $0.05$~kWh/GB. Cloud energy is the cloud server power (300~W) times the remote compute time times a PUE of 1.2. The constants $0.05$~kWh/GB, 300~W, $\mathrm{CI}_{\mathrm{edge}}=720$, $\mathrm{CI}_{\mathrm{net}}=442$~gCO$_2$/kWh, $\gamma_{\mathrm{equip}}=2$~gCO$_2$/GB (against $0.05\times442=22.1$~gCO$_2$/GB of operational network carbon), $P_{\mathrm{orch}}=4$~W and $t_{\mathrm{dec}}=0.5$~ms are \emph{assumptions}, not measurements: $\mathrm{CI}_{\mathrm{net}}$ is of the order of recent global power-sector averages~\citep{iea2025electricity}, $\mathrm{CI}_{\mathrm{edge}}$ places the device on the IN-South grid, $t_{\mathrm{dec}}$ is the decision time measured in our simulator (0.4--0.8~ms depending on the machine, Section~\ref{sec:algorithm}), and the network-path intensity, server power and embodied-carbon factor are modelling choices that must be measured or cited for a deployment. The orchestrator term is charged only to the proposed framework (the baselines fix their split in advance and do not run a per-cycle optimisation); at @@ORCG@@~g per cycle it is @@ORCPCT@@\,\% of the carbon of an on-device inference. Because the conclusions depend on the other constants, Section~\ref{sec:carbon} reports sensitivity sweeps over the network intensity, server power, edge-grid intensity and $\gamma_{\mathrm{equip}}$.

Fig.~\ref{fig:energy} shows the resulting energy by split layer for MobileNetV2. Under these constants network energy dominates for shallow splits, where the transmitted tensor is largest, and edge energy dominates for deep splits, so that every offloaded configuration emits more carbon than on-device execution (Section~\ref{sec:carbon}).

\begin{figure}[t]
  \centering
  \includegraphics[width=\columnwidth]{fig1_energy_distribution.pdf}
  \caption{Modelled energy per inference by split layer for MobileNetV2 (stacked, logarithmic scale). The dashed line marks the split selected by the proposed objective under carbon priority (layer 18, i.e.\ no offloading).}
  \label{fig:energy}
\end{figure}

'''

FIG4_TXT = r'''Fig.~\ref{fig:carbon24h} illustrates the mechanism with a synthetic carbon-intensity profile: the green band
marks a period where EU-West is predicted to drop by
40\,gCO$_2$/kWh, making deferral the clearly preferable choice for
a latency-tolerant workload.  The look-ahead threshold $\tau$ is
configurable per application; tighter real-time budgets use larger
$\tau$ to limit deferral probability.  Deferral is a design feature that is not exercised in the experiments of Section~\ref{sec:experiments}.

\begin{figure}[t]
  \centering
  \includegraphics[width=\columnwidth]{fig4_carbon_24h.pdf}
  \caption{Synthetic illustration of 24-hour regional carbon-intensity profiles (not measured data, and no selection result is implied). The green band
    marks a look-ahead window in which a
    $\Delta\mathrm{CI}=40\,\mathrm{gCO_2/kWh}$ drop is predicted,
    enabling proactive scheduling.}
  \label{fig:carbon24h}
\end{figure}
'''

SEC_44 = r'''\subsection{Privacy Penalty and Risk Zone}
\label{sec:privacy}

Privacy enforcement operates at two levels that interact but do not substitute for each other. The soft penalty is motivated by the layer-wise mutual information $I(\mathbf{a}_k;\mathbf{x})$ between the activation at layer $k$ and the raw input~\citep{tishby2017deep,osia2020hybrid}, which is non-increasing with depth in a feed-forward network by the data-processing inequality. \emph{This study does not estimate $I(\mathbf{a}_k;\mathbf{x})$ from data.} We use a monotone proxy normalised to $[0,1]$ over the candidate layers,
\begin{equation}
P(k) = \frac{e^{-s\,d_k} - e^{-s}}{1 - e^{-s}}, \qquad d_k = \frac{k}{L-1},\quad s = 6.3,
\label{eq:priv}
\end{equation}
so that $P(k)\to 1$ for shallow splits and $P(k)\to 0$ for the deepest, with $L$ the index of the last block. Replacing the proxy with calibration-set mutual-information estimates is future work.

The hard constraint is defined by a rule rather than a fixed index list: $\mathcal{Z}_{\mathrm{priv}}=\{k: P(k)\ge 0.30\}$. For the 19-block MobileNetV2 this gives $\{0,1,2,3\}$; for the 12--16-block architectures of Section~\ref{sec:generalisation} it gives $\{0,1,2\}$. The constraint removes these layers from the feasible set before the optimiser runs, so the soft penalty never has to ``win'' against a latency or carbon gradient that favours a shallow split. Fig.~\ref{fig:privacy} shows the proxy penalty and the real tensor size by layer.

\begin{figure}[t]
  \centering
  \includegraphics[width=\textwidth]{fig6_privacy_risk.pdf}
  \caption{Modelled privacy penalty $P(k)$ (left) and transmitted tensor size from the real MobileNetV2 profile (right). The shaded region marks $\mathcal{Z}_{\mathrm{priv}}=\{0,1,2,3\}$.}
  \label{fig:privacy}
\end{figure}

\subsubsection{Threat model}
The mechanisms are designed against a \emph{passive, computationally unbounded} adversary who observes the transmitted tensor $\tilde{\mathbf{a}}_k$ on the path between the device and the cloud region (a malicious network operator, a man-in-the-middle on an untrusted link, or the cloud provider itself; the destination is not assumed trusted). The adversary has no white-box access to the on-device layers $0{:}k$, does not control the device, and sees only the tensor and its metadata (split layer, region, timestamp). Side-channel adversaries (power or timing analysis on the device) and colluding-endpoint adversaries are out of scope and would require additional protections such as secure enclaves. The empirical attacks of Section~\ref{sec:attacks} assume exactly this adversary.

'''

SEC_45_TAIL = r'''This gives an $\epsilon$-differential-privacy guarantee for a single transmission~\citep{dwork2014algorithmic} that complements the structural exclusion zone. The sensitivity $\Delta f$ is obtained by clipping, as specified in Section~\ref{sec:dpcomp}, not from a layer-wise Lipschitz analysis. The accuracy cost of the noise and its effect on attacks are measured on a trained network in Section~\ref{sec:attacks}(D): at the budgets $\epsilon_r\in\{0.5,1.0\}$ used as operating points, the noisy activation is as useless to the cloud as it is to an attacker, so these budgets are a privacy-first setting rather than a deployable one, and the operator must choose $\epsilon_r$ from the measured utility--privacy trade-off.

'''

SEC_46 = r'''\subsection{Sensitivity, Adjacency and Budget Composition}
\label{sec:dpcomp}

Eq.~(\ref{eq:dp}) leaves open how $\Delta f$ is bounded, over which pairs of inputs the guarantee holds, and what happens to $\epsilon_r$ over repeated inferences.

\paragraph{Clipping and sensitivity.} An unclipped activation has unbounded sensitivity. Every transmitted activation is therefore clipped to an $\ell_1$ ball before noise injection,
\begin{equation}
\hat{\mathbf{a}}_k = \mathbf{a}_k \cdot \min\!\left(1, \frac{C_k}{\|\mathbf{a}_k\|_1}\right),
\label{eq:clip}
\end{equation}
with $C_k$ a clipping norm chosen on a calibration set (a fixed percentile of $\|\mathbf{a}_k\|_1$, as in DP-SGD~\citep{abadi2016deep}). The Laplace mechanism is calibrated to $\ell_1$ sensitivity, and the triangle inequality gives the worst-case bound
\begin{equation}
\Delta f_k=\sup_{x,x'}\|\hat{\mathbf{a}}_k(x)-\hat{\mathbf{a}}_k(x')\|_1\le 2C_k .
\label{eq:sens}
\end{equation}

\paragraph{Adjacency.} The guarantee protects one device's own request, so the relevant notion is local differential privacy: for every pair $x,x'$ in the whole input domain $\mathcal{X}$ (not pairs differing in one record) and every measurable set $S$,
\begin{equation}
\Pr[M(x)\in S]\le e^{\epsilon_r}\Pr[M(x')\in S].
\label{eq:ldp}
\end{equation}
This is a substantially stronger requirement than neighbouring-database adjacency, and it is why the worst-case, clipping-derived bound of Eq.~(\ref{eq:sens}) is used rather than a data-dependent one.

\paragraph{Composition.} A device issues a sequence of $T$ inferences, each spending $\epsilon_r$. We compare three rules for the same Laplace mechanism: basic composition, $T\epsilon_r$~\citep{dwork2014algorithmic}; advanced composition~\citep{dwork2010boosting}, $\bigl(\epsilon_r\sqrt{2T\ln(1/\delta')}+T\epsilon_r(e^{\epsilon_r}-1),\,\delta'\bigr)$-DP; and R\'enyi-DP composition~\citep{mironov2017renyi}, where the Laplace mechanism with scale $b_k=\Delta f_k/\epsilon_r$ has
\begin{equation}
\epsilon^{\mathrm{RDP}}(\alpha)=\frac{1}{\alpha-1}\log\!\left(\frac{\alpha}{2\alpha-1}e^{(\alpha-1)\Delta f_k/b_k}+\frac{\alpha-1}{2\alpha-1}e^{-\alpha\Delta f_k/b_k}\right),
\label{eq:rdp}
\end{equation}
which adds across the $T$ queries at fixed $\alpha$ and is converted to $(\epsilon,\delta)$-DP by $\epsilon=T\epsilon^{\mathrm{RDP}}(\alpha)+\ln(1/\delta')/(\alpha-1)$, minimised over $\alpha$~\citep{mironov2017renyi}.

\paragraph{Numerical evaluation.} Each simulated stream issues $T=60$ queries (one per 1~s decision cycle). Table~\ref{tab:dpcomp} reports the composed budgets at $\delta'=10^{-5}$, with $\alpha$ searched over $[1.01,64)$ in steps of $0.01$. RDP composition is the tightest (19--27\,\% below basic and 42--65\,\% below advanced composition). Advanced composition is \emph{looser} than basic composition at both operating budgets, a property of that bound, which only improves on basic composition in the small-$\epsilon$, large-$T$ regime. Even the tightest composed guarantee ($\epsilon^{\mathrm{RDP}}\approx 21.9$--$48.6$ over one 60-second stream) is far weaker than the per-inference $\epsilon_r\in\{0.5,1.0\}$ suggests and would degrade further over a longer session. The per-inference budgets reported elsewhere in this paper must therefore be read as per-transmission budgets, not session-level guarantees.

\begin{table}[t]
\centering
\caption{Composed end-to-end privacy budget over $T=60$ sequential queries ($\delta'=10^{-5}$ for the approximate-DP rules).}
\label{tab:dpcomp}
\begin{tabular}{lccc}
\toprule
$\epsilon_r$ (per query) & Basic ($T\epsilon_r$) & Advanced & R\'enyi-DP (optimal $\alpha$) \\
\midrule
1.0 (EU-West) & 60.0 & 140.3 & 48.6 ($\alpha^*{=}2.06$) \\
0.5 (US-East / IN-South) & 30.0 & 38.1 & 21.9 ($\alpha^*{=}2.70$) \\
\bottomrule
\end{tabular}
\end{table}

'''

SEC_472 = r'''\subsubsection{Calibration procedure and prediction horizon}
\label{sec:calib}

In this study $(C_{\mathrm{th}},R_{\mathrm{th}})$ and $(R_0,R_1,R_2,k_{\mathrm{soc}})$ are literature-informed constants, not values fitted to measurements; per-block power, timing and tensor-size figures are modelling assumptions. Replacing them with device-specific values requires: (1) \emph{thermal-capacitance identification}: apply a step in sustained load at fixed split with DVFS disabled and record $T_{\mathrm{device}}(t)$; the thermal model of Eq.~(\ref{eq:thermalode}) predicts an exponential approach with time constant $\tau=C_{\mathrm{th}}R_{\mathrm{th}}$, so $R_{\mathrm{th}}$ follows from the steady-state rise per watt and $C_{\mathrm{th}}$ from the fitted time constant; (2) \emph{battery internal-resistance identification}: apply known discharge-current pulses at a grid of temperatures and states of charge, read $R_{\mathrm{int}}$ from the voltage drop, and fit Eq.~(\ref{eq:rint}) by non-linear least squares~\citep{chen2021liion}; (3) \emph{forecast validation}: hold out contiguous trajectories and report the one-step-ahead error $|\hat{s}(k)-T_{\mathrm{device}}(t+\Delta t)|$ rather than only in-sample fit; (4) \emph{DVFS transition dynamics}: the single Euler step treats $P_{\mathrm{compute}}$ as constant over $\Delta t$, which is reasonable when frequency transitions are short relative to the second-scale $\Delta t$ used here, and must be revisited for substantially shorter control intervals. These steps belong to a hardware-calibration study and are outside the scope of this simulation-only work; the thermal results are therefore reported only as a sensitivity analysis (Section~\ref{sec:thermsens}), not as device predictions.

'''

DVFS_NEW = r'''The frequency reduction also lowers local throughput: in the simulator a 20\,\% frequency cut lengthens on-device compute time by a factor $1/0.8$ and scales power by $0.8^3$, so energy per inference scales by $0.8^2=0.64$. The split is re-evaluated every cycle, but in the reported experiments the DVFS action did not by itself trigger a shift of layers to the cloud; whether it should is a policy choice that we leave for future work.

The DVFS step size (20\%) is chosen as a fixed, conservative
compromise rather than the learned, jointly-optimised CPU/GPU schedule
of \citet{kim2021ztt}'s zTT; adopting a
learned step size in place of the fixed 20\% is a
natural refinement (the residual throttling in sustained load reported in
Section~\ref{sec:thermal} is consistent with this fixed step being
insufficient in warm ambient conditions).'''

SEC_5_PATCH = (r'''For MobileNetV2
with 19 blocks, 15 of them feasible after the privacy zone, and 3 candidate regions, this is $2 \times 45 = 90$
scalar evaluations per cycle, each involving only arithmetic over
pre-fetched values.  In our Python simulator one decision takes about @@DM@@\,ms (median over 300 calls; @@DM95@@\,ms at the 95th percentile) on a general-purpose CPU; we have not measured it on an embedded core.
The hard constraint is applied when the feasible set is built, so
excluded layers never enter either pass.''')

SEC_6 = r'''\section{Experimental Validation}
\label{sec:experiments}

\subsection{Experimental Setup}
\label{sec:setup}

\paragraph{Scope.} All results are simulations. Per-block power, timing and tensor sizes, the energy constants of Section~\ref{sec:carbonmodel}, and the thermal and battery parameters are modelling assumptions, not hardware measurements. The code that produces every table and figure in this section is supplied with the paper (Data Availability Statement). The AWC study of Section~\ref{sec:awc-eval} uses a separate, reduced model and is labelled as such.

\paragraph{Model profile.} MobileNetV2~\citep{sandler2018mobilenetv2} is profiled at the granularity of its 19 torchvision feature blocks (an initial convolution, 17 inverted-residual blocks and a final $1\times1$ convolution). Tensor sizes (4~bytes per element) and multiply--accumulate counts are computed analytically from the architecture definition; per-block tensor sizes are identical to the output of torchvision's \texttt{mobilenet\_v2} and the per-block MAC counts agree with PyTorch's FLOP counter (total 301 versus 299~MMAC; the difference is the classifier head). The transmitted tensor shrinks from 1568~KB (block 0) to 30.6~KB (blocks 14--16), and the final block outputs 245~KB; the model has 0.30~GMAC. The edge device is calibrated so that executing all blocks takes 450~ms; per-block active power is $4.0\pm0.15$~W with 1.5~W idle power. The cloud executes 500~MMAC/ms. Region parameters are in Table~\ref{tab:regions}; the reliability column is not used by the simulator. The remaining energy constants are those of Section~\ref{sec:carbonmodel}.

\begin{table}[t]
\centering
\caption{Cloud region configuration and carbon forecast.}
\label{tab:regions}
\begin{tabular}{lcccc}
\toprule
Region & $\mathrm{CI}(r,t)$ & $\mathrm{CI}(r,t{+}1\mathrm{h})$ & RTT (ms) & Reliability \\
 & (gCO$_2$/kWh) & (gCO$_2$/kWh) & & \\
\midrule
IN-South & 720 & 680 & 20 & 99\% \\
EU-West & 180 & 140 & 180 & 85\% \\
US-East & 410 & 390 & 240 & 92\% \\
\bottomrule
\end{tabular}
\end{table}

\paragraph{Protocol.} Each of $n=@@N@@$ trials draws, once, an uplink bandwidth (log-normal, median 10~Mbps, $\sigma=0.5$), an initial device temperature $\mathcal{U}[28,36]$~$^\circ$C, an ambient temperature $\mathcal{U}[22,30]$~$^\circ$C and a battery state of charge $\mathcal{U}[0.2,1.0]$. The same draw is used for \emph{every} metric (latency, carbon, privacy and throttling), and each strategy then runs a continuous 60-second inference stream with temperature integrated through Eq.~(\ref{eq:thermalode}) at 50~ms steps; a trial counts as throttled if $T_{\mathrm{device}}\ge T_{\mathrm{critical}}=42$~$^\circ$C at any time. Latency and carbon are averaged over the cycles executed. The privacy-violation rate is the share of trials in which any cycle used a split inside $\mathcal{Z}_{\mathrm{priv}}$. Throttle intervals are exact Clopper--Pearson 95\,\% intervals.

\paragraph{Strategies.} \emph{Local-Only} runs all blocks on the device with no thermal management. \emph{Local\,+\,DVFS} runs all blocks on the device with the same reactive DVFS rule as the proposed framework; it is included because the proposed framework's thermal safeguard is DVFS, and a fair reference for it must have the same safeguard. \emph{Latency-First} fixes the lowest-latency split and region once. \emph{Carbon-Aware Greedy (CAG)}, following the geographic carbon-shifting principle of \citet{wiesner2021lets}, routes to the lowest-intensity region and then picks its lowest-latency split. \emph{Privacy-Aware Static Split (PASS)}, following \citet{osia2020hybrid,mireshghallah2020shredder}, fixes the shallowest layer whose normalised penalty is at most 0.15. The last three have neither a privacy zone nor a thermal signal, and the orchestrator's own energy is charged only to the proposed framework. These are re-implementations of design principles, not of the cited systems' own published results.

\subsection{Carbon Footprint}
\label{sec:carbon}

Table~\ref{tab:carbon} and Fig.~\ref{fig:carbon} report carbon per inference over the 60-second stream, normalised to Local-Only. Under the energy model of Section~\ref{sec:carbonmodel}, every strategy that offloads is far more carbon-intensive than executing on the device: Latency-First, CAG and PASS emit @@OFFLO@@--@@OFFHI@@ times the carbon of Local-Only. The reason is the network term. At 0.05~kWh/GB, transmitting even the smallest candidate tensor (@@SMKB@@~KB) costs about @@NETJ@@~J, against @@EDGEJ@@~J for the entire on-device computation of this 0.30~GMAC model, while the cloud term is small by comparison. Offloading does not, by itself, reduce the carbon of a lightweight CNN under this model. The embodied-carbon term adds to this penalty (Table~\ref{tab:equip}) but is not its cause.

\begin{table}[t]
\centering
\caption{Carbon per inference over a 60-s stream, as a percentage of Local-Only (mean $\pm$ SD over $n=@@N@@$ trials; 95\,\% interval of the mean).}
\label{tab:carbon}
\begin{tabular}{lcc}
\toprule
Strategy & Carbon (\%) & 95\,\% CI \\
\midrule
@@TAB_CARBON@@
\bottomrule
\end{tabular}
\end{table}

\begin{figure}[t]
  \centering
  \includegraphics[width=\columnwidth]{fig3_carbon_footprint.pdf}
  \caption{Carbon per inference as a percentage of Local-Only (logarithmic axis, $n=@@N@@$ trials).}
  \label{fig:carbon}
\end{figure}

The proposed objective, with carbon-priority weights, therefore selects layer 18 (no offloading) in every cycle of every trial and attains @@PCARB@@\,\% of Local-Only carbon. This reduction does \emph{not} come from splitting or from region choice: it is identical, trial by trial, to Local\,+\,DVFS in split, latency and throttling and differs in carbon only by the orchestrator's own @@ORCPCT@@\,\% of on-device carbon, and it arises because DVFS lowers energy per inference ($0.8^2=0.64$ at a 20\,\% frequency cut) once the thermal safeguard engages, whereas Local-Only is run without it and throttles. Relative to the other offloading strategies the proposed framework emits @@REDLO@@--@@REDHI@@\,\% less carbon, but that comparison reflects the decision not to offload.

\paragraph{Carbon-aware routing when offloading is forced.} The question of how much carbon-aware \emph{region choice} saves once computation must be offloaded for latency, thermal or other reasons is separate and is reported here with the split held fixed and local execution excluded from the feasible set. In the time-stepped simulator, choosing the lowest-carbon region at the selected split rather than the latency-first region (IN-South) would save @@ROUTB@@\,\% on average (@@ROUTBLO@@--@@ROUTBHI@@\,\% across five seeds of 500 scenarios each). The objective itself never selects the lower-carbon region (realised saving 0\,\%): at these constants the carbon difference between regions is negligible next to the network term, while the 160~ms RTT difference is not. A coarser decision-level model, the optimiser of the supplied notebook, in which cloud service time is a uniform 1~ms per remaining block and so is far longer than in the MAC-based simulator, gives a mean saving of @@ROUTA@@\,\% (median @@ROUTAMED@@\,\%; per-seed means @@ROUTALO@@--@@ROUTAHI@@\,\%). The two models disagree because the saving is the cloud term's share of total carbon, and that share is set by the unmeasured constants. Table~\ref{tab:sens} sweeps them. The potential saving ranges from @@SPLO@@\,\% to @@SPHI@@\,\%, and for the settings with a network intensity of 0.05~kWh/GB no offloaded configuration is cheaper than local execution. The headline routing figure is therefore a property of the assumed constants and should be reported as a range until they are measured.

\begin{table}[t]
\centering
\caption{Sensitivity of carbon-aware routing to the unmeasured constants (MobileNetV2, split held fixed, forced offload; 200 scenarios, seed 42). ``Potential'' is the saving of the lowest-carbon region over IN-South at the selected split; the last column is the cheapest feasible configuration, offloaded or local, as a percentage of on-device carbon (100 means that no offloaded configuration is cheaper than local).}
\label{tab:sens}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{ccccc}
\toprule
Network (kWh/GB) & Cloud (W) & $\mathrm{CI}_{\mathrm{edge}}$ & Potential saving (\%) & Best configuration / local (\%) \\
\midrule
@@TAB_SENS@@
\bottomrule
\end{tabular}}
\end{table}

\paragraph{Embodied and orchestrator carbon.} Table~\ref{tab:equip} varies the amortised embodied-carbon factor $\gamma_{\mathrm{equip}}$ of Eq.~(\ref{eq:carbon}) from 0 to 20~gCO$_2$/GB. At the default of 2~gCO$_2$/GB the equipment accounts for a small share of the carbon of an offloaded inference, and even at 20~gCO$_2$/GB (almost the operational network intensity) it only widens the gap between offloading and on-device execution; the sign of the offloading-versus-local comparison does not depend on it. The routing potential falls slightly as $\gamma_{\mathrm{equip}}$ grows, because the equipment term is region-independent and dilutes the regional difference.

\begin{table}[t]
\centering
\caption{Effect of the embodied-carbon factor $\gamma_{\mathrm{equip}}$ (MobileNetV2). ``Equipment share'' is $C_{\mathrm{equip}}$ as a percentage of the carbon of the forced-offload optimum (block 14, IN-South); ``offload / local'' is the carbon of Latency-First relative to on-device execution for one nominal draw; ``potential'' is the routing potential of Table~\ref{tab:sens}.}
\label{tab:equip}
\begin{tabular}{cccc}
\toprule
$\gamma_{\mathrm{equip}}$ (gCO$_2$/GB) & Equipment share (\%) & Offload / local ($\times$) & Routing potential (\%) \\
\midrule
@@TAB_EQUIP@@
\bottomrule
\end{tabular}
\end{table}

\paragraph{Extended carbon accounting in the reduced model.} In the reduced reconstruction of Section~\ref{sec:awc-eval}, adding a network term proportional to bytes transferred (0.05~kWh/GB at the contemporaneous intensity) raises total carbon by @@NETPCT@@\,\% (@@ACOMP@@ to @@ATOT@@ proxy units), and EU-West accounts for @@EUSH@@\,\% of the total. Injecting Gaussian error into the carbon-intensity forecast changes total carbon by @@N20@@\,\% at $\sigma=0.20$ and @@N35@@\,\% at $\sigma=0.35$ relative to the $\sigma=0.10$ default (and by @@N00@@\,\% at $\sigma=0$). These are proxy-unit figures from a retuned model and are not comparable with the main simulator.

\subsection{Latency Performance}
\label{sec:latency}

Mean end-to-end latency over the executed cycles is @@L_LO@@~ms for Local-Only, @@L_LD@@~ms for Local\,+\,DVFS and for the proposed framework, @@L_LF@@~ms for Latency-First, @@L_CAG@@~ms for CAG, and @@L_PASS@@~ms for PASS. The 80~ms gap between CAG and Latency-First is the one-way RTT difference between EU-West and IN-South (Table~\ref{tab:regions}); it is a property of the region, not of orchestration. The proposed framework's latency is @@LGAP@@~ms above Latency-First, because it stays on the device and its DVFS safeguard slows the clock by 20\,\% when the thermal forecast reaches $T_{\mathrm{safe}}$. A deployment with a hard latency budget would raise $w_{\mathrm{lat}}$ (the AWC does this automatically when targets are missed), which moves the optimum towards offloading and incurs the carbon and thermal costs reported here. The decision itself is cheap (about @@DM@@~ms in our simulator, Section~\ref{sec:algorithm}). Fig.~\ref{fig:bandwidth} shows latency against uplink bandwidth for the offloading optimum of the proposed objective (local execution excluded), Latency-First and Local-Only. We have not evaluated a low-bandwidth quantised-inference fallback; it is a design option, not a result.

\begin{figure}[t]
  \centering
  \includegraphics[width=\columnwidth]{fig5_bandwidth_stress.pdf}
  \caption{Latency against available uplink bandwidth at nominal thermal state, for the proposed objective with local execution excluded, Latency-First and Local-Only.}
  \label{fig:bandwidth}
\end{figure}

\subsection{Privacy Preservation}
\label{sec:privacypres}

The proposed framework produced no cycle inside $\mathcal{Z}_{\mathrm{priv}}$ in any of the @@N@@ trials (0\,\%), because the zone is applied when the feasible set is built. Latency-First and CAG, which have no zone, selected a zone layer in 4.0\,\% of trials (8/@@N@@) when minimising latency; PASS and the local strategies have 0\,\% by construction. This figure measures exclusion-zone compliance only; it is not evidence of resistance to activation-level attacks, which are evaluated in Section~\ref{sec:attacks}. The differential-privacy budgets are $\epsilon_r=1.0$ for EU-West (higher trust) and $0.5$ for US-East and IN-South, assigned by Eq.~(\ref{eq:budget}); they are per-inference budgets under local-DP adjacency (Section~\ref{sec:dpcomp}), and over a 60-second stream ($T=60$) the tightest composed bounds are $\epsilon^{\mathrm{RDP}}\approx48.6$ (EU-West) and $\approx21.9$ (US-East/IN-South) (Table~\ref{tab:dpcomp}). Because the proposed objective did not offload under carbon priority, no activation was transmitted in these runs; the privacy mechanisms matter when offloading occurs. The accuracy cost of the noise is measured in Section~\ref{sec:attacks}(D).

\subsection{Empirical Privacy Attack Evaluation}
\label{sec:attacks}

The mechanism of Eq.~(\ref{eq:dp}) is evaluated against the threat model of Section~\ref{sec:privacy} in two ways. Parts (A)--(C) are mechanism-level and synthetic analyses that depend only on the clipping bound and the Laplace scale: the class-identity attack there uses a synthetic, sparsity-matched proxy. Part (D) therefore repeats the evaluation on the \emph{real activations of a pretrained ImageNet network on real ImageNet images}, and reports reconstruction, re-identification and distinguishing attacks, the accuracy cost and repeated queries; part (E) repeats it on a small network trained on MNIST, which also allows membership inference against a known training set.

\paragraph{(A) Reconstruction.} The noise scale is $b=\Delta f_k/\epsilon_r=2C_k/\epsilon_r$, i.e.\ $2.0\,C_k$ at $\epsilon_r=1.0$ and $4.0\,C_k$ at $\epsilon_r=0.5$. In a Monte Carlo of $n=20{,}000$ transmissions per budget ($d=1280$, activations on the $\ell_1$ sphere of radius $C_k$), the mean cosine similarity between a noisy transmission and the true clipped activation is $@@C1M@@$ (SD @@C1S@@, 95\,\% CI $[@@C1LO@@,\,@@C1HI@@]$; one-sample $t$-test against zero $t(19999)=@@C1T@@$, $p=@@C1P@@$) at $\epsilon_r=1.0$ and $@@C5M@@$ (SD @@C5S@@, CI $[@@C5LO@@,\,@@C5HI@@]$, $t=@@C5T@@$, $p=@@C5P@@$) at $\epsilon_r=0.5$. Neither is distinguishable from zero, and both are three orders of magnitude below any plausible threshold for usable directional information; a single intercepted transmission carries no practically usable directional information about the clipped activation at either budget.

\paragraph{(B) Membership inference.} Under $\epsilon$-DP the advantage of any membership-inference adversary is bounded by $(e^{\epsilon}-1)/(e^{\epsilon}+1)$~\citep{yeom2018privacy,shokri2017membership}. At the per-inference budgets the bound is 46.2\,\% ($\epsilon_r=1.0$) and 24.5\,\% ($\epsilon_r=0.5$); at the composed budgets over $T=60$ queries ($\epsilon^{\mathrm{RDP}}\approx21.9$--$48.6$) it is vacuous (1.0). The per-inference budgets protect a single transmission, not a device's session-level membership status.

\paragraph{(C) Class-identity (feature-inversion) leakage.} Ten synthetic activation clusters confined to a 24-dimensional informative subspace of the $d=1280$ activation are classified by a nearest-centroid attacker trained on clean transmissions (Table~\ref{tab:attackC}). Without DP noise the attack is perfect; at both operating budgets it is at chance (9--11\,\% against 10\,\%), becoming partially informative (13--17\,\%) only at $\epsilon\ge2$. This is a controlled proxy for semantic leakage calibrated to the framework's own clipping and noise, not literal image reconstruction~\citep{fredrikson2015model}.

\begin{table}[t]
\centering
\caption{Class-identity attack accuracy against the Laplace mechanism ($K=10$ synthetic clusters, chance $=10\%$). $^*$US-East/IN-South operating point; $^\dagger$EU-West operating point.}
\label{tab:attackC}
\begin{tabular}{lccccccc}
\toprule
$\epsilon$ & 0.1 & 0.25 & $0.5^*$ & $1.0^\dagger$ & 2.0 & 5.0 & no DP \\
\midrule
Accuracy (\%) & @@ATK@@ \\
\bottomrule
\end{tabular}
\end{table}

Parts (A)--(C) show that at the operating budgets the Laplace layer removes essentially all single-transmission reconstruction and class-identity signal in the synthetic setting, and that the formal guarantee does not survive composition over an operating window. They say nothing about utility; part (D) does.

\paragraph{(D) Pretrained ImageNet model on real ImageNet images.} Parts (A)--(C) and the MNIST check (E) below use synthetic proxies or a small network trained here; part (D) uses the real thing at the paper's scale. The network is the 19-block MobileNetV2 of the paper with publicly released ImageNet weights (a PyTorch port, ImageNet top-1 71.8\,\% on the full validation set; BSD-2 licence) and the data are 1{,}000 real ImageNet validation images, one per class~\citep{deng2009imagenet}. On this sample the unmodified network reaches @@PI_CLEAN_ALL@@\,\% top-1 (@@PI_CLEAN@@\,\% on the 500-image test half used below, top-5 @@PI_CLEAN5@@\,\%). The images are split into 500 auxiliary images, which the adversary and the calibration use (four views each: centre crop and three random crops, with random flips), and 500 disjoint test images. For splits $k\in\{4,8,14,17\}$ ($@@PI_D4@@$, $@@PI_D8@@$, $@@PI_D14@@$ and $@@PI_D17@@$ values per activation) the clipping norm $C_k$ is the 95th percentile of the auxiliary $\ell_1$ norms (about @@PI_CLIPF@@\,\% of test activations are clipped), activations are clipped (Eq.~\ref{eq:clip}), Laplace noise of scale $2C_k/\epsilon_r$ is added elementwise, and the unmodified remaining blocks and classifier process the noisy tensor (no noise-aware fine-tuning). The measurements are: (i) top-1 and top-5 accuracy of the cloud half on the noisy test activations; (ii) \emph{re-identification}: an adversary who holds the clean clipped activations of a gallery of all 1{,}000 images returns the gallery image with the smallest $\ell_1$ distance to the received tensor, which is the maximum-likelihood decision under Laplace noise (chance $0.1\,\%$); (iii) \emph{reconstruction}: a ridge-regression decoder on the top 256 principal components of the noisy activation, trained on the noisy auxiliary activations at the attacked $\epsilon_r$ and tested on the unseen test images, to the $32\times32$ RGB thumbnail (the mean thumbnail scores a correlation of @@PI_BASE_CORR@@; a decoder trained and tested on clean activations scores @@PI_RC_CLEAN4@@, @@PI_RC_CLEAN8@@, @@PI_RC_CLEAN14@@ and @@PI_RC_CLEAN17@@ at the four splits); (iv) the optimal likelihood-ratio test between two candidate test inputs, whose advantage $\epsilon$-DP bounds; (v) repeated queries: the adversary averages $T$ noisy copies of the same input at $\epsilon_r=1$ (a Gaussian approximation of the mean for $T>100$). In addition we test a public \emph{PCA denoiser}, a projection of the received tensor onto the top 256 principal components of the clean auxiliary activations, which is post-processing and therefore costs no privacy. Table~\ref{tab:privimg} gives the results at the split $k=14$ that the forced-offload optimum selects; Table~\ref{tab:privimgk} summarises all splits and Fig.~\ref{fig:privimg} shows them.

\begin{table}[t]
\centering
\caption{Pretrained MobileNetV2 on 1{,}000 real ImageNet images, split $k=14$ ($7{,}840$ values per activation; 500 test images, chance $0.1\,\%$ for top-1 and re-identification; clean top-1 @@PI_CLEAN@@\,\%). ``Denoised'' applies the public PCA denoiser before the cloud half. ``Re-id.'' is the accuracy of the maximum-likelihood gallery attack; ``Recon.\ corr.'' is the mean thumbnail correlation of the adaptive decoder (mean-thumbnail baseline @@PI_BASE_CORR@@; clean-activation decoder @@PI_RC_CLEAN14@@); ``LR advantage'' is the empirical advantage of the optimal two-candidate test and the last column the DP bound $(e^{\epsilon}-1)/(e^{\epsilon}+1)$.}
\label{tab:privimg}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{ccccccc}
\toprule
$\epsilon_r$ & Top-1 (\%) & Denoised top-1 (\%) & Re-id. (\%) & Recon.\ corr. & LR advantage (\%) & DP bound (\%) \\
\midrule
@@TAB_PRIVIMG@@
\bottomrule
\end{tabular}}
\end{table}

\begin{table}[t]
\centering
\caption{Summary over splits (pretrained MobileNetV2, ImageNet sample). ``$\epsilon_r$ for 90\,\%'' is the smallest budget in the grid at which the cloud half keeps 90\,\% of the clean top-1 accuracy, without and with the public PCA denoiser. The last three columns are the re-identification accuracy among 1{,}000 images at $\epsilon_r=10^3$ in a single transmission, and after averaging $T=10^6$ and $T=10^4$ transmissions of the same input at $\epsilon_r=1$.}
\label{tab:privimgk}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{rrrrrrr}
\toprule
$k$ & Values & $\epsilon_r$ for 90\,\% & with denoiser & Re-id.\ at $\epsilon_r=10^3$ (\%) & Re-id.\ $T=10^6$ (\%) & Re-id.\ $T=10^4$ (\%) \\
\midrule
@@TAB_PRIVIMGK@@
\bottomrule
\end{tabular}}
\end{table}

\begin{figure}[t]
  \centering
  \includegraphics[width=\textwidth]{fig12b_privacy_imagenet.pdf}
  \caption{Pretrained MobileNetV2 on real ImageNet images, splits $k\in\{4,8,14,17\}$: top-1 accuracy of the cloud half on noisy activations (solid; dashed with the public PCA denoiser; horizontal line = clean accuracy), re-identification accuracy among 1{,}000 images, reconstruction correlation (dotted = mean-thumbnail baseline) and the likelihood-ratio advantage against the DP bound for $k=14$, as functions of $\epsilon_r$.}
  \label{fig:privimg}
\end{figure}

The picture is the same as on MNIST and sharper. (1) At $\epsilon_r\le10$ no attack works, and neither does the service: top-1 accuracy is at chance (at most @@PI_TOP1_LOW@@\,\% over all splits), re-identification is at chance, the reconstruction correlation (at most @@PI_RC_LOW@@) is no better than the mean thumbnail (@@PI_BASE_CORR@@), and the likelihood-ratio advantage is a few per cent, far below the DP bound. (2) The cloud half keeps 90\,\% of the clean accuracy only at $\epsilon_r\approx$ @@PI_E4@@, @@PI_E8@@, @@PI_E14@@ and @@PI_E17@@ for $k=4,8,14,17$ (Table~\ref{tab:privimgk}); the denoiser lowers the required budget only at the deepest split ($\epsilon_r\approx@@PI_ED17@@$ at $k=17$); at $k\le14$ it helps at $\epsilon_r=10^4$ but saturates below 30\,\% top-1 because a 256-component projection discards information the cloud blocks use. (3) Re-identification succeeds far below those budgets. At $\epsilon_r=10^3$ the adversary already picks the right image among 1{,}000 in @@PI_RID_LO@@--@@PI_RID_HI@@\,\% of cases, and at every budget that preserves utility it does so in 100\,\% of cases, with a likelihood-ratio advantage above 99\,\%; the DP bound is vacuous for $\epsilon_r\gtrsim20$. Re-identification needs a gallery that contains the image, so it is a weaker statement than reconstruction of an arbitrary image. (4) Reconstruction is bounded here by the decoder, not by the noise: at utility-preserving budgets the adaptive decoder reaches a correlation of @@PI_RC_UTIL4@@ at $k=4$ and @@PI_RC_UTIL14@@ at $k=14$ (clean-activation decoders: @@PI_RC_CLEAN4@@ and @@PI_RC_CLEAN14@@), clearly above the mean-thumbnail baseline, while at $k=17$ the correlation (@@PI_RC_UTIL17@@) is close to it; a decoder trained on more than 2{,}000 views, or a generative prior, would do better, so these are lower bounds on what a stronger adversary recovers. (5) Repeated queries at $\epsilon_r=1$: averaging up to $T=10^4$ noisy copies leaves re-identification at chance for every split, but $T=10^6$ copies give @@PI_REP6_LO@@--@@PI_REP6_HI@@\,\% and $T=10^8$ copies 100\,\%, consistent with the $1/\sqrt{T}$ decay of the noise; a 60-second stream of a few hundred queries is far from this regime, but a long-lived session is not. Membership inference against the \emph{training set} cannot be tested: the validation images are not training members of the released weights, so only the distinguishing advantage (iv), which is what the DP guarantee refers to, is reported.

\paragraph{(E) A small trained network on MNIST.} As a second, independent check we also train a small network, and add membership inference against a model with a known training set. We use the torchvision MobileNetV2 architecture (19 feature blocks; width multiplier 0.35 and a stride-1 first convolution for $32\times32$ inputs) trained from scratch on 1{,}500 of the 5{,}000 real MNIST digits distributed with the \texttt{mlxtend} package (test accuracy @@PR_CLEAN@@\,\%, training-set accuracy @@PR_MEM@@\,\%, non-member accuracy @@PR_NON@@\,\%). The remaining digits serve as non-members (1{,}500), as auxiliary data for the adversary (1{,}500) and as a test set (500). For split layers $k\in\{3,4,8,14,17\}$ the clipping norm $C_k$ is the 95th percentile of the training $\ell_1$ norms (about @@PR_CLIPF@@\,\% of test activations are clipped at $k=14$), activations are clipped (Eq.~\ref{eq:clip}), Laplace noise of scale $2C_k/\epsilon_r$ is added elementwise, and the \emph{unmodified} remaining blocks and classifier (the ``cloud half'', with no noise-aware fine-tuning) process the noisy tensor. The attackers are adaptive: a ridge-regression decoder on the top 256 principal components reconstructs the image; a logistic-regression classifier trained on noisy auxiliary activations predicts the class; membership is attacked by (i) the optimal likelihood-ratio test between two candidate inputs, which is exactly the quantity that $\epsilon$-DP bounds (advantage = true-positive rate minus false-positive rate over 500 random input pairs), and (ii) a confidence-threshold test of training-set members against non-members. Table~\ref{tab:privreal} gives the results for the split $k=14$ that the forced-offload optimum selects; Fig.~\ref{fig:privreal} shows all splits.

\begin{table}[t]
\centering
\caption{Real-activation evaluation at split $k=14$ (MobileNetV2, MNIST; chance $=10\,\%$; clean accuracy @@PR_CLEAN@@\,\%). ``Recon.\ corr.'' is the mean pixel correlation of the adversary's reconstruction with the true image; predicting the mean digit scores @@PR_BASE_CORR@@. ``LR advantage'' is the empirical membership advantage of the optimal two-candidate test; the last column is the DP bound $(e^{\epsilon}-1)/(e^{\epsilon}+1)$.}
\label{tab:privreal}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{cccccc}
\toprule
$\epsilon_r$ & Cloud accuracy (\%) & Class attack (\%) & Recon.\ corr. & LR advantage (\%) & DP bound (\%) \\
\midrule
@@TAB_PRIVREAL@@
\bottomrule
\end{tabular}}
\end{table}

\begin{figure}[t]
  \centering
  \includegraphics[width=\textwidth]{fig12_privacy_real.pdf}
  \caption{Real-activation evaluation for splits $k\in\{3,4,8,14,17\}$: accuracy of the cloud half on noisy activations (left, dashed line = clean accuracy), class-identity attack accuracy (centre) and empirical membership advantage of the likelihood-ratio test against the DP bound for $k=14$ (right), as functions of $\epsilon_r$. The dotted lines mark chance.}
  \label{fig:privreal}
\end{figure}

The results are unambiguous and not favourable to the operating budgets. (1) At $\epsilon_r=0.5$ and $1.0$ the cloud half classifies at chance (@@PR_ACC05@@\,\% and @@PR_ACC1@@\,\% at $k=14$), and so does every attack: class identity is at chance, the reconstruction (correlation @@PR_RC_05@@) is no better than predicting the mean digit (@@PR_BASE_CORR@@), and the likelihood-ratio advantage is close to zero, far below the DP bound. The mechanism is private at these budgets only because the tensor carries no usable information for anyone. (2) Utility returns only when the attacks succeed. Cloud accuracy reaches 90\,\% of the clean accuracy at $\epsilon_r\approx$ @@PR_E3@@, @@PR_E4@@, @@PR_E8@@, @@PR_E14@@ and @@PR_E17@@ for $k=3,4,8,14,17$ respectively; at $k=14$, $\epsilon_r=300$ gives @@PR_ACC300@@\,\% cloud accuracy, @@PR_CL300@@\,\% class-identity accuracy for the adversary (the same information), a reconstruction correlation of @@PR_RC14@@ (above the mean-digit baseline), and a likelihood-ratio advantage of 100\,\%. In \emph{every} configuration that keeps 90\,\% of the clean accuracy, the optimal adversary distinguishes two inputs perfectly, and the DP bound is vacuous for $\epsilon_r\gtrsim 20$. No budget in the grid gives both usable accuracy and meaningful protection. This is a property of adding independent Laplace noise to a high-dimensional, $\ell_1$-clipped activation, and it means that class-level privacy cannot be protected by noise when the cloud's task is to predict the class. (3) Confidence-threshold membership inference is near chance at every budget (AUC @@PR_AUC_LO@@--@@PR_AUC_HI@@), but also without noise (@@PR_AUC_CLEAN@@ at $\epsilon_r=10^5$): the lightly overfitted model gives this test little power, so it does not discriminate between budgets. (4) Repeated queries. For an adversary who averages $T$ noisy copies of the \emph{same} input at $\epsilon_r=1$, class-identity accuracy stays at chance for $T\le 600$ queries (at most @@PR_RP600@@\,\% over all splits), but rises to @@PR_RP1_14@@\,\% ($k=14$) and @@PR_RP1_8@@\,\% ($k=8$) at $T=6000$ and to at most @@PR_RP05@@\,\% at $\epsilon_r=0.5$, because the noise standard deviation falls as $1/\sqrt{T}$. The vacuous composed budget of Table~\ref{tab:dpcomp} therefore overstates what a practical adversary achieves within one 60-second stream ($T=60$: at most @@PR_RP60@@\,\%), but the guarantee that would protect longer sessions does not exist.

\paragraph{Consequence for the framework.} On this evidence the Laplace layer as specified is not a deployable utility-preserving privacy mechanism: at $\epsilon_r\in\{0.5,1\}$ it disables the service, and at utility-preserving budgets it offers no formal and no empirical protection. The protection the framework provides while preserving utility comes from the hard exclusion zone and from the controller's preference for not transmitting at all. The offloading analyses of Sections~\ref{sec:carbon}--\ref{sec:generalisation} account for the energy and latency of transmission but not for noise, so they correspond to offloading \emph{without} the Laplace layer. The ImageNet evaluation (D) and the MNIST check (E) agree. The ImageNet sample is small (1{,}000 images, one per class), the decoder is a linear ridge model, and only one mechanism is tested; mitigations such as noise-aware fine-tuning of the cloud half, lower-dimensional bottlenecks or per-feature clipping might shift the trade-off, but they are not evaluated here.

\subsection{Thermal Awareness}
\label{sec:thermal}

A single inference of a few hundred milliseconds cannot change device temperature appreciably, so throttle risk is evaluated under a continuous 60-second stream (Section~\ref{sec:setup}), consistent with the sustained-load throttling reported by \citet{xu2018deepwear}. Table~\ref{tab:thermal} gives throttle counts with exact Clopper--Pearson intervals. Local-Only throttles in every trial because it has no relief mechanism. Latency-First, CAG and PASS throttle in @@OTHLO2@@--@@OTHHI2@@\,\% of trials: each fixes its split at the start of the stream and never revisits it as temperature rises. The proposed framework throttles in @@TN@@ of @@N@@ trials (@@PTHR@@\,\%, 95\,\% CI @@PTHRLO@@--@@PTHRHI@@\,\%) \emph{at the nominal assumed parameters}; Section~\ref{sec:thermsens} shows that this rate is not robust to those parameters. Local\,+\,DVFS gives the same @@TN@@ of @@N@@, and the two are identical, trial by trial, in latency and throttling (their carbon differs only by the orchestrator term). The thermal benefit therefore comes from the DVFS safeguard, not from forecast-driven split selection. In the simulator the thermal forecast depends on the split only through the mean per-block compute power, which is nearly constant across $k$, so the forecast-driven thermal term is almost flat across candidate splits and does not move the optimum. We state this as a limitation of the present thermal model: it does not model the idle fraction that offloading adds to each cycle, which is the physical mechanism by which offloading cools a device. The residual @@PTHR@@\,\% is concentrated in warm ambient conditions (mean ambient temperature @@TAMB1@@~$^\circ$C among throttled trials versus @@TAMB0@@~$^\circ$C among the rest; correlation @@RAMB@@), for which a fixed 20\,\% DVFS step is insufficient; initial temperature and state of charge are essentially uncorrelated with throttling over the sampled ranges ($|r|<0.05$).

\begin{table}[t]
\centering
\caption{Sustained-load thermal throttling over a 60-s stream ($T_{\mathrm{critical}}=42$~$^\circ$C), $n=@@N@@$ trials, exact 95\,\% Clopper--Pearson intervals.}
\label{tab:thermal}
\begin{tabular}{lccc}
\toprule
Strategy & Throttled trials & Rate (\%) & 95\,\% CI (\%) \\
\midrule
@@TAB_THERMAL@@
\bottomrule
\end{tabular}
\end{table}

\subsection{Sensitivity to Thermal and Battery Parameters}
\label{sec:thermsens}

The throttle rates of Table~\ref{tab:thermal} depend on constants that are not fitted to any device. Table~\ref{tab:thermsens} varies each in turn around the nominal point (same 200-trial protocol): the thermal capacitance $C_{\mathrm{th}}$ (nominal 3~J/K), the thermal resistance $R_{\mathrm{th}}$ (7~K/W), a shift of the ambient-temperature range (22--30~$^\circ$C), a common factor on the battery internal-resistance parameters $R_0,R_1,R_2$, and the DVFS frequency step $f$ (0.8, with power scaling as $f^3$). A joint Monte Carlo then draws all parameters at once ($C_{\mathrm{th}}\in[1.5,12]$, $R_{\mathrm{th}}\in[4,12]$, ambient shift $\in[-6,6]$~K, battery factor $\in[0.5,2]$, $f\in[0.6,0.9]$; 40 draws of 100 trials).

\begin{table}[t]
\centering
\caption{One-at-a-time sensitivity of the sustained-load throttle rate (\%, 200 trials per setting). The nominal values are $C_{\mathrm{th}}=3$, $R_{\mathrm{th}}=7$, shift 0, factor 1 and $f=0.8$. Local\,+\,DVFS is identical to the proposed framework for MobileNetV2.}
\label{tab:thermsens}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{llll}
\toprule
Parameter & Values tested & Local\,+\,DVFS throttle (\%) & Local-Only throttle (\%) \\
\midrule
@@TAB_THERMSENS@@
\bottomrule
\end{tabular}}
\end{table}

The precise rate is not robust. With DVFS the throttle rate runs from 0\,\% to 100\,\% across $R_{\mathrm{th}}$, the ambient shift and the DVFS step, and changes by an order of magnitude across $C_{\mathrm{th}}$; the battery resistance matters little (@@BAT_LO@@--@@BAT_HI@@\,\% over a fourfold range). In the joint Monte Carlo the throttle rate of Local\,+\,DVFS has a median of @@JMC_D_MED@@\,\% (90th percentile @@JMC_D_P90@@\,\%, maximum @@JMC_D_MAX@@\,\%) and that of Local-Only a median of @@JMC_LO_MED@@\,\% (minimum @@JMC_LO_MIN@@\,\%); the rank correlation of the Local\,+\,DVFS rate with the DVFS step is @@SP_DVFS@@, with $R_{\mathrm{th}}$ @@SP_RTH@@, with the ambient shift @@SP_AMB@@, with $C_{\mathrm{th}}$ @@SP_CTH@@ and with the battery factor @@SP_R0@@. The qualitative statement that DVFS lowers throttling relative to no thermal management holds in every draw, and reduces it below 50\,\% in @@JMC_BELOW50@@\,\% of draws. The quantitative statement ``@@PTHR@@\,\%'' does not: it is the value at the nominal assumed parameters, and a device with a slightly higher thermal resistance, a warmer environment or a gentler DVFS step would throttle in nearly all or none of the trials. We therefore treat the thermal results as a simulation-only illustration of the mechanism (DVFS reduces throttling relative to no thermal management, and the size of the effect depends on the parameters), and we make no claim about the throttling probability of any physical device.

\begin{figure}[t]
  \centering
  \includegraphics[width=\textwidth]{fig13_thermal_sensitivity.pdf}
  \caption{One-at-a-time sensitivity of the sustained-load throttle rate to $C_{\mathrm{th}}$, $R_{\mathrm{th}}$, the ambient shift, the battery resistance factor and the DVFS step (200 trials per point).}
  \label{fig:thermsens}
\end{figure}

\subsection{Adaptive Weight Controller Evaluation}
\label{sec:awc-eval}

\paragraph{Evaluation model.} The AWC is evaluated in a reduced reconstruction built from the stated equations: two regions (EU-West and a merged US-East/IN-South), a scalar carbon-proxy unit, and a cloud-power constant retuned until the objectives trade off. Its absolute values are not comparable with those of Sections~\ref{sec:carbon}--\ref{sec:thermal}; only comparisons within one table or figure are meaningful. The scenario is a 200-cycle run with a carbon-intensity spike in the normally lowest-carbon region (cycles 70--110, 180 to 650~gCO$_2$/kWh) and a concurrent ambient-temperature excursion (to 34~$^\circ$C, cycles 120--160), with operator targets $\tau_i=0.30$ and $\eta=3$, averaged over three seeds. Two scripts implement this scenario with different noise models: the policy comparison below adds 10\,\% Gaussian noise to the carbon-intensity forecast, while the hyperparameter sweep adds 2\,\% multiplicative noise to latency and carbon. Their absolute totals therefore differ and are only comparable within one script.

\paragraph{Static preset versus AWC.} The static Environmental-Priority preset $\mathbf{w}=(0.15,0.55,0.15,0.15)$ never adapts. Its cumulative excess over target is @@STAT@@ in the sweep script and @@STAT2@@ in the policy-comparison script; the AWC, from the same initial weights, reduces this to @@AWCSW@@ (@@RED1@@\,\% lower) and @@AWC2@@ (@@RED2@@\,\% lower) respectively, by reallocating weight towards the persistently violated objectives at some cost to the others. This is the behaviour Proposition~\ref{prop:selfcorrect} guarantees for a persistent single violation. It is a single disturbance shape with fixed $\eta$ and $\tau$, not evidence that the AWC dominates every static configuration.

\paragraph{Comparison with other policies.} Table~\ref{tab:policies} compares the AWC at $(\eta,\tau)=(3,0.30)$ with four other policies on the same scenario. The AWC is clearly better than the static and thermal-only policies. The Pareto-selection policy attains lower cumulative excess (@@PAR@@ versus @@AWC2@@) and almost no SLO violations, and the tabular-RL policy has none, although its cumulative excess is higher than the AWC's (@@RLX@@ versus @@AWC2@@) and it learns online on the same fixed scenario it is evaluated on, so its generalisation is untested. The AWC's exponentially weighted adaptation lags a sudden disturbance by several cycles, which produces the visible tail ($p_{99}=@@AWCP99@@$~ms, more than twice its $p_{50}$) and the highest switching rate (@@AWCSW2@@ switches per 200 cycles). We do not claim that the AWC dominates these alternatives.

\begin{table}[t]
\centering
\caption{Control policies on the 200-cycle carbon-spike/thermal-excursion scenario in the reduced reconstruction (3-seed means; 10\,\% carbon-forecast noise). Latencies are in ms.}
\label{tab:policies}
\begin{tabular}{lcccccc}
\toprule
Policy & Cum.\ excess & Switches & SLO viol.\ (\%) & $p_{50}$ & $p_{95}$ & $p_{99}$ \\
\midrule
@@TAB_POL@@
\bottomrule
\end{tabular}
\end{table}

\paragraph{Hyperparameter sensitivity.} Fig.~\ref{fig:awcsweep} sweeps $\eta\in\{0.25,\dots,8\}$ and uniform $\tau\in\{0.20,\dots,0.40\}$. Three observations hold in this sweep. First, the operating point $\eta=3$ is not loss-minimising: $\eta\le1$ gives a smaller total violation at every $\tau$ (for example @@E1@@ at $\eta=1$ versus @@AWCSW@@ at $\eta=3$ for $\tau=0.30$), so a lower learning rate is the better default in this scenario. Second, total violation falls monotonically as $\tau$ is relaxed, which is the expected effect of a looser target. Third, the controller is only weakly sensitive to the clipping band and to the starting preset: $(w_{\min},w_{\max})=(0.05,0.85)$, $(0.15,0.60)$ and $(0.02,0.95)$ give @@CLIP0@@, @@CLIP1@@ and @@CLIP2@@, and the spread across the four starting presets is @@SPR0@@ at $\eta=3$ and @@SPR1@@ at $\eta=1$. The sweep varies the controller's configuration against a single disturbance trajectory; sensitivity to the shape and timing of the disturbance is not tested.

\begin{figure}[t]
  \centering
  \includegraphics[width=\columnwidth]{fig11_awc_ablation.pdf}
  \caption{AWC cumulative excess-over-target over $\eta$ and $\tau$ in the reduced reconstruction (3-seed means; lower is better). The star marks $(\eta,\tau)=(3,0.30)$; the static-preset baseline is @@STAT@@.}
  \label{fig:awcsweep}
\end{figure}

\paragraph{Reading of this subsection.} The results above use one disturbance shape and the per-cycle min--max excess of the original formulation. The next subsection tests both assumptions.

\subsection{AWC under Unseen Disturbance Trajectories}
\label{sec:awcheld}

\paragraph{Design.} The same reduced model is driven by randomised trajectories: a carbon spike in EU-West (start $\mathcal{U}[20,120]$, duration $\mathcal{U}[20,60]$ cycles, 400--700~gCO$_2$/kWh), a second spike in the other region with probability 0.5, an ambient excursion ($\mathcal{U}[30,38]$~$^\circ$C) and an uplink degradation (factor $\mathcal{U}[0.1,0.6]$), each with random start and duration, so that zero to three disturbances overlap. Controller settings are tuned on 30 training trajectories ($\eta\in\{0.5,1,3,8\}$, $\tau\in\{0.2,0.3,0.4\}$) and all controllers are evaluated on @@A_NTEST@@ \emph{different} test trajectories. The generalised runner reproduces the original scenario script exactly on the original scenario (cumulative excess @@A_VAL@@ for seed 0). Two excess measures are reported. $E_{\mathrm{mm}}$ is the original one (excess over $\tau=0.30$ of the per-cycle min--max normalised cost of the chosen action). $E_{\mathrm{ref}}$ measures the excess over the same $\tau$ of the cost on the \emph{fixed reference scale} of Eq.~(\ref{eq:cbar}), which does not change with the candidate set, so that all controllers are compared on a common physical scale. We also report cycles above $T_{\mathrm{safe}}$, mean latency, the mean weight movement $\|\Delta\mathbf{w}\|_1$ per cycle (oscillation) and the share of cycles in which a weight sits at its clip bound.

\paragraph{Why the normalisation matters.} With per-cycle min--max normalisation the normalised cost of a \emph{fixed physical action} changes with the other candidates: in the original scenario the carbon of block 14 in the non-EU region is constant (@@MM_G@@~g in the model's units), yet its min--max normalised value moves between @@MM_LO@@ and @@MM_HI@@ as the EU-West intensity changes, whereas its fixed-scale value stays at @@MM_REF@@. A target $\tau_i$ on the former is not a stable physical requirement.

\begin{table}[t]
\centering
\caption{Held-out evaluation of the AWC in the reduced model (@@A_NTEST@@ unseen randomised trajectories; means). $E_{\mathrm{ref}}$ and $E_{\mathrm{mm}}$: excess over $\tau=0.30$ on the fixed and the per-cycle min--max scale (lower is better); ``hot'': cycles above $T_{\mathrm{safe}}$ (of 200); $\|\Delta w\|$: mean weight movement per cycle; clip: \% of cycles with a weight at its bound. The fixed-scale rows use the excess of Eq.~(\ref{eq:cbar}) in the update; the last row also uses it inside $J$.}
\label{tab:awcheld}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{lcccccc}
\toprule
Controller & $E_{\mathrm{ref}}$ & $E_{\mathrm{mm}}$ & hot & latency (ms) & $\|\Delta w\|$ & clip (\%) \\
\midrule
@@TAB_AWCHELD@@
\bottomrule
\end{tabular}}
\end{table}

\paragraph{Results.} (1) The original controller reduces the excess by its own measure ($E_{\mathrm{mm}}$ @@A_AW_M@@ versus @@A_ENV_M@@ for the static Environmental preset), but on the fixed scale it is \emph{worse} than the static preset ($E_{\mathrm{ref}}$ @@A_AW_E@@ versus @@A_ENV_E@@; better in only @@A_WIN_AW@@\,\% of trajectories). It moves its weights by @@A_AW_TV@@ per cycle and holds a weight at its clip bound in @@A_AW_CLIP@@\,\% of cycles: with min--max-normalised costs the excess exceeds $\tau$ whenever the candidate set is narrow, so the controller saturates rather than converges. The earlier finding that it halves the excess on the single original scenario is therefore specific to that scenario and to that measure. (2) Measuring the excess on the fixed scale (Eq.~\ref{eq:cbar}) while keeping min--max inside $J$ removes the saturation (movement @@A_MX_TV@@, clipping @@A_MX_CLIP@@\,\%). At the original hyperparameters it is indistinguishable from the static preset ($E_{\mathrm{ref}}$ @@A_MX_E@@ versus @@A_ENV_E@@, better in @@A_WIN_MX@@\,\% of trajectories). With $(\eta,\tau)=(@@A_TUNE_E@@,@@A_TUNE_T@@)$ chosen on the training trajectories it lowers the excess to @@A_MT_E@@ (mean paired reduction @@A_PD@@, 95\,\% interval $\pm@@A_PDCI@@$; better in @@A_WIN_MT@@\,\% of test trajectories). The static presets are worse on this scale (Latency @@A_LATP@@, Privacy @@A_PRIVP@@, Thermal @@A_THP@@). (3) The gain is not thermal: the number of hot cycles is @@A_HOT_MX@@ for the fixed-scale controller against @@A_HOT_ENV@@ for the static preset (the original controller reaches @@A_HOT_AW@@ and the Thermal-Safety preset @@A_HOT_TH@@, at a large cost on the other axes). (4) Multiple simultaneous violations are not handled better. The mean excess per cycle of the static preset rises from @@A_C0S@@ with no active disturbance to @@A_C3S@@ with three; that of the fixed-scale controller rises from @@A_C0M@@ to @@A_C3M@@ (@@A_C3N@@ trajectories), i.e.\ it is worse than the static preset when all three overlap. (5) Oscillation is governed by the normalisation, not by $\eta$ alone: the weight movement of the original controller rises from @@A_TV_LO@@ to @@A_TV_HI@@ per cycle as $\eta$ goes from 0.5 to 50, whereas that of the fixed-scale controller never exceeds @@A_MIXTV_HI@@ (Fig.~\ref{fig:awcheld}).

\begin{figure}[t]
  \centering
  \includegraphics[width=\textwidth]{fig14_awc_study.pdf}
  \caption{Held-out AWC evaluation: fixed-scale excess $E_{\mathrm{ref}}$ with 95\,\% intervals (left), weight movement per cycle against $\eta$ (centre) and $E_{\mathrm{ref}}$ against $\eta$ (right). ``mm'': per-cycle min--max excess (original); ``mix'': fixed-scale excess; ``ref'': fixed scale also in $J$.}
  \label{fig:awcheld}
\end{figure}

We conclude that the AWC is a reasonable design only with targets defined on a fixed scale; that with its original formulation the benefit shown on the single scenario does not transfer; and that even the revised controller shows a modest, hyperparameter-dependent improvement in a reduced model, no thermal benefit, and no demonstrated advantage under simultaneous violations. We do not claim optimality, convergence or a stability guarantee (Proposition~\ref{prop:pairwise} below gives only a one-step property).

\subsection{Optimisation Landscape}
\label{sec:landscape}

Fig.~\ref{fig:landscape} plots $J(k,r^*)$ across the offloaded split layers at a nominal state (10~Mbps, 32~$^\circ$C device, 26~$^\circ$C ambient, SOC 0.6) with local execution excluded and the privacy zone removed. The curve is not monotone, because the transmitted tensor is not: it shrinks with depth but grows again at blocks 11--13 and 17. $J$ is high ($\approx@@J4@@$) for blocks 4--6, which transmit the largest tensors, falls to a secondary basin at blocks 7--10 ($@@J7@@$--$@@J10@@$), rises at blocks 11--13 ($@@J11@@$--$@@J13@@$), and is lowest at block @@KSTAR@@ ($J=@@JMIN@@$), an interior solution rather than a boundary one. When local execution is allowed, the carbon-priority optimum is layer 18 (Section~\ref{sec:carbon}); the interior optimum is the best \emph{offloaded} configuration, which is the relevant one once the device must offload.

\begin{figure}[t]
  \centering
  \includegraphics[width=\columnwidth]{fig9_optimization_landscape.pdf}
  \caption{Optimisation landscape of $J(k,r^*)$ over offloaded split layers for MobileNetV2 under the base weights. Layers 0--3 are excluded by the privacy zone.}
  \label{fig:landscape}
\end{figure}

\subsection{Convergence and Sensitivity}
\label{sec:convergence}

Across 50 independent trials of the offloaded optimum the selected layer is @@KC@@ in every trial (SD 0) and the objective is $@@JC@@\pm@@JCS@@$ (Fig.~\ref{fig:convergence}); the optimiser is not sensitive to the sampled bandwidth, temperatures or state of charge in this range. Perturbing each weight by $\pm50\,\%$ (renormalised) shifts $k^*$ by at most two layers for $w_{\mathrm{lat}}$ and $w_{\mathrm{therm}}$, by at most one for $w_{\mathrm{carb}}$ and not at all for $w_{\mathrm{priv}}$ (Fig.~\ref{fig:sensitivity}); a poorly calibrated weight vector therefore changes the solution by only a few partition boundaries.

\begin{figure}[t]
  \centering
  \includegraphics[width=\textwidth]{fig7_convergence.pdf}
  \caption{Split-layer stability (left) and objective value (right) over 50 trials of the offloaded optimum.}
  \label{fig:convergence}
\end{figure}

\begin{figure}[t]
  \centering
  \includegraphics[width=\columnwidth]{fig8_sensitivity.pdf}
  \caption{Mean shift in the selected split layer under $\pm50\,\%$ perturbation of each objective weight (50 scenarios).}
  \label{fig:sensitivity}
\end{figure}

\subsection{Pareto Front Analysis}
\label{sec:pareto}

Fig.~\ref{fig:pareto} plots the six strategies in the latency--carbon plane, with marker size indicating privacy compliance. No strategy dominates. Latency-First, CAG and PASS achieve the lowest latency (@@L_LF@@--@@L_CAG@@~ms) at 5--6 times Local-Only carbon, and the first two violate the privacy zone. The proposed framework and Local\,+\,DVFS reach the lowest carbon of the strategies that manage temperature, with full privacy compliance, at the highest latency of the six (@@L_LD@@~ms). The honest summary is that the proposed framework trades latency for carbon and thermal safety; it does not dominate on all three axes.

\begin{figure}[t]
  \centering
  \includegraphics[width=\columnwidth]{fig10_pareto_front.pdf}
  \caption{Latency--carbon trade-off (carbon as a percentage of Local-Only, logarithmic axis). Large markers indicate no privacy-zone violations.}
  \label{fig:pareto}
\end{figure}

\subsection{Summary of Results}
\label{sec:sota}

Table~\ref{tab:summary} consolidates the sustained-load results from the single trial draw. Under the stated assumptions: (i) offloading is carbon-costly for MobileNetV2, and the proposed objective, correctly, stays on the device under carbon priority; (ii) the thermal and carbon benefit over fixed strategies comes from the DVFS safeguard and equals that of Local\,+\,DVFS, with a throttle rate that depends strongly on unfitted thermal parameters; (iii) the hard privacy zone removes the 4\,\% violation rate of strategies without it; (iv) the value of carbon-aware region routing when offloading is forced depends on unmeasured constants (@@SPLO@@--@@SPHI@@\,\%); (v) on real activations the Laplace layer is unusable at the operating budgets and offers no protection at utility-preserving ones; and (vi) the AWC benefit seen on its original scenario does not transfer to unseen disturbances in its original min--max formulation. The result we can defend is narrower than ``beats every baseline on every axis'': a unified, constraint-respecting controller that makes the trade-offs explicit, at a latency cost.

\begin{table}[t]
\centering
\caption{Summary of sustained-load results ($n=@@N@@$ trials; one draw per trial for all metrics). Latency is mean $\pm$ SD in ms; carbon is a percentage of Local-Only; the throttle rate carries an exact 95\,\% interval.}
\label{tab:summary}
\begin{tabular}{lcccc}
\toprule
Strategy & Latency (ms) & Carbon (\%) & Priv.\ viol.\ (\%) & Throttle (\%) \\
\midrule
@@TAB_SUMMARY@@
\bottomrule
\end{tabular}
\end{table}

\subsection{Generalisation to Additional Architectures}
\label{sec:generalisation}

We apply the same cost model and optimiser to three further profiles: ResNet-50 (16 bottleneck blocks, 4.09~GMAC), ViT-Base (ViT-B/16, 12 encoder blocks, 17.6~GMAC) and the CLIP ViT-B/32 image encoder (12 blocks, 4.41~GMAC). Tensor sizes and MACs are computed analytically from the architecture definitions; the tensor sizes of all three are identical to those of the corresponding torchvision models (ResNet-50, ViT-B/16 and ViT-B/32, the last having the geometry of the CLIP image tower: 50 tokens $\times$ 768 channels), and total MACs agree with PyTorch's FLOP counter to within 0.1\,\%, 4.1\,\% and 1.0\,\% respectively (the accompanying notebook repeats the check). The CLIP entry is the \emph{image encoder only}: the text tower and fusion are not modelled, so no multimodal split is evaluated. The edge compute rate is that calibrated for MobileNetV2, which makes the edge-only latency of the larger models many seconds; the table therefore reports where the optimiser places the split and relative carbon, not latency. Weights are the Environmental-Priority preset with no thermal term; the privacy zone follows the rule of Section~\ref{sec:privacy}.

\begin{table}[t]
\centering
\caption{Generalisation across architectures (300 scenarios, seed 42). $k^*$ is the modal selected split with local execution allowed (``free'') and with offloading forced. ``Offload / local'' is the carbon of the forced-offload optimum as a percentage of on-device carbon; ``routing potential'' is the saving of the lowest-carbon region over IN-South at that split.}
\label{tab:generalisation}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{lccccccc}
\toprule
Architecture & Blocks & Zone ends at & $k^*$ (free) & $k^*$ (forced offload) & Offload / local (\%) & Routing potential (\%) \\
\midrule
@@TAB_GEN@@
\bottomrule
\end{tabular}}
\end{table}

Two regimes appear. For the CNNs (MobileNetV2, ResNet-50) tensors shrink with depth, edge compute is modest relative to network energy, and the carbon-priority optimum is to run everything locally; forcing offloading gives an interior split (14 and 13) at about @@GEN_OFF_CNN@@ times on-device carbon, and the routing potential is below 1\,\%. For the transformer-style models the activation size is constant across depth (591~KB for ViT-Base at every block, 150~KB for the CLIP image encoder), so delaying the split gains nothing on the network side while edge compute keeps growing, and the optimiser selects the earliest privacy-feasible split in every scenario; offloading then costs within @@GEN_OFF_VIT@@--@@GEN_OFF_VIT_HI@@\,\% of on-device carbon (slightly more, not less) and the routing potential is @@GEN_RP_LO@@--@@GEN_RP_HI@@\,\%. The interior optimum observed for MobileNetV2 under forced offloading therefore does not generalise to constant-width architectures, for which the framework behaves as a privacy-constrained latency--carbon minimiser. Restoring an interior optimum there would need a depth-dependent cost term that does not rely on tensor shrinkage, which we leave as future work. The single-index split abstraction also does not natively support branched or multi-stream architectures: a split inside a residual block would sever a skip connection, so splits are restricted to block boundaries, and independent per-modality splits for a two-tower model would additionally require a synchronisation term in the latency model and two concurrently transmitted tensors in the network term.

'''

SEC_7_A = r'''\section{Discussion}
\label{sec:discussion}

\subsection{Comparison with Related Systems}

Table~\ref{tab:prior} places the proposed framework against the closest related
systems.  The comparison reveals a consistent pattern: existing work
addresses at most two of the four objectives within a single framework.
Neurosurgeon~\citep{kang2017neurosurgeon} and its successors
\citep{hu2019dynamic,laskaridis2020spinn,ghosh2024partnner} optimise latency;
SPINN~\citep{laskaridis2020spinn} adds bandwidth adaptation but not
carbon or thermal awareness.  Shredder~\citep{mireshghallah2020shredder}
and the resource-aware partitioner of \citet{ding2024resource} address privacy, the latter as a term in a resource-aware cost rather than a structurally separate hard constraint, and \citet{cheng2025privacy} do likewise under a privacy constraint.
zTT~\citep{kim2021ztt} and DeepX~\citep{lane2016deepx} handle thermal and energy dynamics
without carbon intensity or privacy zones.  CarbonCP~\citep{ke2024carboncp} is the most directly comparable recent system in targeting carbon through partitioning, on a single-node deployment without multi-region selection and without privacy or thermal terms.  To our knowledge no published system combines region-resolved carbon, a structurally separate privacy zone, a thermal model and DVFS in a single objective; the evidence in this paper that the combination \emph{outperforms} its parts is, however, limited to simulation and, for the thermal axis, to the DVFS safeguard (Section~\ref{sec:thermal}).

\begin{table*}[t]
\centering
\caption{Comparison with Related Systems}
\label{tab:prior}
\begin{tabular}{lcccc}
\toprule
\textbf{System} & \textbf{Carbon-Aware} & \textbf{Privacy Zone} &
  \textbf{Thermal Model} & \textbf{DVFS Integration} \\
\midrule
Neurosurgeon~\citep{kang2017neurosurgeon}        & $\times$   & $\times$   & $\times$   & $\times$   \\
BranchyNet~\citep{teerapittayanon2017branchynet} & $\times$   & $\times$   & $\times$   & $\times$   \\
SPINN~\citep{laskaridis2020spinn}                & $\times$   & $\times$   & $\times$   & $\times$   \\
PArtNNer~\citep{ghosh2024partnner}               & $\times$   & $\times$   & $\times$   & $\times$   \\
Shredder~\citep{mireshghallah2020shredder}       & $\times$   & \checkmark & $\times$   & $\times$   \\
Resource-aware partitioning~\citep{ding2024resource} & $\times$ & $\times^{*}$ & $\times$ & $\times$ \\
Joint deployment/partitioning~\citep{cheng2025privacy} & $\times$ & $\times^{*}$ & $\times$ & $\times$ \\
DeepX~\citep{lane2016deepx}                      & $\times$   & $\times$   & \checkmark & $\times$   \\
DVFS inference~\citep{kim2021ztt}              & $\times$   & $\times$   & \checkmark & \checkmark \\
Carbon-aware scheduling~\citep{wiesner2021lets}  & \checkmark & $\times$   & $\times$   & $\times$   \\
CarbonCP~\citep{ke2024carboncp}                  & \checkmark & $\times$   & $\times$   & $\times$   \\
\textbf{Proposed (Ours)}                      & \checkmark & \checkmark & \checkmark & \checkmark \\
\bottomrule
\end{tabular}
\par\smallskip\footnotesize $^{*}$These systems address privacy, but as a cost term or constraint rather than the structurally separate hard exclusion zone that the ``Privacy Zone'' column denotes.
\end{table*}

\subsection{Trade-offs and Practical Considerations}

The most visible trade-off is latency: on MobileNetV2 the proposed framework is @@LGAP@@~ms slower than the latency-first baseline because it stays on the device behind a DVFS safeguard.  For applications with hard sub-300\,ms budgets this is not acceptable, and the operator must raise $w_{\mathrm{lat}}$ (or rely on the AWC to do so), which moves the optimum to offloading with the carbon and thermal costs of Section~\ref{sec:carbon}.  Reported latencies are means over simulated 60-second streams, not a long-duration production workload, so the claim of practical deployability is provisional; conversational-response thresholds~\citep{miller1968response} are a reference for what an interactive application tolerates, not a result of this study.

The carbon API dependency is a separate practical concern.  We describe, but have not evaluated, a design in which scheduling falls back to cached forecasts for short outages and to a fixed regional priority order if caching fails; operating without live carbon data for extended periods would remove the value of region-aware routing and should be reflected in deployment agreements.  Likewise, the reliability column of Table~\ref{tab:regions} (EU-West 85\,\% versus IN-South 99\,\%) and any retry-and-fallback behaviour for unreliable regions are not exercised by the simulator, and no timeout-overhead figure is reported.

\subsection{Limitations and Future Work}

\paragraph{Simulation and assumed constants.} The evaluation is simulation-based.  Edge timing and power, network and cloud energy (0.05~kWh/GB, 300~W) and the edge-grid intensity are assumptions; Section~\ref{sec:carbon} shows that the routing benefit and the offloading-versus-local comparison depend on them.  Reaching a higher technology-readiness level requires on-device validation with a live carbon API, real network variability and profiling across device generations, work we intend to pursue on a Raspberry Pi 4 / Jetson Nano testbed.  The embodied-carbon factor and the orchestrator power are assumed values, swept in Section~\ref{sec:carbon}.

\paragraph{Thermal model.} The forecast depends on the split only through mean per-block compute power and ignores the idle fraction that offloading adds to each cycle; the thermal benefit in our results therefore comes from DVFS.  The throttle rates depend strongly on unfitted parameters (Section~\ref{sec:thermsens}) and are not predictions for any device.  A forecast that includes the duty cycle, and the calibration protocol of Section~\ref{sec:calib}, are the next steps.

\paragraph{Privacy.} The soft penalty uses a monotone proxy rather than measured mutual information; the DP budgets are per-inference and compose to weak session-level guarantees (Table~\ref{tab:dpcomp}), so a session-level budget enforced by the framework is needed for continuous streaming; the real-activation evaluations (a pretrained ImageNet MobileNetV2 on 1{,}000 real images, and a small MNIST network) show that at the operating budgets the noisy activation is useless to the cloud while at utility-preserving budgets the guarantee is vacuous and re-identification among 1{,}000 images succeeds (Section~\ref{sec:attacks}); the ImageNet sample is small, one image per class, and its attackers are simple; noise-aware training, lower-dimensional bottlenecks and per-feature clipping are untested remedies.  Hard regulatory constraints such as data-residency requirements are not encoded and would need to be enforced as an additional hard constraint alongside $\mathcal{Z}_{\mathrm{priv}}$.

\paragraph{AWC.} The AWC is evaluated only in a reduced reconstruction.  On the original scenario Pareto selection attains lower cumulative violation, tabular RL has fewer latency-SLO violations, and $\eta=3$ was not loss-optimal; on unseen randomised disturbances the original min--max formulation saturates and the fixed-scale variant gives a modest gain, no thermal benefit and no advantage under three simultaneous violations (Section~\ref{sec:awcheld}).  Evaluation on the full simulator, on slow-onset drift and with a stability analysis is open.

\paragraph{Scope of architectures and deployments.} Results use a single Raspberry-Pi-4-class profile; heterogeneous fleets, network congestion and queuing, correlated regional outages and non-stationary ambient temperature are not modelled.  Longer forecast horizons (six to 24 hours)~\citep{wiesner2021lets} could yield larger savings for genuinely deferrable workloads, and the interior-optimum behaviour does not generalise to constant-width architectures (Section~\ref{sec:generalisation}).  A further direction is multi-device coordination: in scenarios where multiple edge devices share a cloud backend, the carbon and thermal objectives are coupled, all devices compete for the same low-carbon region, and regional capacity constraints may limit simultaneous offloading.  Extending the proposed framework to a cooperative multi-agent scheduling setting is an open research question.

\subsection{Ethical Considerations}
'''

SEC_8 = r'''% =======================================================================
\section{Conclusion}
\label{sec:conclusion}

Running DNN inference at the network edge has environmental, privacy and hardware costs that a latency-only scheduler cannot see.  We formulated the split-point and region choice as a single normalised four-objective problem with a hard privacy exclusion zone, an online weight controller with a proved one-step self-correction property, a forward thermal--battery model and a DVFS safeguard, and evaluated it in simulation.

Under our energy model, offloading a lightweight CNN costs several times the carbon of running it on the device, and the proposed objective correctly keeps MobileNetV2 local under carbon priority.  In sustained load the framework reduces throttle risk from @@OTHLO@@--@@OTHHI@@\,\% for the fixed strategies to @@PTHR@@\,\% at the nominal assumed thermal parameters, but this equals a local-with-DVFS baseline, so the benefit is attributable to the DVFS safeguard, and the rate itself ranges from 0 to 100\,\% over plausible parameters (Section~\ref{sec:thermsens}).  The hard zone eliminates the 4\,\% privacy-zone violations of strategies without it.  When offloading is forced, carbon-aware region choice saves between @@SPLO@@\,\% and @@SPHI@@\,\% depending on assumed constants, which should be measured before the figure is relied upon.  On a pretrained ImageNet network and real ImageNet images the Laplace layer is either too noisy for the cloud to use (at the operating budgets) or too weak to protect (at budgets that preserve accuracy). In a reduced model the AWC halves constraint violation on its original scenario, but on unseen randomised disturbances its min--max formulation saturates, a fixed-scale variant is stable with only a modest gain and no thermal benefit, Pareto selection attains lower violation on the original scenario and tabular RL fewer latency-SLO violations, and the interior-optimum behaviour seen for MobileNetV2 does not generalise to constant-width transformer profiles.

The work is a simulation-based proof of concept.  The mechanisms we regard as its main contributions are the formalisation of the multi-objective problem, the structurally separate hard privacy zone, a differential-privacy layer whose utility--privacy trade-off we measured and found unfavourable at the operating budgets, an explicit composition analysis, the forward thermal model with its calibration protocol, and the tamper-evident ESG ledger.  Measurements of network-path and server energy, a thermal forecast that captures offloading's duty-cycle effect, are natural next steps; validation on physical devices is left for future work.

'''

DATA_AVAIL = r'''\section*{Data Availability Statement}
The code that generates every number, table and figure in Sections~\ref{sec:experiments} and~\ref{sec:discussion} is provided as supplementary material. The package \texttt{greensplit/} contains the single simulator (\texttt{sim.py}), the experiment runner (\texttt{experiments.py}), the supporting analyses and the privacy $t$-test script; it needs no GPU or deep-learning framework, because tensor sizes and operation counts are computed analytically and are checked against PyTorch/torchvision for all four architectures (\texttt{GreenSplit\_torch\_check.ipynb}; its output is stored in \texttt{results/torch\_check.json}). The thermal-sensitivity study (\texttt{thermal\_sensitivity.py}), the held-out AWC study (\texttt{awc\_study.py}) and the real-activation privacy evaluations (\texttt{privacy\_imagenet.py}, which uses the publicly released ImageNet MobileNetV2 checkpoint stored in \texttt{data/} with its BSD-2 licence and the 1{,}000-image ImageNet sample of Schwartz (github.com/EliSchwartz/imagenet-sample-images; the images are not redistributed, see the README); and \texttt{privacy\_real.py}, which uses the MNIST digits bundled with the \texttt{mlxtend} package and stores the trained network) are in \texttt{greensplit/}. The scripts for the differential-privacy composition analysis, the synthetic privacy attacks and the original reduced AWC study are provided unmodified in \texttt{original/}, and \texttt{results/} stores the outputs of the runs reported here. The AWC studies are reconstructions from the stated equations and are not numerically comparable with the main simulator. Repository: \url{https://github.com/Saanvigoel/An-Adaptive-Spatio-Temporal-Framework-for-Carbon-Aware-and-Privacy-Preserving-DNN-Partitioning}. % TODO(authors): confirm that this repository is public and contains greensplit/ before submission.

'''

AWC_CBAR = r"""with $\bar{C}_{\mathrm{priv}}:=P(k_t^*)$ and $\bar{C}_{\mathrm{lat}},\bar{C}_{\mathrm{carb}},\bar{C}_{\mathrm{therm}}$ the realised costs on a \emph{fixed reference scale},
  \begin{equation}
  \bar{C}_{\mathrm{lat}}=\tfrac{C_{\mathrm{lat}}-L_{\mathrm{lo}}}{L_{\mathrm{hi}}-L_{\mathrm{lo}}},\quad
  \bar{C}_{\mathrm{carb}}=\tfrac{C_{\mathrm{carb}}-G_{\mathrm{lo}}}{G_{\mathrm{hi}}-G_{\mathrm{lo}}},\quad
  \bar{C}_{\mathrm{therm}}=\min\!\Bigl(1,\tfrac{\max(0,\hat{s}-T_{\mathrm{safe}})^2}{(T_{\mathrm{crit}}-T_{\mathrm{safe}})^2}\Bigr),
  \label{eq:cbar}
  \end{equation}
  where $[L_{\mathrm{lo}},L_{\mathrm{hi}}]$ and $[G_{\mathrm{lo}},G_{\mathrm{hi}}]$ are the best-case and worst-case latency and carbon over the full candidate set under the deployment's operating envelope (range of uplink bandwidths and carbon intensities), computed once offline. The selection cost $J$ keeps the per-cycle min--max normalisation of Eq.~(\ref{eq:norm}), which needs only the relative order of the candidates; only the controller's \emph{excess} is measured on the fixed scale. This is a deliberate choice: with per-cycle min--max normalisation, the normalised cost of an unchanged physical action varies with the other candidates, so a target $\tau_i$ on it is not a stable requirement, whereas on the reference scale $\tau_i$ is a fixed physical level (for example $\tau_{\mathrm{lat}}=0.3$ means that latency is 30\,\% of the way from the best-case to the worst-case value, which converts to milliseconds through $L_{\mathrm{lo}},L_{\mathrm{hi}}$). Section~\ref{sec:awcheld} quantifies the difference."""

AWC_PROP2 = r"""The proposition covers one violated objective. The update has an exact consequence for several simultaneously violated objectives as well:

\begin{proposition}
\label{prop:pairwise}
For any two objectives $i\neq j$ and any cycle, before clipping,
$\log\frac{w_{i,t+1}}{w_{j,t+1}}=\log\frac{w_{i,t}}{w_{j,t}}+\eta\,(\ell_{i,t}-\ell_{j,t})$.
Hence the relative weight of $i$ increases exactly when its excess is larger than that of $j$, and every objective within target loses absolute weight whenever at least one objective is violated.
\end{proposition}

\begin{proof}
Eq.~(\ref{eq:mwu}) gives $w_{i,t+1}/w_{j,t+1}=\tilde{w}_{i,t+1}/\tilde{w}_{j,t+1}=(w_{i,t}/w_{j,t})e^{\eta(\ell_{i,t}-\ell_{j,t})}$, the normaliser cancelling. If $\ell_{j,t}=0$ and $\sum_m\ell_{m,t}>0$, then $\sum_m\tilde{w}_{m,t+1}>1$ and $w_{j,t+1}=w_{j,t}/\sum_m\tilde{w}_{m,t+1}<w_{j,t}$.
\end{proof}

Both propositions are one-step properties. They do not imply convergence, stability or optimality: the excess depends on the weights through the chosen action, so oscillation and limit cycles are possible, and the clipping bounds only keep the weights in $[w_{\min},w_{\max}]$. We therefore evaluate oscillation, simultaneous violations and unseen disturbance trajectories empirically in Section~\ref{sec:awc-eval} and Section~\ref{sec:awcheld}, where the results are mixed."""

ZONE_TXT = r"""Layers close to the network input retain high mutual information
$I(\mathbf{a}_k; \mathbf{x})$ with the original sensor signal
$\mathbf{x}$~\citep{tishby2017deep}.  The framework therefore defines a
hard exclusion zone $\mathcal{Z}_{\mathrm{priv}}$ of the shallowest
layers, where splitting would expose information comparable in
sensitivity to the raw input.  Section~\ref{sec:privacy} gives the rule
used in this study (a threshold on a monotone proxy of the leakage, not a
measured mutual information) and the zone it produces for each
architecture.  The hard constraint $k \notin \mathcal{Z}_{\mathrm{priv}}$ removes these
points from consideration \emph{before} the cost function is evaluated,
rather than after, ensuring that no combination of weights can produce a
privacy-violating split.  Fig.~\ref{fig:privacy} shows the proxy
penalty and the transmitted tensor size by layer."""

# ------------------------------------------------------------------ token values
atk_acc = {}
for m in re.finditer(r'^\s*([\d.e+]+)\s*\|\s*([\d.]+)', atk, re.M):
    atk_acc[float(m.group(1))] = float(m.group(2))
assert abs(atk_acc[1e6] - 1.0) < 1e-9 and abs(atk_acc[0.5] - 0.092) < 1e-9
atk_row = " & ".join(f"{100 * atk_acc[e]:.1f}" for e in (0.1, 0.25, 0.5, 1.0, 2.0, 5.0, 1e6))
tok = dict(
    N=str(N), OFFLO=f"{min(offl):.1f}", OFFHI=f"{max(offl):.1f}", PCARB=f1(carb('proposed')), PTHR=f1(thr('proposed')),
    PTHRLO=f1(T9['proposed']['throttle_ci'][0]), PTHRHI=f1(T9['proposed']['throttle_ci'][1]),
    OTHLO=f1(min(thr_others)), OTHHI=f"{max(thr_others):.0f}", OTHLO2=f1(min(thr_others[1:])), OTHHI2=f1(max(thr_others[1:])),
    ROUTB=f"{rB['potential_seed42']:.1f}", ROUTBLO=f"{rB['potential_range'][0]:.2f}", ROUTBHI=f"{rB['potential_range'][1]:.2f}",
    ROUTA=f"{rA['mean_seed42']:.0f}", ROUTAMED=f1(rA['median_all']), ROUTALO=f1(rA['range'][0]), ROUTAHI=f1(rA['range'][1]),
    SPLO=f"{sp_lo:.1f}", SPHI=f"{sp_hi:.0f}",
    STAT=f"{static_sw:.1f}", AWCSW=f"{awc_sw:.1f}", STAT2=f"{pol['static']['excess']:.1f}", AWC2=f"{pol['awc']['excess']:.1f}",
    RED1=f1(100 * (1 - awc_sw / static_sw)), RED2=f1(100 * (1 - pol['awc']['excess'] / pol['static']['excess'])),
    PAR=f"{pol['pareto']['excess']:.1f}", RLX=f"{pol['rl']['excess']:.1f}", AWCP99=f"{pol['awc']['p99']:.1f}", AWCSW2=f"{pol['awc']['switches']:.0f}",
    E1=f"{grid[1.0][2]:.1f}", CLIP0=f"{clip[0]:.1f}", CLIP1=f"{clip[1]:.1f}", CLIP2=f"{clip[2]:.1f}", SPR0=f"{spreads[0]:.2f}", SPR1=f"{spreads[1]:.2f}",
    REDLO=f"{red_lo:.0f}", REDHI=f"{red_hi:.0f}",
    SMKB=f1(X['smallest_tensor_kb']), NETJ=f1(X['net_J_smallest']), EDGEJ=f1(X['edge_J_full_local']),
    NETPCT=f1(acct['net_pct']), ACOMP=f"{acct['compute']:.2f}", ATOT=f"{acct['total']:.2f}", EUSH=f1(acct['eu_share']),
    N20=f"{100 * (noise[0.2] / noise[0.1] - 1):+.1f}", N35=f"{100 * (noise[0.35] / noise[0.1] - 1):+.1f}", N00=f"{100 * (noise[0.0] / noise[0.1] - 1):+.1f}",
    L_LO=f1(lat_pc('local_only')), L_LD=f1(lat_pc('proposed')), L_LF=f1(lat_pc('latency_first')), L_CAG=f1(lat_pc('carbon_greedy')), L_PASS=f1(lat_pc('privacy_static')),
    LGAP=f"{lat_pc('proposed') - lat_pc('latency_first'):.0f}", DM=f"{dm:.1f}", DM95=f"{dm95:.1f}",
    TN=str(T9['proposed']['throttle_n']), TAMB1=f1(X['throttled_means']['t_amb']), TAMB0=f1(X['not_throttled_means']['t_amb']),
    RAMB=f"{X['corr_with_throttle']['t_amb']:.2f}",
    C1M=sci(cl['1.0']['mean']), C1S=f"{cl['1.0']['sd']:.3f}", C1LO=sci(cl['1.0']['ci'][0]), C1HI=sci(cl['1.0']['ci'][1]), C1T=f"{cl['1.0']['t']:.2f}", C1P=f"{cl['1.0']['p']:.3f}",
    C5M=sci(cl['0.5']['mean']), C5S=f"{cl['0.5']['sd']:.3f}", C5LO=sci(cl['0.5']['ci'][0]), C5HI=sci(cl['0.5']['ci'][1]), C5T=f"{cl['0.5']['t']:.2f}", C5P=f"{cl['0.5']['p']:.2f}",
    ATK=atk_row,
    ORCPCT=f"{R['orch_pct_of_local']:.2f}", ORCG='$' + sci(R['orch_carbon_g']) + '$',
    TAB_EQUIP=tab_equip(), TAB_THERMSENS=tab_thermsens(), TAB_PRIVREAL=tab_privreal(), TAB_AWCHELD=tab_awcheld(),
    DVFSLO=f"{TS['one_at_a_time']['DVFS']['0.8']['local_dvfs']['pct']:.1f}",
    JMC_LO_MED=f"{TS['joint_mc']['local_only_pct']['median']:.0f}", JMC_LO_MIN=f"{TS['joint_mc']['local_only_pct']['min']:.0f}",
    JMC_D_MED=f"{TS['joint_mc']['local_dvfs_pct']['median']:.0f}", JMC_D_P90=f"{TS['joint_mc']['local_dvfs_pct']['p90']:.0f}", JMC_D_MAX=f"{TS['joint_mc']['local_dvfs_pct']['max']:.0f}",
    JMC_BELOW50=f"{100 * TS['joint_mc']['frac_draws_dvfs_below_50']:.0f}",
    SP_DVFS=f"{TS['joint_mc']['spearman_local_dvfs']['DVFS']:.2f}", SP_RTH=f"{TS['joint_mc']['spearman_local_dvfs']['R_TH']:.2f}", SP_AMB=f"{TS['joint_mc']['spearman_local_dvfs']['AMB_SHIFT']:.2f}",
    SP_R0=f"{TS['joint_mc']['spearman_local_dvfs']['R0']:.2f}", SP_CTH=f"{TS['joint_mc']['spearman_local_dvfs']['C_TH']:.2f}",
    BAT_LO=f"{min(v['local_dvfs']['pct'] for v in TS['one_at_a_time']['BATT_SCALE'].values()):.0f}", BAT_HI=f"{max(v['local_dvfs']['pct'] for v in TS['one_at_a_time']['BATT_SCALE'].values()):.0f}",
    MM_G=f"{AS['minmax_instability']['split14_other_region_carbon_g_range'][0]:.3f}",
    MM_LO=f"{AS['minmax_instability']['minmax_norm_range'][0]:.2f}", MM_HI=f"{AS['minmax_instability']['minmax_norm_range'][1]:.2f}", MM_REF=f"{AS['minmax_instability']['ref_norm_range'][0]:.2f}",
    A_ENV_E=f"{_env['E_ref_mean']:.2f}", A_AW_E=f"{_aw['E_ref_mean']:.2f}", A_MX_E=f"{_mx['E_ref_mean']:.2f}", A_MT_E=f"{_mt['E_ref_mean']:.2f}",
    A_ENV_M=f"{_env['E_mm_mean']:.1f}", A_AW_M=f"{_aw['E_mm_mean']:.1f}",
    A_AW_TV=f"{_aw['tv']:.2f}", A_MX_TV=f"{_mx['tv']:.3f}", A_AW_CLIP=f"{100 * _aw['clip_share']:.0f}", A_MX_CLIP=f"{100 * _mx['clip_share']:.1f}",
    A_WIN_AW=f"{100 * AS['winrate']['awc_mm:paper(3,0.30)']['vs_env_static']:.0f}", A_WIN_MX=f"{100 * AS['winrate']['awc_mix:paper(3,0.30)']['vs_env_static']:.0f}", A_WIN_MT=f"{100 * AS['winrate']['awc_mix:tuned(3.0,0.4)']['vs_env_static']:.0f}",
    A_HOT_ENV=f"{_env['hot_cycles']:.1f}", A_HOT_AW=f"{_aw['hot_cycles']:.1f}", A_HOT_MX=f"{_mx['hot_cycles']:.1f}", A_HOT_TH=f"{_tm['static_mm:Thermal Safety']['hot_cycles']:.1f}",
    A_C0S=f"{_cc['static_mm_env']['0']['mean_excess_per_cycle']:.4f}", A_C3S=f"{_cc['static_mm_env']['3']['mean_excess_per_cycle']:.4f}",
    A_C0M=f"{_cc['awc_mix_paper']['0']['mean_excess_per_cycle']:.4f}", A_C3M=f"{_cc['awc_mix_paper']['3']['mean_excess_per_cycle']:.4f}", A_C3N=str(_cc['awc_mix_paper']['3']['n_traj']),
    A_TV_LO=f"{AS['eta_sweep']['awc_mm|0.5']['tv']:.2f}", A_TV_HI=f"{AS['eta_sweep']['awc_mm|50.0']['tv']:.1f}", A_MIXTV_HI=f"{AS['eta_sweep']['awc_mix|50.0']['tv']:.3f}",
    A_PD=f"{(np.array(_env['per_traj']) - np.array(_mt['per_traj'])).mean():.2f}", A_PDCI=f"{1.96 * (np.array(_env['per_traj']) - np.array(_mt['per_traj'])).std(ddof=1) / np.sqrt(len(_env['per_traj'])):.2f}",
    A_VAL=f"{AS['validation_vs_original']['pairs'][0][0]:.2f}", A_NTEST=str(len(_env['per_traj'])),
    A_TUNE_E=AS['tuning']['best']['awc_mix'].split('|')[0], A_TUNE_T=AS['tuning']['best']['awc_mix'].split('|')[1],
    A_STAT_BEST=f"{min(_tm[k]['E_ref_mean'] for k in _tm if k.startswith('static_mm')):.2f}",
    A_LATP=f"{_tm['static_mm:Latency Priority']['E_ref_mean']:.2f}", A_PRIVP=f"{_tm['static_mm:Privacy Priority']['E_ref_mean']:.2f}", A_THP=f"{_tm['static_mm:Thermal Safety']['E_ref_mean']:.2f}",
    PI_CLEAN_ALL=f"{100 * PI['clean_top1_all']:.1f}", PI_CLEAN=f"{100 * _pic:.1f}", PI_CLEAN5=f"{100 * PI['clean_top5_test']:.1f}",
    PI_D4=f"{_pi['4']['d']:,}".replace(',', '{,}'), PI_D8=f"{_pi['8']['d']:,}".replace(',', '{,}'), PI_D14=f"{_pi['14']['d']:,}".replace(',', '{,}'), PI_D17=f"{_pi['17']['d']:,}".replace(',', '{,}'),
    PI_CLIPF=f"{100 * min(_pi[k]['clip_fraction_test'] for k in _pi):.0f}--{100 * max(_pi[k]['clip_fraction_test'] for k in _pi):.0f}",
    PI_BASE_CORR=f"{PI['recon_baseline_mean_image']['corr']:.2f}",
    PI_RC_CLEAN4=f"{_pi['4']['recon_clean']['corr']:.2f}", PI_RC_CLEAN8=f"{_pi['8']['recon_clean']['corr']:.2f}", PI_RC_CLEAN14=f"{_pi['14']['recon_clean']['corr']:.2f}", PI_RC_CLEAN17=f"{_pi['17']['recon_clean']['corr']:.2f}",
    PI_TOP1_LOW=f"{100 * max(v['top1'] for r in _pi.values() for e, v in r['eps'].items() if float(e) <= 10):.1f}",
    PI_RC_LOW=f"{max(v['recon_corr'] for r in _pi.values() for e, v in r['eps'].items() if float(e) <= 10):.2f}",
    PI_E4=f"{min(float(e) for e, v in _pi['4']['eps'].items() if v['top1'] >= 0.9 * _pic):g}", PI_E8=f"{min(float(e) for e, v in _pi['8']['eps'].items() if v['top1'] >= 0.9 * _pic):g}",
    PI_E14=f"{min(float(e) for e, v in _pi['14']['eps'].items() if v['top1'] >= 0.9 * _pic):g}", PI_E17=f"{min(float(e) for e, v in _pi['17']['eps'].items() if v['top1'] >= 0.9 * _pic):g}",
    PI_ED17=f"{min(float(e) for e, v in _pi['17']['eps'].items() if v['top1_denoised'] >= 0.9 * _pic):g}",
    PI_EMIN=f"{min(float(min((e for e, v in r['eps'].items() if v['top1'] >= 0.9 * _pic), key=float)) for r in _pi.values()):g}",
    PI_EMAX=f"{max(float(min((e for e, v in r['eps'].items() if v['top1'] >= 0.9 * _pic), key=float)) for r in _pi.values()):g}",
    PI_RID_LO=f"{100 * min(r['eps']['1000.0']['reid_acc'] for r in _pi.values()):.0f}", PI_RID_HI=f"{100 * max(r['eps']['1000.0']['reid_acc'] for r in _pi.values()):.0f}",
    PI_RC_UTIL4=f"{_pi['4']['eps']['300000.0']['recon_corr']:.2f}", PI_RC_UTIL14=f"{_pi['14']['eps']['30000.0']['recon_corr']:.2f}", PI_RC_UTIL17=f"{_pi['17']['eps']['30000.0']['recon_corr']:.2f}",
    PI_REP6_LO=f"{100 * min(r['repeat']['1.0']['1000000']['reid_acc'] for r in _pi.values()):.0f}", PI_REP6_HI=f"{100 * max(r['repeat']['1.0']['1000000']['reid_acc'] for r in _pi.values()):.0f}",
    TAB_PRIVIMG=tab_privimg(), TAB_PRIVIMGK=tab_privimg_k(),
    PR_CLEAN=f"{100 * _cl:.1f}", PR_MEM=f"{100 * PR['clean_acc']['member']:.1f}", PR_NON=f"{100 * PR['clean_acc']['nonmember']:.1f}",
    PR_BASE_CORR=f"{PR['recon_baseline_mean_image']['corr']:.2f}",
    PR_ACC05=f"{100 * _pk['14']['eps']['0.5']['acc']:.1f}", PR_ACC1=f"{100 * _pk['14']['eps']['1.0']['acc']:.1f}",
    PR_E3=f"{min(float(e) for e, v in _pk['3']['eps'].items() if v['acc'] >= 0.9 * _cl):g}", PR_E4=f"{min(float(e) for e, v in _pk['4']['eps'].items() if v['acc'] >= 0.9 * _cl):g}",
    PR_E8=f"{min(float(e) for e, v in _pk['8']['eps'].items() if v['acc'] >= 0.9 * _cl):g}", PR_E14=f"{min(float(e) for e, v in _pk['14']['eps'].items() if v['acc'] >= 0.9 * _cl):g}",
    PR_E17=f"{min(float(e) for e, v in _pk['17']['eps'].items() if v['acc'] >= 0.9 * _cl):g}",
    PR_RP1_14=f"{100 * _pk['14']['repeat']['1.0']['6000']['clf_acc']:.0f}", PR_RP1_8=f"{100 * _pk['8']['repeat']['1.0']['6000']['clf_acc']:.0f}",
    PR_RP60=f"{100 * max(_pk[k]['repeat']['1.0']['60']['clf_acc'] for k in _pk):.0f}", PR_RP600=f"{100 * max(_pk[k]['repeat']['1.0']['600']['clf_acc'] for k in _pk):.0f}",
    PR_RP05=f"{100 * max(_pk[k]['repeat']['0.5']['6000']['clf_acc'] for k in _pk):.0f}",
    PR_AUC_LO=f"{min(v['mi_auc'] for r in _pk.values() for v in r['eps'].values()):.2f}", PR_AUC_HI=f"{max(v['mi_auc'] for r in _pk.values() for v in r['eps'].values()):.2f}",
    PR_AUC_CLEAN=f"{_pk['14']['eps']['100000.0']['mi_auc']:.2f}",
    PR_RC14=f"{_pk['14']['eps']['300.0']['recon_corr']:.2f}", PR_ACC300=f"{100 * _pk['14']['eps']['300.0']['acc']:.1f}", PR_CL300=f"{100 * _pk['14']['eps']['300.0']['class_attack_acc']:.1f}",
    PR_RC_05=f"{_pk['14']['eps']['0.5']['recon_corr']:.2f}",
    PR_CLIPF=f"{100 * _pk['14']['clip_fraction_test']:.0f}",
    GEN_OFF_CNN=f"{T11['MobileNetV2']['offload_vs_local_pct'] / 100:.1f}", GEN_OFF_VIT=f"{min(T11['ViT-Base']['offload_vs_local_pct'], T11['CLIP ViT-B/32']['offload_vs_local_pct']) - 100:.1f}",
    GEN_OFF_VIT_HI=f"{max(T11['ViT-Base']['offload_vs_local_pct'], T11['CLIP ViT-B/32']['offload_vs_local_pct']) - 100:.1f}",
    GEN_RP_LO=f"{min(T11['ViT-Base']['potential_pct'], T11['CLIP ViT-B/32']['potential_pct']):.1f}", GEN_RP_HI=f"{max(T11['ViT-Base']['potential_pct'], T11['CLIP ViT-B/32']['potential_pct']):.1f}",
    J4=f"{ld['4']:.2f}", J7=f"{ld['7']:.2f}", J10=f"{ld['10']:.2f}", J11=f"{ld['11']:.2f}", J13=f"{ld['13']:.2f}",
    KSTAR=str(R['landscape']['k_star']), JMIN=f"{R['landscape']['J_min']:.3f}", KC=str(cv['k_mode']), JC=f"{cv['J_mean']:.3f}", JCS=f"{cv['J_sd']:.3f}",
    TAB_CARBON=tab_carbon(), TAB_SENS=tab_sens(), TAB_THERMAL=tab_thermal(), TAB_SUMMARY=tab_summary(), TAB_GEN=tab_gen(), TAB_POL=tab_pol(),
)
assert 0.13 <= ld['7'] <= 0.17 and 0.13 <= ld['10'] <= 0.17 and 0.39 <= ld['11'] <= 0.45 and 0.39 <= ld['13'] <= 0.45 and ld['4'] > 0.5
_wp = R['weight_perturbation']
_mx = lambda key: max(_wp[key + '-50%']['max_abs'], _wp[key + '+50%']['max_abs'])
assert (_mx('w_lat'), _mx('w_carb'), _mx('w_priv'), _mx('w_therm')) == (2, 1, 0, 2), _wp


def fill(s):
    for k, v in tok.items():
        s = s.replace(f'@@{k}@@', v)
    left = re.findall(r'@@\w+@@', s)
    assert not left, left
    return s


# ------------------------------------------------------------------ patch the submitted tex
def cut(s, a, b, new, include_b=False):
    i = s.index(a); j = s.index(b, i)
    return s[:i] + new + s[j:] if not include_b else s[:i] + new + s[j + len(b):]


t = old
t = re.sub(r'\\begin\{abstract\}\n.*?\n\n\\tiny', lambda m: '\\begin{abstract}\n' + fill(ABSTRACT) + '\n\n\\tiny', t, count=1, flags=re.S)

# introduction
t = cut(t, 'The 2022 \\emph{Principles of\nGreen Software Engineering}', '\n\nTwo further blind spots', INTRO_GREEN)
t = t.replace('Schwartz-Ziv and Tishby~\\citep{tishby2017deep}', 'Shwartz-Ziv and Tishby~\\citep{tishby2017deep}')
t = cut(t, 'that forecasts device temperature under each candidate\nsplit one control interval ahead, so thermal cost genuinely\nparticipates in split selection rather than acting only as a reactive\nthreshold, with a DVFS controller',
        'and battery-cutoff logic retained as', 'that forecasts device temperature under each candidate\nsplit one control interval ahead (in our experiments the forecast discriminates only weakly between splits, Section~\\ref{sec:thermal}), with a DVFS controller ')
t = t.replace('The result is an assignment that is not merely fast\nbut jointly efficient across carbon, privacy, and thermal axes.',
              'The result is an assignment that balances latency against\ncarbon, privacy, and thermal state.')
t = t.replace('the proposed framework against local-only and latency-first baselines along the\ncarbon, latency, privacy, and thermal axes.',
              'the proposed framework against local-only, local-with-DVFS, latency-first, carbon-aware greedy and privacy-aware static baselines along the\ncarbon, latency, privacy, and thermal axes.')

# related work
t = t.replace('The proposed framework is a direct response to that observation.\n', 'The proposed framework is a direct response to that observation.\n' + RW_21, 1)
t = cut(t, 'For split inference specifically, the literature on carbon awareness', '\\subsection{Privacy-Preserving Split Inference}', RW_22 + '\n')
t = t.replace('\\subsection{Thermal-Aware Mobile Inference}', RW_24 + '\\subsection{Thermal-Aware Mobile Inference}', 1)

# section 4
t = cut(t, '\\subsection{Carbon Emission Model}', '\\subsection{Proactive Carbon Look-Ahead Scheduling}', fill(SEC_42))
t = cut(t, 'Fig.~\\ref{fig:carbon24h} illustrates the mechanism:', '\\subsection{Privacy Penalty and Risk Zone}', FIG4_TXT + '\n')
t = cut(t, '\\subsection{Privacy Penalty and Risk Zone}', '\\subsection{Differential Privacy Module}', SEC_44)
t = cut(t, 'This gives an $\\epsilon$-differential privacy guarantee', '\\subsection{Active Thermal--Battery Conduction Model}', SEC_45_TAIL + SEC_46)
t = t.replace('\\subsection{DVFS-Coupled Hardware Thermal Control}', SEC_472 + '\\subsection{DVFS-Coupled Hardware Thermal Control}', 1)
t = cut(t, 'The frequency reduction also reduces local\nthroughput.', '\\subsection{Battery Chemistry Protection}', DVFS_NEW + '\n\n')
t = cut(t, 'For MobileNetV2\nwith 18 layers and 3 candidate regions', '\n\n', fill(SEC_5_PATCH))
# the hard-constraint sentence of the old paragraph follows the replaced text; remove it
t = t.replace('The hard constraint check $k \\in \\mathcal{Z}_{\\mathrm{priv}}$ is\nevaluated first, enabling early termination for excluded layers before\neither pass.\n', '')

# --- AWC formulation: fixed-reference excess, pairwise proposition
_old = '\\ell_{i,t} &= \\max\\!\\bigl(0,\\; \\hat{C}_i(k_t^*, r_t^*) - \\tau_i\\bigr), \\notag\\\\'
assert _old in t
t = t.replace(_old, '\\ell_{i,t} &= \\max\\!\\bigl(0,\\; \\bar{C}_i(k_t^*, r_t^*) - \\tau_i\\bigr), \\notag\\\\')
_old = 'with $\\hat{C}_{\\mathrm{priv}} := P(k_t^*)$.'
assert _old in t
t = t.replace(_old, AWC_CBAR)
_old = 'Section~\\ref{sec:awc-eval} evaluates this\nempirically under a scenario combining a carbon-intensity spike with a\nconcurrent thermal excursion, comparing the adaptive controller\nagainst the best static preset from this section.'
assert _old in t
t = t.replace(_old, AWC_PROP2)
# --- Section 3: the zone is a rule, not a list from measurements
t = cut(t, 'Layers close to the network input retain high mutual information', '% =======================================================================\n\\section{System Design and Component Models}', ZONE_TXT + '\n')

eth = t[t.index('\\subsection{Ethical Considerations}') + len('\\subsection{Ethical Considerations}'):]
eth = eth[:eth.index('% =======================================================================\n\\section{Conclusion}')]

# sections 6-8 replaced
i = t.index('\\section{Experimental Validation}')
j = t.index('% =======================================================================\n\\section*{Conflict of Interest Statement}')
new_mid = fill(SEC_6) + fill(SEC_7_A) + eth.rstrip('\n') + '\n\n' + fill(SEC_8)
t = t[:i] + new_mid + t[j:]
t = cut(t, '\\section*{Data Availability Statement}', '\\bibliographystyle', DATA_AVAIL)
t = t.replace('The authors declare that this research received no specific grant from\nany funding agency in the public, commercial, or not-for-profit sectors.',
              'The authors declare that this research received no specific grant from\nany funding agency in the public, commercial, or not-for-profit sectors. % TODO(authors): the submission form states that financial support was received; make the two consistent.')
a = "\\begin{tabular}{lcccc}\n\\toprule\n\\textbf{System}"
b = "\\bottomrule\n\\end{tabular}\n\\par\\smallskip\\footnotesize $^{*}$"
if a in t and b in t:
    t = t.replace(a, "\\resizebox{\\textwidth}{!}{%\n" + a, 1).replace(b, b.replace("\\end{tabular}", "\\end{tabular}}"), 1)
t = re.sub(r'\\paragraph\{([^}]*)\}', lambda m: '\\par\\medskip\\noindent\\textbf{' + m.group(1) + '}', t)
open(sys.argv[2], 'w', encoding='utf-8').write(t)
print('wrote', sys.argv[2], len(t.splitlines()), 'lines')
